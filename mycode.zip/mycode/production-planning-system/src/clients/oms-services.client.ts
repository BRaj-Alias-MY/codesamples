
import axios from 'axios';
import {  PlantCode } from "../models/oms-services.request";
import { StyleScheduleColorGroupedMos,MoWiseOperations } from '../models/oms-services.response';

export class OmsServicesClient{
    private getMoWiseOperationsUrl = '/order-management-service/getMoWiseOperations';
    private getStyleScheduleColorGroupedMosUrl = '/order-management-service/getStyleScheduleColorGroupedMos';
    
    async loadMoWiseOperations(plant_code : PlantCode):Promise<MoWiseOperations[]>{ 
        return axios.post(process.env.OMS_BASE_URL+this.getMoWiseOperationsUrl,plant_code).then(moOperations=>{
            return moOperations.data;
        }).catch(err=>{
            console.log(err);
            return null;
        }); 
    }

    async getStyleScheduleColorGroupedMos(plant_code : PlantCode):Promise<StyleScheduleColorGroupedMos[]>{
        return axios.post(''+process.env.OMS_BASE_URL+this.getStyleScheduleColorGroupedMosUrl,plant_code).then(groupedMos=>{
            return groupedMos.data;
        }).catch(err=>{
            console.log(err);
            return null;
        });
    }
}

