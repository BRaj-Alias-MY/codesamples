import { Injectable, Body } from '@nestjs/common';
import 'dotenv/config';
import { PoMoUpdationClentRequest } from 'src/models/prodution-order.request';


@Injectable()
export class MoPoUpdate {
    constructor() {}
    async moUpdation(podata:PoMoUpdationClentRequest):Promise<string> {
        console.log(podata);
        const axios = require('axios');
        const oms_base_url = process.env.PO_UPDATE_URL;
        console.log(oms_base_url);
        try{
            return await axios.post(oms_base_url, podata).then(async response => {
                return await "Production Order Successfully Created with Po Number "+podata.ponumber;
          })
        }
        catch(err){
            console.log(err);
            return err.data;
        }
    }
}