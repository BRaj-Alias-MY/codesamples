
import axios from 'axios';
import { BuyerMappings } from '../models/cms-services.response';
export class CmsServicesClient{
    private loadMappedBuyerDivisionsUrl = '/buyerMapping/loadMappedBuyerDivisions';
    loadMappedBuyerDivisions():Promise<BuyerMappings[]>{
        return axios.post(process.env.CMS_BASE_URL+this.loadMappedBuyerDivisionsUrl).then(mappedBuyerDivisons=>{
            return mappedBuyerDivisons.data
        }).catch(err=>{
            return null;
        })
    }
}

