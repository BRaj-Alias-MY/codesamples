import { ApiModelProperty } from "@nestjs/swagger";

export class PlantCode{
    @ApiModelProperty()
    plant_code : string
}



