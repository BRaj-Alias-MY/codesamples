
export class MoWiseOperations {
    mo_number : string;
    operation_codes : string;
}

export class StyleScheduleColorGroupedMos{
    style : string;
    schedule : string;
    color_name : string;
    mo_list : string;
    buyer_desc : string;
}

