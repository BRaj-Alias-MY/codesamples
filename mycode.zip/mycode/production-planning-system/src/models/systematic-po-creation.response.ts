
export class SystematicPoCreationResponse{
    mos  : string;
    info : any;
    style: string;
    color: string;
    schedule:string;
}
export enum operationsComparision{
    lessthan = "1",
    equal = "0",
    greaterthan = "-1"
}