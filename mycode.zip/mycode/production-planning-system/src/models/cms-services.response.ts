export class BuyerMappings{
    buyer_division :string;
    customer_name : string;
}
