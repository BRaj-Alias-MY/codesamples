import { ApiModelProperty } from '@nestjs/swagger';
import { PpsGraph } from '../entities/pps_graph';

export class ProductionOrderRequest {
      @ApiModelProperty()
      graph: PpsGraph;

      @ApiModelProperty()
      productionorder: string;

      @ApiModelProperty()
      isMo: boolean;

}
export class PoMoUpdationClentRequest{
      monumbers:string;
      ponumber:string
}