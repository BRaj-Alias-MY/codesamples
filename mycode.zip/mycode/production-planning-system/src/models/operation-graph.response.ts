import { PpsOperationRouting } from 'src/entities/pps_operation_routing';

export class OperationGraphResponse {
    status: boolean;
    data?: PpsOperationRouting;
    errorInfo?: string;
}
