import { ApiModelProperty } from "@nestjs/swagger";

export  class poSpecificationsObj{
    @ApiModelProperty()
    style : string;
    @ApiModelProperty()
    schedule : string;
    @ApiModelProperty()
    color : string;
    @ApiModelProperty()
    mos : string;
    @ApiModelProperty()
    mo_operations : string;
    @ApiModelProperty()
    customer_plant_ref_id:string;
}
