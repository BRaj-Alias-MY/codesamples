import { ApiModelProperty} from "@nestjs/swagger";

export class operationFindByCode{
    @ApiModelProperty()
    operation_code : string;
}
