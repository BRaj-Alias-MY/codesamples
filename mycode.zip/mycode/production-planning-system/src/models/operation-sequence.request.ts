import { ApiModelProperty } from '@nestjs/swagger';
import { DeepPartial } from 'typeorm';
import { PpsGraph } from '../entities/pps_graph';
import { PpsOperationRouting } from '../entities/pps_operation_routing';

export class OperationSequenceRequest {
      @ApiModelProperty()
      graph: DeepPartial<PpsGraph>;

      @ApiModelProperty()
      operationRouting: Partial<PpsOperationRouting>;
}
