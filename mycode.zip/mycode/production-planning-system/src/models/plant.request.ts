import { ApiModelProperty } from '@nestjs/swagger';
import { PpsGraph } from '../entities/pps_graph';

export class PlantRequest {
      @ApiModelProperty()
      graph: PpsGraph;

      @ApiModelProperty()
      plant: string;
}
