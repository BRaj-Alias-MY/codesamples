import { PpsOperations } from "../entities/pps_operations";

export class OperationCreationObject{
    status : boolean;
    errInfo ?: string;
    data ?: PpsOperations;
}

export class OperationsFindObject{
    status : boolean;
    errInfo ?: string;
    data ?: PpsOperations[];
}
