import { ApiModelProperty } from '@nestjs/swagger';
import { PpsGraph } from '../entities/pps_graph';

export class CustomerRequest {
      @ApiModelProperty()
      graph: PpsGraph;

      @ApiModelProperty()
      plant: string;

      @ApiModelProperty()
      customer: string;
}
