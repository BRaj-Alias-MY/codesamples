import { Test, TestingModule } from '@nestjs/testing';
import { ManualpocreationController } from './manual-pocreation.controller';

describe('Manualpocreation Controller', () => {
  let controller: ManualpocreationController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [ManualpocreationController],
    }).compile();

    controller = module.get<ManualpocreationController>(ManualpocreationController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
