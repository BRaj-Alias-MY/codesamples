import { Controller, Post,Body } from '@nestjs/common';
import { SystematicPoCreationService } from '../services/systematic-po-creation.service';
import {SystematicPoCreationResponse} from '../models/systematic-po-creation.response';
import { PlantCode } from '../models/oms-services.request';

@Controller('systematicPoCreation')
export class SystematicPoCreationController {
    constructor(private systematicPoCreationService : SystematicPoCreationService){
    }
    
    //Dummy Method to call the systematic Po creation through URL
    @Post('/createSystematicPos')
    async createSystematicPos(@Body() plant_code: PlantCode):Promise<SystematicPoCreationResponse[]>{
        try{
            return await this.systematicPoCreationService.createSystematicPos(plant_code);
        }catch(err){
            console.log(err);
            return null;
        }
    }

}