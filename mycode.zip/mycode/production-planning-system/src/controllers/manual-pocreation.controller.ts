import { Controller,Post,Body } from '@nestjs/common';
import {PoCreation} from '../dtos/manualpocreation.dto';
//import { OperationsGraphService } from '../services/operations-graph.service';
import {ManualpocreationService} from '../services/manual-pocreation.service';


@Controller('manualpocreation')
export class ManualpocreationController {
      constructor( private pocreate: ManualpocreationService){}

      @Post('/poCreation')
      async poCreation(@Body() podata: PoCreation) {
            return await this.pocreate.productionorderCreation(podata);

      }
}
