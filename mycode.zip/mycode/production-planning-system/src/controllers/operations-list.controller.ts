import { Controller, Post, Body, Logger } from '@nestjs/common';
import { OperationsListService } from '../services/operations-list.service';
import { OperationCreationObject, OperationsFindObject } from '../models/operation.response';
import { operationFindByCode } from '../models/operation.request';
import { PpsOperations } from '../entities/pps_operations';

@Controller('operations-list')
export class OperationsListController {
    private logger = new Logger('OperationsListController')
    constructor(private service:OperationsListService){}
    @Post('/createOperation')
    async createOperation(@Body() operation:PpsOperations):Promise<OperationCreationObject>{
        const operationCodeExists = await this.service.verifyOperationCodeExists(operation);
        const operationNameExists = await this.service.verifyOperationNameExists(operation);
        const operationCreateObj = new OperationCreationObject();
        if(!operationCodeExists && !operationNameExists){
            return await this.service.createOperation(operation).then((data)=>{
                operationCreateObj.status = true;
                operationCreateObj.data = data;
                return operationCreateObj;
            }).catch((err)=>{
                operationCreateObj.status = false;
                operationCreateObj.errInfo = err.data;
                return operationCreateObj;
            })
        }
        else{
            operationCreateObj.errInfo = "Operation Code or Operation Name already exists.";
            operationCreateObj.status = false;
            return operationCreateObj;
        }
    }
    @Post('/updateOperation')
    async updateOperation(@Body() operation:PpsOperations):Promise<OperationCreationObject>{
        const operationCreateObj = new OperationCreationObject();
            return await this.service.createOperation(operation).then((data)=>{
                operationCreateObj.status = true;
                operationCreateObj.data = data;
                return operationCreateObj;
            }).catch((err)=>{
                operationCreateObj.status = false;
                operationCreateObj.errInfo = err.data;
                return operationCreateObj;
            })
    }
    @Post('/getAllOperations')
    async getAllOperations():Promise<PpsOperations[]>{
        return await this.service.getAllOperations().then((data)=>{
            return data;
        }).catch((err)=>{
            return err;
        })
    }
    @Post('/getOperation')
    async getOperation(@Body() operation_code:operationFindByCode):Promise<OperationCreationObject>{
        const operationGetObj = new OperationCreationObject();
        return await this.service.getOperation(operation_code.operation_code).then((data)=>{
            operationGetObj.data = data;
            operationGetObj.status = true;
            return operationGetObj;
        }).catch((err)=>{
            operationGetObj.status = false;
            operationGetObj.errInfo = err.data;
            return operationGetObj;
        })
    }
    @Post('/deActivateOperation')
    async deActivateOperation(@Body() operation_code:operationFindByCode):Promise<OperationCreationObject>{
        const operationGetObj = new OperationCreationObject();
        return await this.service.deActivateOperation(operation_code.operation_code).then((data)=>{
            operationGetObj.data = data;
            operationGetObj.status = true;
            return operationGetObj
        }).catch((err)=>{
            operationGetObj.errInfo = err.data;
            operationGetObj.status = false;
            return operationGetObj
        })
    }
}
