import { Controller, Post, Body, Logger} from '@nestjs/common';
import { OperationsGraphService } from '../services/operations-graph.service';
import { OperationGraphResponse } from '../models/operation-graph.response';
import { OperationSequenceRequest } from '../models/operation-sequence.request';
import { PlantRequest } from '../models/plant.request';
import { CustomerRequest } from '../models/customer.request';
import { ProductionOrderRequest } from '../models/prodution-order.request';
import { PpsGraph } from '../entities/pps_graph';
import { PpsOperationRouting } from '../entities/pps_operation_routing';

@Controller('operationsGraph')
export class OperationsGraphController {
    private logger = new Logger('OperationsGraphController');
    constructor(private operationGraphService: OperationsGraphService) {
    }

    // Requests for Global Graph
    @Post('/createGlobalGraph')
    async createGlobalGraph(@Body() graph: PpsGraph): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(graph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            graphSequenceObj.level = 'Global';
            graphSequenceObj.unique_reference_id = 'global';

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.createOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

    @Post('/updateGlobalGraph')
    async updateGlobalGraph(@Body() graph: PpsGraph): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(graph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            graphSequenceObj.level = 'Global';
            graphSequenceObj.unique_reference_id = 'global';

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.updateOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

    // Requests for Plant Graph
    @Post('/createPlantGraph')
    async createPlantGraph(@Body() plantGraph: PlantRequest): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(plantGraph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            graphSequenceObj.level = 'Plant';
            graphSequenceObj.unique_reference_id = plantGraph.plant;

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = plantGraph.graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.createOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

    @Post('/updatePlantGraph')
    async updatePlantGraph(@Body() plantGraph: PlantRequest): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(plantGraph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            graphSequenceObj.level = 'Plant';
            graphSequenceObj.unique_reference_id = plantGraph.plant;

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = plantGraph.graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.updateOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

    // Requests for Customer Graph
    @Post('/createCustomerGraph')
    async createCustomerGraph(@Body() customerGraph: CustomerRequest): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(customerGraph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            graphSequenceObj.level = 'Customer';
            graphSequenceObj.unique_reference_id = customerGraph.plant + '_' + customerGraph.customer;

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = customerGraph.graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.createOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

    @Post('/updateCustomerGraph')
    async updateCustomerGraph(@Body() customerGraph: CustomerRequest): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(customerGraph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            graphSequenceObj.level = 'Customer';
            graphSequenceObj.unique_reference_id = customerGraph.plant + '_' + customerGraph.customer;

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = customerGraph.graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.updateOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

    // Requests for Production Order Graph
    @Post('/createPoGraph')
    async createPoGraph(@Body() poGraph: ProductionOrderRequest): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(poGraph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            if (poGraph.isMo) {
                graphSequenceObj.level = 'POMO';
            } else {
                graphSequenceObj.level = 'PO';
            }

            graphSequenceObj.unique_reference_id = poGraph.productionorder;

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = poGraph.graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.createOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

    @Post('/updatePoGraph')
    async updatePoGraph(@Body() poGraph: ProductionOrderRequest): Promise <OperationGraphResponse> {
        this.logger.log(JSON.stringify(poGraph));
        const response = new OperationGraphResponse();
        try {
            // setting operation sequence data
            const graphSequenceObj = new PpsOperationRouting();
            if (poGraph.isMo) {
                graphSequenceObj.level = 'POMO';
            } else {
                graphSequenceObj.level = 'PO';
            }

            graphSequenceObj.unique_reference_id = poGraph.productionorder;

            // Preparing input data as per OperationSequenceRequest
            const operationSequenceRequst = new OperationSequenceRequest();
            operationSequenceRequst.graph = poGraph.graph;
            operationSequenceRequst.operationRouting = graphSequenceObj;

            return await this.operationGraphService.updateOperationSequence(operationSequenceRequst).then(
                graphData => {
                    if (graphData) {
                        response.status = true;
                        response.data = graphData;
                        return response;
                    } else {
                        response.status = false;
                        response.errorInfo = 'Graph Data Not Found';
                        return response;
                    }
                },
            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } catch (err) {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        }
    }

}
