import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OperationsListController } from '../controllers/operations-list.controller';
import { ManualpocreationController } from '../controllers/manual-pocreation.controller';
import { ManualpocreationService } from '../services/manual-pocreation.service';
import { OperationsListService } from '../services/operations-list.service';
import { SystematicPoCreationController } from '../controllers/systematic-po-creation.controller';
import { SystematicPoCreationService } from '../services/systematic-po-creation.service';
import { PpsGraph } from '../entities/pps_graph';
import { PpsGraphRouting } from '../entities/pps_graph_routing';
import { PpsOperations } from '../entities/pps_operations';
import { PpsOperationRouting } from '../entities/pps_operation_routing';
import { PpsProductionOrder } from '../entities/pps_production_order';
import { OperationsGraphService } from '../services/operations-graph.service';
import { OmsServicesClient } from '../clients/oms-services.client';
import { CmsServicesClient } from '../clients/cms-services.client';
import { MoPoUpdate } from 'src/clients/mo_po_updateclient';
import { OperationsGraphController } from '../controllers/operations-graph.controller';

@Module({
    imports: [TypeOrmModule.forFeature([PpsGraph, PpsGraphRouting, PpsOperations, PpsOperationRouting, 
        PpsProductionOrder])],
    controllers: [OperationsListController, ManualpocreationController, SystematicPoCreationController, 
        OperationsGraphController ],
    providers: [ OperationsListService, ManualpocreationService, SystematicPoCreationService, OperationsGraphService,
        OmsServicesClient,CmsServicesClient,MoPoUpdate]
})

export class InfrastructureModule { }
