import { Injectable } from '@nestjs/common';
import { PoCreation } from '../dtos/manualpocreation.dto';
import {PpsGraph} from '../entities/pps_graph';
import { PpsProductionOrder } from '../entities/pps_production_order';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import {OperationsGraphService} from '../services/operations-graph.service';
import { PpsGraphRouting } from '../entities/pps_graph_routing';
import { OperationSequenceRequest } from '../models/operation-sequence.request';
import { PpsOperationRouting } from '../entities/pps_operation_routing';
import axios from 'axios';
import 'dotenv/config';
import { MoPoUpdate } from 'src/clients/mo_po_updateclient';
import { PoMoUpdationClentRequest } from 'src/models/prodution-order.request';


@Injectable()
export class ManualpocreationService {
      constructor(private operationgraphservice : OperationsGraphService, @InjectRepository(PpsProductionOrder) private prodorderRepository: Repository<PpsProductionOrder>,
      private MoPoUpdateClient : MoPoUpdate){}
      async productionorderCreation(podata:PoCreation){            
            const operationSequenceRequest = new OperationSequenceRequest();
            operationSequenceRequest.graph = podata.graph;
            // Level and reference id
            const operationRouting = new PpsOperationRouting();
            operationRouting.level = podata.level;
            const monumbers = podata.mo;
            const po_desc = podata.schedule+'_'+podata.style+'_'+podata.color;
            return await this.prodorderRepository.save({po_description : po_desc}).then(async data=>{
                  operationRouting.unique_reference_id = data.po_number;
                  const ponumber = data.po_number;
                  const podata = new PoMoUpdationClentRequest();
                  podata.monumbers = monumbers;
                  podata.ponumber = ponumber;
                  operationSequenceRequest.operationRouting = operationRouting;
                  try{
                        await this.operationgraphservice.createOperationSequence(operationSequenceRequest).then(async res=>{
                        })
                  }
                  catch(err){
                        return err;
                  }
                  try{
                     return await this.MoPoUpdateClient.moUpdation(podata);
                  }
                  catch(err){
                        return err;
                  }
            })
      }
}
