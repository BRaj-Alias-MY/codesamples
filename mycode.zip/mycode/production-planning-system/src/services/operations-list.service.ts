import { Injectable, Body } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, FindOperator, Not} from 'typeorm';
import { PpsOperations } from '../entities/pps_operations';

@Injectable()
export class OperationsListService {
    constructor(@InjectRepository(PpsOperations) private operationsRepository: Repository<PpsOperations>){}
    async verifyOperationCodeExists(operation:PpsOperations):Promise<Boolean>{
        return await this.operationsRepository.findOne({where:{operation_code:operation.operation_code}}).then((data)=>{
            if(data){
                return data.isActive;
            }
            else{
                return false;
            }
        }).catch((err)=>{
            console.log(err);
            return err;
        })
    }
    async verifyOperationNameExists(operation:PpsOperations):Promise<Boolean>{
        return await this.operationsRepository.findOne({where:{operation_name:operation.operation_name}}).then((data)=>{
            if(data){
                return data.isActive;
            }
            else{
                return false;
            }
        }).catch((err)=>{
            console.log(err);
            return err;
        })
    }
    async createOperation(operation:PpsOperations):Promise<PpsOperations>{
        operation.isActive = true;
        const activated_date = new Date().toISOString().slice(0, 10);
        operation.activated_date = activated_date;
        return await this.operationsRepository.save(operation).then((data)=>{
            return data;
        }).catch((err)=>{
            return err;
        })
    }
    async getAllOperations():Promise<PpsOperations[]>{
        try{
            const allOperations =  await this.operationsRepository.find({where:{isActive:true},order:{operation_code:"ASC"}});
            return allOperations.map((opeartion)=>{
                return opeartion;
            })
        }
        catch(err){
            return err;
        }
    }
    async getOperation(operation_code:string):Promise<PpsOperations>{
        return await this.operationsRepository.find({where:{operation_code:operation_code}}).then((data)=>{
            return data;
        }).catch((err)=>{
            return err;
        })
    }
    async deActivateOperation(operation_code:string):Promise<PpsOperations>{
        const deactive_date = new Date().toISOString().slice(0, 10);
        return await this.operationsRepository.update({operation_code:operation_code},{isActive:false,deactivated_date:deactive_date}).then(()=>{
            return this.getOperation(operation_code);
        }).catch((err)=>{
            return err;
        })
    }
}
