import { Test, TestingModule } from '@nestjs/testing';
import { OperationsGraphService } from './operations-graph.service';
import { InfrastructureModule } from '../infrastructure/infrastructure.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OperationSequenceRequest } from '../models/operation-sequence.request';
import { PpsOperationRouting } from 'src/entities/pps_operation_routing';


describe('OperationsGraphService', () => {
  let service: OperationsGraphService;
  const operationSequenceRequest = new OperationSequenceRequest();
  const operationRouting = new PpsOperationRouting();

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports : [InfrastructureModule, TypeOrmModule.forRoot()],
    }).compile();

    service = module.get<OperationsGraphService>(OperationsGraphService);
  });

  it('should returns created graph data with operation routing.', async () => {
    expect(await service.createOperationSequence({graph:{root_operation: 'op1' ,graphRoutings:[{toOperation:{operation_code:'op1'}, fromOperation: {operation_code:'op2'}},{toOperation:{operation_code:'op2'}, fromOperation: {operation_code:'op3'}}] }, operationRouting:{level:'Global', unique_reference_id: 'global'} })).toMatchObject(operationRouting);
  });

  it('should returns updated graph data with operation routing.', async () => {
    expect(await service.updateOperationSequence({graph:{root_operation: 'op1',graphRoutings:[{toOperation:{operation_code:'op1'}, fromOperation: {operation_code:'op2'}},{toOperation:{operation_code:'op2'}, fromOperation: {operation_code:'op3'}}] }, operationRouting:{level:'Global', unique_reference_id: 'global'} })).toMatchObject(operationRouting);
  });

});
