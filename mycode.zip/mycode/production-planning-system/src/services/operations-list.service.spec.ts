import { Test, TestingModule } from '@nestjs/testing';
import { OperationsListService } from './operations-list.service';

describe('OperationsListService', () => {
  let service: OperationsListService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [OperationsListService],
    }).compile();

    service = module.get<OperationsListService>(OperationsListService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
