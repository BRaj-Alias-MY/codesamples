import { ManualpocreationService } from '../services/manual-pocreation.service';
import { Injectable } from '@nestjs/common';
import { poSpecificationsObj } from '../models/po-specifications-obj';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { PpsGraph } from '../entities/pps_graph';
import { PpsGraphRouting } from '../entities/pps_graph_routing';
import { PpsOperationRouting } from '../entities/pps_operation_routing';
import { OmsServicesClient } from '../clients/oms-services.client';
import { CmsServicesClient } from '../clients/cms-services.client';
import { PlantCode } from '../models/oms-services.request';
import { BuyerMappings } from '../models/cms-services.response';
import { StyleScheduleColorGroupedMos,MoWiseOperations } from '../models/oms-services.response';
import { PoCreation } from '../dtos/manualpocreation.dto';
import {SystematicPoCreationResponse, operationsComparision} from '../models/systematic-po-creation.response';

@Injectable()
export class SystematicPoCreationService {
    private returnResult = [];
    private Global = "global";
    private graphRelations = ["ppsGraphRoutings","ppsOperationRouting"];

    constructor(@InjectRepository(PpsGraph) private graphroutingRepository: Repository<PpsGraph>,
                @InjectRepository(PpsOperationRouting) private operarationroutingRepository: Repository<PpsOperationRouting>,
                private omsServicesClient : OmsServicesClient,
                private cmsServicesClient : CmsServicesClient,
                private poService : ManualpocreationService){
        //Do Nothing
    }

    async createSystematicPos(plant_code : PlantCode):Promise<SystematicPoCreationResponse[]>{
        try{
            return await this.saveSystematicPos(plant_code);
        }catch(err){
            console.log(err);
            return null;
        }
    }
    //This function loads all customers-mapped for buyer divisions for sending the customer-name to graph creation
    async loadMappedBuyerDivisions():Promise<BuyerMappings[]>{
        try{
            const mappedbuyerdivisions = await this.cmsServicesClient.loadMappedBuyerDivisions();
            return mappedbuyerdivisions;
        }catch(err){
            console.log(err);
            return null;
        }
    }
    //This functin gets all the operations of a MO in a csv format
    async loadMoWiseOperations(plant_code:PlantCode):Promise<MoWiseOperations[]>{
        try{
            const moWiseOpetrations = await this.omsServicesClient.loadMoWiseOperations(plant_code);
            return moWiseOpetrations;
        }catch(err){
            console.log(err);
            return null;
        }
    }

    async loadStyleScheduleColorGroupedMos(plant_code : PlantCode):Promise<StyleScheduleColorGroupedMos[]>{
        try{
            const mosOpetratgroupedMosions = await this.omsServicesClient.getStyleScheduleColorGroupedMos(plant_code);
            return mosOpetratgroupedMosions;
        }catch(err){
            console.log(err);
            return null;
        }
    }

    //This function cumulate the mos based on plant,style,schedule and color and pass it furthur
    async saveSystematicPos(plant_code : PlantCode):Promise<SystematicPoCreationResponse[]>{
        try{
            let cumulatedSimilarMos = null;
            const mappedbuyerdivisionsMap = new Map();
            const moWiseOpetrationsMap = new Map();

            const mappedbuyerdivisions = await this.loadMappedBuyerDivisions();
            const moWiseOpetrations = await this.loadMoWiseOperations(plant_code);
            const groupedMos = await this.loadStyleScheduleColorGroupedMos(plant_code);

            mappedbuyerdivisions.map(mappedbuyerdivision=>{
                mappedbuyerdivisionsMap.set(mappedbuyerdivision.buyer_division,mappedbuyerdivision.customer_name);
            });
            moWiseOpetrations.map(mo=>{
                moWiseOpetrationsMap.set(mo.mo_number.toString(),mo.operation_codes);
            });

            return Promise.all(groupedMos.map(async groupedMo=>{
                if(mappedbuyerdivisionsMap.get(groupedMo.buyer_desc)){
                    cumulatedSimilarMos = await this.cumulateMatchingMosWithOperations(groupedMo.mo_list,moWiseOpetrationsMap);
                    for(let cumulatedSimilarMosRecord of cumulatedSimilarMos){
                        const poSpecObj = new poSpecificationsObj;
                        poSpecObj.mos = cumulatedSimilarMosRecord[1].toString();
                        poSpecObj.mo_operations = cumulatedSimilarMosRecord[0];
                        poSpecObj.customer_plant_ref_id = plant_code.plant_code+'_'+mappedbuyerdivisionsMap.get(groupedMo.buyer_desc);
                        poSpecObj.style = groupedMo.style;
                        poSpecObj.schedule = groupedMo.schedule;
                        poSpecObj.color = groupedMo.color_name;
                        
                        let systematicPoCreationResponse = new SystematicPoCreationResponse();
                        systematicPoCreationResponse.mos = cumulatedSimilarMosRecord[1].toString();
                        systematicPoCreationResponse.style = groupedMo.style;
                        systematicPoCreationResponse.schedule = groupedMo.schedule;
                        systematicPoCreationResponse.color = groupedMo.color_name;
                        systematicPoCreationResponse.info = await this.comparingMoOpsAndOperationRoutingLevels(poSpecObj);
                        this.returnResult.push(systematicPoCreationResponse);
                    }
                }
            })).then(res=>{
                return this.returnResult;;
            }).catch(err=>{
                console.log(err);
                return null;
            });
        }catch(err){
            console.log(err);
            return null;
        }
    }  
    //This function will group the mos of a style,schedule,color based on operations 
    async cumulateMatchingMosWithOperations(manuOrderList:string,moWiseOpetrationsMap:Map<string,string>)
    :Promise<Map<string,string[]>>{
        try{
            const manuOrders = manuOrderList.split(',');
            const operationSeqMap = new Map<string,string[]>();
            manuOrders.map(manuOrder => {
                const opSequence:string = moWiseOpetrationsMap.get(manuOrder).replace(/\s/g,'');
                //Trimming the white spaces out of the operation codes 
                if(opSequence){
                    if(!operationSeqMap.has(opSequence)){
                        operationSeqMap.set(opSequence,[]);
                    }
                    operationSeqMap.get(opSequence).push(manuOrder);
                }
            });
            return operationSeqMap;
        }catch(err){
            console.log(err);
            return null;
        }
    }
    async comparingMoOpsAndOperationRoutingLevels(poSpecificationsObj : poSpecificationsObj):Promise<String>{
        const ComapnyandPlantref_no = poSpecificationsObj.customer_plant_ref_id;
        const split_to_plantref_no = poSpecificationsObj.customer_plant_ref_id.split("_");
        const plantref_no = split_to_plantref_no[0];
        const levelsobject = [ComapnyandPlantref_no,plantref_no,this.Global];
        return await this.verifyingOperationRoutingLevelExists(levelsobject).then(async (graphIdResponse)=>{
            if(graphIdResponse){
                return await this.graphroutingRepository.findOne({where:{graph_id:graphIdResponse},relations:this.graphRelations}).then((graphObj)=>{
                        const operationComparissionStatus = this.verifyingMoOperationsMatchesRoutingLevelOperations(graphObj,poSpecificationsObj.mo_operations)
                        if(operationComparissionStatus == operationsComparision.equal){
                                return this.createProductionOrder(poSpecificationsObj,graphObj)
                        }
                        else if(operationComparissionStatus == operationsComparision.greaterthan){
                            const moOperations = poSpecificationsObj.mo_operations.split(",");
                                const customGraph =  this.createCustomPOGraph(graphObj,moOperations)
                                if(customGraph){
                                    return this.createProductionOrder(poSpecificationsObj,customGraph)
                                }
                        }
                        else if(operationComparissionStatus == operationsComparision.lessthan){
                            // return operationsComparision.lessthan;
                            return "Level Operation Routing operations are less than the MO operations";
                        }
                    }).catch((err)=>{
                        return err.data;
                    });
            }else{
                return "No Level Found with Operation Routing";
            } 
        });
    }
    async verifyingOperationRoutingLevelExists(levelsobject : string[]):Promise<String>{
        for(let levelobj of levelsobject){
            try{
                const result =  await this.operarationroutingRepository.findOne({where:{unique_reference_id:levelobj},relations:["graph"]})
                if(result){
                    return result['graph']['graph_id'];
                }
            }
            catch(err){
                return err;
            }
        }
    }
    verifyingMoOperationsMatchesRoutingLevelOperations(graphObj:PpsGraph,mo_operations:string):String{
        const uniqueRoutingLevelOperations = new Set();
            graphObj.ppsGraphRoutings.forEach((routing)=>{
                uniqueRoutingLevelOperations.add(routing.from_operation);
                uniqueRoutingLevelOperations.add(routing.to_operation);
            })        
        const moOperations = mo_operations.split(",");
        for(let operationCode of moOperations){
            if(!uniqueRoutingLevelOperations.has(operationCode)){
                return operationsComparision.lessthan;
            }
        }
        if(uniqueRoutingLevelOperations.size > moOperations.length){
            return operationsComparision.greaterthan;
        }
        return operationsComparision.equal;
    }
    async createProductionOrder (poSpecificationsObj:poSpecificationsObj,resgraph:PpsGraph):Promise<string>{
        const mos = poSpecificationsObj.mos;
        const style = poSpecificationsObj.style;
        const schedule = poSpecificationsObj.schedule;
        const color = poSpecificationsObj.color;
        let poobj = new PoCreation();
        poobj.style = style;
        poobj.schedule = schedule;
        poobj.color = color;
        poobj.graph = resgraph;
        poobj.mo = mos;
        poobj.level = "Po";
        try{
            return this.poService.productionorderCreation(poobj).then((data)=>{
                return data;
            });
        }
        catch(err){
            return err;
        }
    }
    createCustomPOGraph(graphObj: PpsGraph, operationsList: string[]): PpsGraph{
        const parentList = new Map();
        const childList = new Map();

        // Loop through graph routing
        graphObj.ppsGraphRoutings.forEach(edge => {
            // if list doesn't have the edge then set the edge to array
            if (!parentList.has(edge.from_operation)) {
                parentList.set(edge.from_operation, []);
            }

            // push the edge as a value to the key in parent list
            (parentList.get(edge.from_operation) as string[]).push(edge.to_operation);

            // if list doesn't have the edge then set the edge to array
            if (!childList.has(edge.to_operation)) {
                childList.set(edge.to_operation, []);
            }

            // push the edge as a value to the key in child list
            (childList.get(edge.to_operation) as string[]).push(edge.from_operation);

        });
        
        const removedChilds: string[] = [];
        // Loop through the parent list keys
        for (const key of parentList.keys()) {
            // if the input list doesn't have the key
            if (!operationsList.includes(key)) {
                // get the length of childs for the key
                if (childList.get(key).length === 1) {
                    // get the parent of the child list
                    const parent = childList.get(key)[0];
                    // get the childs of the parent
                    const parentChilds = parentList.get(parent) as string[];
                    // getting index of the key and removing the key from childs of the parent
                    const index = parentChilds.indexOf(key);
                    if (index > -1) {
                        parentChilds.splice(index, 1);
                    }
                    // loop through the parent list for the key
                    (parentList.get(key) as string[]).forEach(child => {
                        // update the child to all the parents
                        parentChilds.push(child);
                        // get the list of parents from the child
                        const childParents = childList.get(child);
                        // getting index of the key and removing the key from child list
                        const currentindex = childParents.indexOf(key);
                        if (currentindex > -1) {
                            childParents.splice(currentindex, 1);
                        }
                        // update the parent to all the childs
                        childParents.push(parent);
                    });
                    // push the key to remove childs array
                    removedChilds.push(key);
                }
            }
        }

        // delete the removed keys from the parentlist
        removedChilds.forEach(key => {
            parentList.delete(key);
        });

        const newGraphObj = new PpsGraph();
        newGraphObj.ppsGraphRoutings = [];
        newGraphObj.root_operation = graphObj.root_operation;
        // create a graph using parent list
        for (const key of parentList.keys()) {
            const values = parentList.get(key);
            if (values.length > 1) {
                values.forEach(element => {
                    const graprouting = new PpsGraphRouting();
                    graprouting.from_operation = key;
                    graprouting.to_operation = element;
                    newGraphObj.ppsGraphRoutings.push(graprouting);
                });
            } else if (values.length === 1) {
                const graprouting = new PpsGraphRouting();
                graprouting.from_operation = key;
                graprouting.to_operation = values[0];
                newGraphObj.ppsGraphRoutings.push(graprouting);
            }
        }
        return newGraphObj;
    }
}
