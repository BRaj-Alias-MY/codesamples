import { Injectable } from '@nestjs/common';
import { Repository, DeepPartial } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { OperationSequenceRequest } from '../models/operation-sequence.request';
import { PpsGraph } from '../entities/pps_graph';
import { PpsOperationRouting } from '../entities/pps_operation_routing';

@Injectable()
export class OperationsGraphService {
      constructor(@InjectRepository(PpsGraph) private entity: Repository<PpsGraph>,
                  @InjectRepository(PpsOperationRouting) private operationRouting: Repository<PpsOperationRouting>) { }

      async createGraph(graph: DeepPartial<PpsGraph>): Promise<PpsGraph> {
            try {
                  return await this.entity.save({...graph});
            } catch (err) {
                  throw err;
            }
      }

      async createOperationSequence(operationSequenceData: OperationSequenceRequest): Promise<PpsOperationRouting> {
            try {
                  if (await this.checkOperationSequence(operationSequenceData.operationRouting.unique_reference_id)) {
                        throw 'data Already exist. please update the data.';
                  } else {
                        const graph = await this.createGraph(operationSequenceData.graph);
                        const operationSequence = operationSequenceData.operationRouting;
                        operationSequence.graph = graph;
                        operationSequence.isActive = true;
                        operationSequence.activated_date = new Date().toISOString().slice(0, 10);
                        return await this.operationRouting.save(operationSequence);
                  }
            } catch (err) {
                  return err;
            }
      }

      async updateOperationSequence(operationSequenceData: OperationSequenceRequest): Promise<PpsOperationRouting> {
            try {
                  const oldOperationSeq = await this.operationRouting.findOne({
                        unique_reference_id: operationSequenceData.operationRouting.unique_reference_id, isActive: true});
                  if (oldOperationSeq) {
                        oldOperationSeq.isActive = false;
                        await this.operationRouting.save(oldOperationSeq);
                        return await this.createOperationSequence(operationSequenceData);
                  } else {
                        return null;
                  }
            } catch ( err ) {
                  return null;
            }
      }

      async getGraph(graphId: string): Promise<PpsGraph> {
            const result = await this.entity.findOne({where: {graph_id: graphId}, relations: ['graphRoutings', 'graphRoutings.fromOperation',
            'graphRoutings.toOperation', 'graphLevels']});
            return result ? result : null;
      }

      async getAllGraphs(): Promise<PpsGraph[]> {
            const result = await this.entity.find({relations: ['graphRoutings', 'graphRoutings.fromOperation',
            'graphRoutings.toOperation', 'graphLevels']});
            return result.length > 0 ? result : null;
      }

      async checkOperationSequence(uniqueReferenceId: string): Promise<boolean> {
            const data = await this.operationRouting.findOne({unique_reference_id: uniqueReferenceId, isActive: true});
            return data ? true : false;
      }
}
