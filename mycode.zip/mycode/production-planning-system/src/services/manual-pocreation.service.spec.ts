import { Test, TestingModule } from '@nestjs/testing';
import { ManualpocreationService } from 'src/services/manual-pocreation.service';

describe('ManualpocreationService', () => {
  let service: ManualpocreationService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [ManualpocreationService],
    }).compile();

    service = module.get<ManualpocreationService>(ManualpocreationService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
