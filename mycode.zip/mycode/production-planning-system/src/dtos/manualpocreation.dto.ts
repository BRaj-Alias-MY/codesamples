import { ApiModelProperty } from "@nestjs/swagger";
import { PpsGraph } from "../entities/pps_graph";


export class PoCreation{
    @ApiModelProperty()
    style: string
    @ApiModelProperty()
    schedule: string
    @ApiModelProperty()
    color: string
    @ApiModelProperty()
    mo: string 
    @ApiModelProperty()
    level: string
    @ApiModelProperty()
    graph: PpsGraph 
}