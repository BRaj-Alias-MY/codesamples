import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {PpsGraph} from "./pps_graph";
import { ApiModelProperty } from "@nestjs/swagger";


@Entity("pps_graph_routing",{schema:"public" } )
@Index("fki_fk_graphrouting_graph",["graph",])
export class PpsGraphRouting {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"uid"
        })
    uid:string;
        
    @ApiModelProperty()
    @Column("character varying",{ 
        nullable:false,
        length:10,
        name:"from_operation"
        })
    from_operation:string;
        
    @ApiModelProperty()
    @Column("character varying",{ 
        nullable:false,
        length:10,
        name:"to_operation"
        })
    to_operation:string;
        

   
    @ManyToOne(type=>PpsGraph, pps_graph=>pps_graph.ppsGraphRoutings,{  nullable:false, })
    @JoinColumn({ name:'graph_id'})
    graph:PpsGraph | null;

}
