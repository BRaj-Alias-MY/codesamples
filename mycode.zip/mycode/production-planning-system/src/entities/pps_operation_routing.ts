import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {PpsGraph} from "./pps_graph";


@Entity("pps_operation_routing",{schema:"public" } )
@Index("REL_e7a2277a4caae2955ecc455d0a",["graph",],{unique:true})
@Index("fki_fk_graphlevel_graph",["graph",])
export class PpsOperationRouting {

    @Column("character varying",{ 
        nullable:false,
        length:20,
        name:"level"
        })
    level:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:100,
        name:"unique_reference_id"
        })
    unique_reference_id:string;
        

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"uid"
        })
    uid:string;
        

    @Column("boolean",{ 
        nullable:true,
        name:"isActive"
        })
    isActive:boolean | null;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

   
    @OneToOne(type=>PpsGraph, pps_graph=>pps_graph.ppsOperationRouting,{  nullable:false, })
    @JoinColumn({ name:'graph_id'})
    graph:PpsGraph | null;

}
