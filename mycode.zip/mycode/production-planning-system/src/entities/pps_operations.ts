import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import { ApiModelProperty} from "@nestjs/swagger";

export enum OperationType{
    Cut = 'Cut', 
    embellishment = 'embellishment', 
    sewing = 'sewing', 
    packing = 'packing',
}

export enum OperationCategory{
    Panel_Form = "Panel Form",
    Semi_Finished = 'Semi-Finished',
    Garment_Form = 'Garment Form',
    Carton_Form = 'Carton Form'
}


@Entity("pps_operations",{schema:"public" } )
export class PpsOperations {

    @ApiModelProperty()
    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:10,
        name:"operation_code"
        })
    operation_code:string;
    @ApiModelProperty()
    @Column("character varying",{ 
        nullable:false,
        length:20,
        name:"operation_name"
        })
    operation_name:string;
    
    @ApiModelProperty()
    @Column("character varying",{ 
        nullable:true,
        length:50,
        name:"operation_description"
        })
    operation_description:string | null;
        
    @ApiModelProperty()
    @Column("boolean",{ 
        nullable:false,
        name:"is_external_operation"
        })
    is_external_operation:boolean;
        
    @ApiModelProperty({enum:["Panel Form","Semi-Finished","Garment Form","Carton Form"]})
    @Column({
        type:"enum",
        enum:OperationCategory, 
        nullable:false,
        name:"operation_category"
        })
    operation_category:OperationCategory | null;
    
    @ApiModelProperty({enum:["Cut","embellishment", "sewing", "packing"]})
    @Column({ 
        type : "enum",
        enum:OperationType,
        nullable:false,
        name:"operation_type"
    })
    operation_type:OperationType | null;

    @Column("boolean",{ 
        nullable:false,
        name:"isActive"
        })
    isActive:boolean;

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        
    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;

        
}
