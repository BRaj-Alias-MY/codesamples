import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";


@Entity("pps_production_order",{schema:"public" } )
export class PpsProductionOrder {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"po_number"
        })
    po_number:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:40,
        name:"po_description"
        })
    po_description:string | null;
        
}
