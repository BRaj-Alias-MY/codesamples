import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {PpsGraphRouting} from "./pps_graph_routing";
import {PpsOperationRouting} from "./pps_operation_routing";
import { ApiModelProperty } from "@nestjs/swagger";


@Entity("pps_graph",{schema:"public" } )
export class PpsGraph {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"graph_id"
        })
    graph_id:string;
        
    @ApiModelProperty()
    @Column("character varying",{ 
        nullable:true,
        name:"root_operation"
        })
    root_operation:string | null;
        

    @ApiModelProperty({type: [PpsGraphRouting]})
    @OneToMany(type=>PpsGraphRouting, pps_graph_routing=>pps_graph_routing.graph, {cascade:true})
    ppsGraphRoutings:PpsGraphRouting[];
    

    
    @OneToOne(type=>PpsOperationRouting, pps_operation_routing=>pps_operation_routing.graph)
    ppsOperationRouting:PpsOperationRouting | null;

}
