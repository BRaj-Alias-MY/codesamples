import { Test, TestingModule } from '@nestjs/testing';
import { OperationsGraphService } from '../src/services/operations-graph.service';
import { InfrastructureModule } from '../src/infrastructure/infrastructure.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { OperationSequenceRequest } from '../src/models/operation-sequence.request';
import { PpsOperationRouting } from '../src/entities/pps_operation_routing';


describe('OperationsGraphService', () => {
  let service: OperationsGraphService;
  const operationSequenceRequest = new OperationSequenceRequest();
  const operationRouting = new PpsOperationRouting();

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports : [InfrastructureModule, TypeOrmModule.forRoot()],
    }).compile();

    service = module.get<OperationsGraphService>(OperationsGraphService);
  });

  it('should returns created graph data with operation routing.', async () => {
    expect(await service.createOperationSequence({graph:{root_operation: 'op1' ,ppsGraphRoutings:[{from_operation:'op1', to_operation:'op2'},{from_operation:'op2', to_operation: 'op3'}] }, operationRouting:{level:'Global', unique_reference_id: 'global'} })).toMatchObject(operationRouting);
  });

  it('should returns updated graph data with operation routing.', async () => {
    expect(await service.updateOperationSequence({graph:{root_operation: 'op1',ppsGraphRoutings:[{from_operation:'op1', to_operation: 'op2'},{from_operation:'op2', to_operation: 'op3'}] }, operationRouting:{level:'Global', unique_reference_id: 'global'} })).toMatchObject(operationRouting);
  });

});
