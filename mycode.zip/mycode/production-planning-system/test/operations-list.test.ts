import { Test, TestingModule } from '@nestjs/testing';
import { OperationsListService } from '../src/services/operations-list.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { InfrastructureModule } from '../src/infrastructure/infrastructure.module';
import { PpsOperations, OperationType, OperationCategory } from '../src/entities/pps_operations';

describe('OperationsListService', () => {
  let operationsListservice: OperationsListService;
  let operationsObj = new PpsOperations();
  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports :[InfrastructureModule,TypeOrmModule.forRoot()]
    }).compile();
    operationsListservice = module.get<OperationsListService>(OperationsListService);
  });
  it('should return the list of operations', async () => {
    expect(await operationsListservice.getAllOperations()).toMatchObject(operationsObj);
  });
  it('should return the operation details of given operationcode', async()=>{
    let operation_code = "15";
    expect(await operationsListservice.getOperation(operation_code)).toMatchObject(operationsObj);
  })
  it('should return operation details with given details if successfully created', async()=>{
     const operation_details = new PpsOperations();
     operation_details.operation_code = "100";
     operation_details.operation_name = "sewing";
     operation_details.operation_description = "sewingg";
     operation_details.operation_type= OperationType.sewing;
     operation_details.operation_category = OperationCategory.Garment_Form;
     operation_details.is_external_operation = false;

    expect(await operationsListservice.createOperation(operation_details)).toMatchObject(operationsObj);
  })
  it('should return updated opeartion details for given operation code', async()=>{
     const updatable_details = new PpsOperations();
     updatable_details.operation_code = "15";
     updatable_details.operation_name = "cuttings";
     updatable_details.operation_description = "cuttings";
     updatable_details.operation_type= OperationType.Cut;
     updatable_details.operation_category = OperationCategory.Panel_Form;
     updatable_details.is_external_operation = false;
     expect(await operationsListservice.createOperation(updatable_details)).toMatchObject(operationsObj);
  })
  it('should return deactivated operation details after deactivating for given operation code', async()=>{
    let operation_code = "15";
    expect(await operationsListservice.deActivateOperation(operation_code)).toMatchObject(operationsObj);
  })

});
