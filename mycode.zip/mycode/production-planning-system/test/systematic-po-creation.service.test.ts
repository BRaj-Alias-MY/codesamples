import { Test, TestingModule } from '@nestjs/testing';
import { InfrastructureModule } from '../src/infrastructure/infrastructure.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SystematicPoCreationService } from '../src/services/systematic-po-creation.service';
import { PpsGraph } from '../src/entities/pps_graph';
import { PpsGraphRouting } from '../src/entities/pps_graph_routing';
import { BuyerMappings } from '../src/models/cms-services.response';
import { StyleScheduleColorGroupedMos,MoWiseOperations } from '../src/models/oms-services.response';
import { PlantCode } from '../src/models/oms-services.request';
describe('SystematicPoCreation', () => {
    let poService: SystematicPoCreationService;

    beforeAll(async () => {
        const module: TestingModule = await Test.createTestingModule({
        imports : [InfrastructureModule, TypeOrmModule.forRoot()],
        }).compile();

        poService = module.get<SystematicPoCreationService>(SystematicPoCreationService);
    });

    it('should return a constructed graph with root operation and operation routing with all the operations', async () => {
        const resultObj = {
            ppsGraphRoutings:
             [ { from_operation: '10', to_operation: '20' },
               { from_operation: '20', to_operation: '30' },
               { from_operation: '20', to_operation: '40' },
               { from_operation: '30', to_operation: '50' },
               { from_operation: '40', to_operation: '50' } ],
            root_operation: '10' };

        const operations = ['10', '20', '30', '40', '50'];
        const graphObj = new PpsGraph();
        const graphRouting = new PpsGraphRouting();
        graphObj.ppsGraphRoutings = [];
        graphObj.root_operation = '10';
        graphRouting.from_operation = '10';
        graphRouting.to_operation = '20';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '20';
        graphRouting.to_operation = '30';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '20';
        graphRouting.to_operation = '40';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '30';
        graphRouting.to_operation = '50';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '40';
        graphRouting.to_operation = '50';
        graphObj.ppsGraphRoutings.push({...graphRouting});

        expect(await poService.createCustomPOGraph(graphObj, operations)).toMatchObject(resultObj);
    });

    it('should return a constructed graph with root operation and operation routing with operations which are available in routing.', async () => {
        const resultObj = {
            ppsGraphRoutings:
             [ { from_operation: '10', to_operation: '20' },
               { from_operation: '20', to_operation: '40' },
               { from_operation: '20', to_operation: '50' },
               { from_operation: '40', to_operation: '50' } ],
            root_operation: '10' };

        const operations = ['10', '20', '30', '40', '50'];
        const graphObj = new PpsGraph();
        const graphRouting = new PpsGraphRouting();
        graphObj.ppsGraphRoutings = [];
        graphObj.root_operation = '10';
        graphRouting.from_operation = '10';
        graphRouting.to_operation = '20';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '20';
        graphRouting.to_operation = '60';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '20';
        graphRouting.to_operation = '40';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '60';
        graphRouting.to_operation = '50';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '40';
        graphRouting.to_operation = '50';
        graphObj.ppsGraphRoutings.push({...graphRouting});

        expect(await poService.createCustomPOGraph(graphObj, operations)).toMatchObject(resultObj);
    });

    it('should return a constructed graph with root operation and operation routing with operations which are available in routing.', async () => {
        const resultObj = {
            ppsGraphRoutings:
             [ { from_operation: '10', to_operation: '20' },
               { from_operation: '20', to_operation: '40' },
               { from_operation: '20', to_operation: '50' },
               { from_operation: '40', to_operation: '50' } ],
            root_operation: '10' };

        const operations = ['10', '20', '30', '40', '50'];
        const graphObj = new PpsGraph();
        const graphRouting = new PpsGraphRouting();
        graphObj.ppsGraphRoutings = [];
        graphObj.root_operation = '10';
        graphRouting.from_operation = '10';
        graphRouting.to_operation = '20';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '20';
        graphRouting.to_operation = '60';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '20';
        graphRouting.to_operation = '40';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '60';
        graphRouting.to_operation = '50';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '40';
        graphRouting.to_operation = '50';
        graphObj.ppsGraphRoutings.push({...graphRouting});
        graphRouting.from_operation = '50';
        graphRouting.to_operation = '70';
        graphObj.ppsGraphRoutings.push({...graphRouting});

        expect(await poService.createCustomPOGraph(graphObj, operations)).toMatchObject(resultObj);
    });

    it('should return All the mapped Buyer Divisions', async () => {
        const resObject = new BuyerMappings;
        expect(await poService.loadMappedBuyerDivisions()).toMatchObject(resObject);
    });

    it('should return All the MoNumber grouped Operations for the given plant code', async () => {
        const plant_code = new PlantCode;
        const resObject = new MoWiseOperations;
        plant_code.plant_code = 'EKG';
        expect(await poService.loadMoWiseOperations(plant_code)).toMatchObject(resObject);
    });

    it('should return All the MoNumbers grouped by style,schedule and color for the given plant code', async () => {
        const plant_code = new PlantCode;
        const resObject = new StyleScheduleColorGroupedMos;
        plant_code.plant_code = 'EKG';
        expect(await poService.loadStyleScheduleColorGroupedMos(plant_code)).toMatchObject(resObject);
    });

    it('should return All the MoNumbers grouped by style,schedule and color', async () => {
        let resObject : Map<string,string[]>;
        let moWiseOpetrationsMap = new Map();
        const manuOrderList = 'mo1,mo2,mo3,mo4';
        moWiseOpetrationsMap.set('mo1','10,20,30');
        moWiseOpetrationsMap.set('mo2','10,20,30,200');
        moWiseOpetrationsMap.set('mo3','10,20,30');
        moWiseOpetrationsMap.set('mo4','10,20,30,50');
        moWiseOpetrationsMap.set('mo5','10,20,30,40');

        expect(await poService.cumulateMatchingMosWithOperations(manuOrderList,moWiseOpetrationsMap)).toMatchObject(resObject);
    });

});
