import {customerDTO} from 'src/dtos/customer.dto';
import { ApiModelProperty } from '@nestjs/swagger';

export class CustomerRequest {
    @ApiModelProperty()
    customer_code: string;
}