
import { CmsCustomer } from '../entities/cms_customer';
import { BuyerMappingDto } from '../dtos/buyer-mapping.dto';

export class AllCustomersResponse{
    status : boolean;
    errInfo ?: string;
    data ?:  CmsCustomer[];
}

export class AllBuyerDivisionsResponse{
    status : boolean;
    errInfo ?: string;
    data ?:  any;
}

export class BuyerMappingResponse{
    status : boolean;
    errInfo ?: string;
    data ?:  BuyerMappingDto[];
}

export class BuyerMappings{
    buyer_division :string;
    customer_name : string;
}

