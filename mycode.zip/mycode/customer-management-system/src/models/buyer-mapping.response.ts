import { BuyerMappingDto } from '../dtos/buyer-mapping.dto';
import { CmsCustomer } from '../entities/cms_customer';

export class AllCustomersResponse {
  status: boolean;
  errInfo?: string;
  data?: CmsCustomer[];
}

export class AllBuyerDivisionsResponse {
  status: boolean;
  errInfo?: string;
  data?: any;
}

export class BuyerMappingResponse {
  status: boolean;
  errInfo?: string;
  data?: BuyerMappingDto[];
}
