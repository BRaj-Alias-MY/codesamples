import {CmsCustomer} from 'src/entities/cms_customer';
import {customerDTO} from 'src/dtos/customer.dto';

export class CustomerCreateResponse {
    status: boolean;
    data?: customerDTO;
    errorInfo?: string;
}

export class GetCustomersResponse {
    status: boolean;
    data?: customerDTO[];
    errorInfo?: string;
}

export class GetCustomerResponse {
    status: boolean;
    data?: boolean;
    errorInfo?: string;
}
