import { BuyerMappingDto } from '../dtos/buyer-mapping.dto';
import { CmsBuyerMapping } from '../entities/cms_buyer_mapping';
import { CmsCustomer } from '../entities/cms_customer';
import { Injectable } from '@nestjs/common';

@Injectable()
export class BuyerMappingAdapter {
  public convertDtoToEntity(buyerMappingDto: BuyerMappingDto): CmsBuyerMapping {
    let buyerMappingEntity = new CmsBuyerMapping();
    buyerMappingEntity.buyer_division = buyerMappingDto.buyer_division;
    buyerMappingEntity.customerCode = new CmsCustomer();
    buyerMappingEntity.customerCode.customer_code =
      buyerMappingDto.customer_code;
    buyerMappingEntity.isActive = true;
    return buyerMappingEntity;
  }

  public convertEntityToDto(
    buyerMappingEntity: CmsBuyerMapping,
  ): BuyerMappingDto {
    let buyerMappingrResponseDto = new BuyerMappingDto();
    buyerMappingrResponseDto.buyer_division = buyerMappingEntity.buyer_division;
    buyerMappingrResponseDto.customer_code =
      buyerMappingEntity.customerCode.customer_code;
    buyerMappingrResponseDto.customer_name =
      buyerMappingEntity.customerCode.customer_name;
    buyerMappingrResponseDto.isActive = buyerMappingEntity.isActive;
    buyerMappingrResponseDto.activatedDate = buyerMappingEntity.activated_date;
    if (!buyerMappingrResponseDto.isActive)
      buyerMappingrResponseDto.deActivatedDate =
        buyerMappingEntity.deactivated_date;

    return buyerMappingrResponseDto;
  }
}
