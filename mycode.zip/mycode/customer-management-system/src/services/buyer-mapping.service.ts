
import { getRepository } from 'typeorm';
import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository} from 'typeorm';
import { BuyerMappings } from "../models/buyerMapping.response";
import { BuyerMappingAdapter } from '../adapters/buyer-mapping.adapter';
import { BuyerMappingDto } from '../dtos/buyer-mapping.dto';
import { CmsBuyerMapping } from '../entities/cms_buyer_mapping';
import { CmsCustomer } from '../entities/cms_customer';
import { MoBuyermapping } from '../clients/oms_buyer_client';
import { BuyerMappingRequest } from './../models/buyer-mapping.request';

@Injectable()
export class BuyerMappingService {
    constructor(@InjectRepository(CmsBuyerMapping) private buyerMapping: Repository<CmsBuyerMapping>,
                @InjectRepository(CmsCustomer) private customer: Repository<CmsCustomer>,
                private buyerMappingAdapter: BuyerMappingAdapter,
                private MoBuyermappingclient: MoBuyermapping){
          //Do Nothing
    }

    async checkIfBuyerMappingExist(buyer_division: string): Promise<boolean> {
        const isMapped = await this.buyerMapping.find({ where:{buyer_division:buyer_division,isActive:true} });
        if (isMapped.length) return true;else return false;
    }

    async checkIfCustomerMapped(customer_code: string): Promise<boolean> {
        const isMapped = await this.buyerMapping.find({where: { customerCode: customer_code } });
        if (isMapped.length) return true; else return false;
    }

    async checkIfCustomerExist(customer_code: string): Promise<boolean> {
        const isExist = await this.customer.find({where: { customer_code: customer_code } });
        if (isExist.length) return true; else return false;
    }

    async checkIfBuyerDivisionExist(buyer_divison: string) {
        const buyerMappingRequest = new BuyerMappingRequest;
        buyerMappingRequest.buyer_division = buyer_divison;
        return await this.MoBuyermappingclient.checkBuyerDivisionExist(buyerMappingRequest);
    }
    

    async getBuyerMapping(buyer_division : string):Promise<BuyerMappingDto[]>{
        return await this.buyerMapping.findOne({where:{'buyer_division':buyer_division},relations:["customerCode"]}).then(buyer_mapping=>{
            if(buyer_mapping){
                return this.buyerMappingAdapter.convertEntityToDto(buyer_mapping);
            }else{
                return null;
            }
        }).catch(err=>{
            return null;
        });
    }

    async getAllBuyerMappings():Promise<BuyerMappingDto[]>{
        return await this.buyerMapping.find({relations:["customerCode"]}).then(buyer_mappings=>{
            if(buyer_mappings){
                return buyer_mappings.map(buyer_mapping => {
                    return this.buyerMappingAdapter.convertEntityToDto(buyer_mapping);
                }); 
            }else{
                return null;
            }
        }).catch(err=>{
            return null;
        });
    }

    async createBuyerMapping(buyer_map : BuyerMappingDto):Promise<BuyerMappingDto[]>{
        const activatedDate = new Date().toISOString().slice(0, 10);
        const buyerMappingEntity = this.buyerMappingAdapter.convertDtoToEntity(buyer_map);
        buyerMappingEntity.activated_date = activatedDate;
        return  this.buyerMapping.save(buyerMappingEntity).then(res=>{
            return this.buyerMappingAdapter.convertEntityToDto(res);
        }).catch(err=>{
            return null;
        });
    }

    async deActivateBuyerMapping(buyer_division : string):Promise<boolean>{
        const deActivatedDate = new Date().toISOString().slice(0, 10);
        return await this.buyerMapping.update({buyer_division:buyer_division,isActive:true},
            {isActive:false,deactivated_date:deActivatedDate}
        ).then(res=>{
            return true;
        }).catch(err=>{
            return false;
        });
    }

    //This function is for the pps(systematic production order) for getting the customer name for the buyer_desc
    async loadMappedBuyerDivisions(): Promise<BuyerMappings[]> {
        try {
            const cmsBuyerMapppings = await getRepository(CmsBuyerMapping)
              .createQueryBuilder('cms_buyer_mapping')
              .select('buyer_division,customer_name')
              .leftJoin('cms_buyer_mapping.customerCode', 'customer')
              .getRawMany();
            return cmsBuyerMapppings;
        } catch (err) {
            console.log(err);
            return null;
        }
    }
}
