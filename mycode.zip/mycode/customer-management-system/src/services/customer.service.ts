import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import {CmsCustomer} from 'src/entities/cms_customer';
import {customerDTO} from 'src/dtos/customer.dto';
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm';
import {CustomerCreateResponse,GetCustomersResponse} from 'src/models/customer.response';

import { Repository } from 'typeorm';


@Injectable()
export class CustomerService {

    constructor(@InjectRepository(CmsCustomer)   private customerRepository : Repository<CmsCustomer>){

    }

    async verifyCustomer(customercode : String):Promise<Boolean>{
            const customer = await this.customerRepository.findOne({where:{customer_code:customercode} });
            return customer ? true : false;
    }

    async createCustomer(sectiondata: customerDTO):Promise<customerDTO>{
        try{
            const createddate = new Date().toISOString().slice(0, 10);
            const savecustomer = {...sectiondata, created_date : createddate};
            const response = await this.customerRepository.save(savecustomer);
            return response;
          } catch(error){
            return error;
        }
    } 

    async getAllCustomers():Promise<customerDTO[]>{
            const customers = await this.customerRepository.find({order:{customer_name:"ASC"}});
            return customers;
    }

    async deActivateCustomer(customername:string):Promise<boolean>{
            const deactivateddate = new Date().toISOString().slice(0, 10);
            const obj =  await this.customerRepository.update({customer_code:customername},{isActive:false, deactivated_date : deactivateddate})
            return obj ? true : false;
    }

    async getCustomer (customerdata:string):Promise<customerDTO>{
            return await this.customerRepository.findOne({where:{customer_code:customerdata}});
    }


}
