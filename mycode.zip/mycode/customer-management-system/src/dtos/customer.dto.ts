import { ApiModelProperty } from '@nestjs/swagger';

export class customerDTO{

    @ApiModelProperty()
    customer_code: string;
    @ApiModelProperty()
    customer_name: string;
    @ApiModelProperty()
    customer_description: string;
    @ApiModelProperty()
    isActive: boolean;
   
}