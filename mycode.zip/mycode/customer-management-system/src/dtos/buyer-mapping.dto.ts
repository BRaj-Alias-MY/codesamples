import { ApiModelProperty } from '@nestjs/swagger';
import { IsString, IsBoolean, IsDate } from 'class-validator';

export class BuyerMappingDto{
    @ApiModelProperty()
    @IsString()
    buyer_division : string;
    @ApiModelProperty()
    @IsString()
    customer_code : string;
    @IsString()
    customer_name : string;
    @ApiModelProperty()
    @IsBoolean()
    isActive ?: boolean;
    @ApiModelProperty()
    @IsDate()
    activatedDate ?: string;
    @ApiModelProperty()
    @IsDate()
    deActivatedDate ?: string;
}
