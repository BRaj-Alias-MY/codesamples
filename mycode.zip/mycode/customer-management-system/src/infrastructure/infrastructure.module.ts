import { BuyerMappingAdapter } from '../adapters/buyer-mapping.adapter';
import { BuyerMappingController } from '../controllers/buyer-mapping.controller';
import { BuyerMappingService } from '../services/buyer-mapping.service';
import { CmsBuyerMapping } from '../entities/cms_buyer_mapping';
import { CmsCustomer } from '../entities/cms_customer';
import { CustomerController } from '../controllers/customer.controller';
import { CustomerService } from '../services/customer.service';
import { MoBuyermapping } from '../clients/oms_buyer_client';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';


@Module({
  imports: [TypeOrmModule.forFeature([CmsCustomer, CmsBuyerMapping])],
  controllers: [BuyerMappingController, CustomerController],
  providers: [
    BuyerMappingAdapter,
    BuyerMappingService,
    CustomerService,
    MoBuyermapping,
  ],
})
export class InfrastructureModule {}
