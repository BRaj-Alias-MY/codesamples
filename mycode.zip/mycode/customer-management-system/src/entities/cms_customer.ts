import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {CmsBuyerMapping} from "./cms_buyer_mapping";


@Entity("cms_customer",{schema:"public" } )
@Index("customer_name",["customer_name",],{unique:true})
export class CmsCustomer {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:10,
        name:"customer_code"
        })
    customer_code:string;
        

    @Column("character varying",{ 
        nullable:false,
        unique: true,
        length:20,
        name:"customer_name"
        })
    customer_name:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:40,
        name:"customer_description"
        })
    customer_description:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"created_date"
        })
    created_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:true,
        default: () => "true",
        name:"isActive"
        })
    isActive:boolean | null;
        

   
    @OneToMany(type=>CmsBuyerMapping, cms_buyer_mapping=>cms_buyer_mapping.customerCode)
    cmsBuyerMappings:CmsBuyerMapping[];
    
}
