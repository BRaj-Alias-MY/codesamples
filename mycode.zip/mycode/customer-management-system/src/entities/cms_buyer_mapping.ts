import {
  BaseEntity,
  Column,
  Entity,
  Index,
  JoinColumn,
  JoinTable,
  ManyToMany,
  ManyToOne,
  OneToMany,
  OneToOne,
  PrimaryColumn,
  PrimaryGeneratedColumn,
  RelationId,
} from 'typeorm';
import { CmsCustomer } from './cms_customer';

@Entity('cms_buyer_mapping', { schema: 'public' })
@Index('fki_customer_buyer_fk', ['customerCode'])
export class CmsBuyerMapping {
  @Column('uuid', {
    nullable: false,
    primary: true,
    default: () => 'uuid_generate_v4()',
    name: 'uid',
  })
  uid: string;

  @Column('character varying', {
    nullable: false,
    length: 40,
    name: 'buyer_division',
  })
  buyer_division: string;

  @Column('boolean', {
    nullable: true,
    name: 'isActive',
  })
  isActive: boolean | null;

  @Column('date', {
    nullable: true,
    name: 'activated_date',
  })
  activated_date: string | null;

  @Column('date', {
    nullable: true,
    name: 'deactivated_date',
  })
  deactivated_date: string | null;

  @ManyToOne(
    type => CmsCustomer,
    cms_customer => cms_customer.cmsBuyerMappings,
    { nullable: false },
  )
  @JoinColumn({ name: 'customer_code' })
  customerCode: CmsCustomer | null;
}
