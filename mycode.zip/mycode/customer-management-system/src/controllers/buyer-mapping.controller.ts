import { Controller } from '@nestjs/common';
import { Post, Body, Get } from '@nestjs/common';
import { BuyerMappingService } from '../services/buyer-mapping.service';
import { BuyerMappingDto } from '../dtos/buyer-mapping.dto';
import { BuyerMappingRequest } from '../models/buyer-mapping.request';
import { BuyerMappingResponse } from '../models/buyer-mapping.response';
import { BuyerMappings } from "../models/buyerMapping.response";

@Controller('buyerMapping')
export class BuyerMappingController {
    constructor(private buyerMappingService: BuyerMappingService) {
      //Do Nothing
    }

    @Post('/getBuyerMapping')
    async getBuyerMapping(@Body() buyer_map: BuyerMappingRequest): Promise<BuyerMappingResponse> {
        const buyerMappingResponse = new BuyerMappingResponse();
        try{
            const buyer_mapping = await this.buyerMappingService.getBuyerMapping(buyer_map.buyer_division);
            if (buyer_mapping) {
                buyerMappingResponse.status = true;
                buyerMappingResponse.data = buyer_mapping;
            } else {
                buyerMappingResponse.status = false;
                buyerMappingResponse.errInfo = 'No Buyer Mapping Does Not Exist';
            }
            return buyerMappingResponse;
        }catch (err) {
            console.log(err);
            buyerMappingResponse.status = false;
            buyerMappingResponse.errInfo ='Error Occured While Finding Buyer Mapping';
            return buyerMappingResponse;
        }
    }

    @Post('/createBuyerMapping')
    async createBuyerMapping(@Body() buyer_map : BuyerMappingDto):Promise<BuyerMappingResponse>{
        const buyerMappingResponse = new BuyerMappingResponse();
        const isMappingExist = await this.buyerMappingService.checkIfBuyerMappingExist(buyer_map.buyer_division);
        const isDivisionExist = await this.buyerMappingService.checkIfBuyerDivisionExist(buyer_map.buyer_division);
        const isCustomerExist = await this.buyerMappingService.checkIfCustomerExist(buyer_map.customer_code);
        if(!isDivisionExist){
            buyerMappingResponse.status = false;
            buyerMappingResponse.errInfo = "Buyer Division Does Not Exist";
            return buyerMappingResponse;
        } 
        if(!isCustomerExist){
            buyerMappingResponse.status = false;
            buyerMappingResponse.errInfo = "Customer Does Not Exist";
            return buyerMappingResponse;
        }
        if(!isMappingExist){
            try{
                const buyer_mapping = await this.buyerMappingService.createBuyerMapping(buyer_map);
                if(buyer_mapping){
                    buyerMappingResponse.status = true;
                    buyerMappingResponse.data = buyer_mapping;
                }else{
                    buyerMappingResponse.status = false;
                    buyerMappingResponse.errInfo = "Unable to save the buyer mapping";
                }
                return buyerMappingResponse;
            }catch(err){
                buyerMappingResponse.status = false;
                buyerMappingResponse.errInfo = "Problem Occured While Mapping Buyer Division";
                return buyerMappingResponse;
            }
        }else{
            buyerMappingResponse.status = false;
            buyerMappingResponse.errInfo = "Buyer Division Already Mapped";
            return buyerMappingResponse;
        }
    }

    @Post('/getAllBuyerMappings')
    async getAllBuyerMappings(): Promise<BuyerMappingResponse> {
        const buyerMappingResponse = new BuyerMappingResponse();
        try {
            const buyer_mappings = await this.buyerMappingService.getAllBuyerMappings();
            if (buyer_mappings.length) {
                buyerMappingResponse.data = buyer_mappings;
                buyerMappingResponse.status = true;
            }else{
                buyerMappingResponse.status = false;
                buyerMappingResponse.errInfo = 'No Buyer Division Mappings Found';
            }
            return buyerMappingResponse;
        } catch (err) {
            buyerMappingResponse.status = false;
            buyerMappingResponse.errInfo = 'Error While Getting Buyer Division Mappings';
          return buyerMappingResponse;
        }
    }


    @Post('/deActivateBuyerMapping')
    async deActivateBuyerMapping(@Body() buyer_map: BuyerMappingRequest): Promise<BuyerMappingResponse> {
        const buyerMappingResponse = new BuyerMappingResponse();
        const isMappingExist = await this.buyerMappingService.checkIfBuyerMappingExist(buyer_map.buyer_division);
        if(isMappingExist){
            try {
                const deActivated = await this.buyerMappingService.deActivateBuyerMapping(buyer_map.buyer_division);
                if(deActivated){
                    buyerMappingResponse.status = true;
                }else{
                    buyerMappingResponse.status = false;
                    buyerMappingResponse.errInfo = 'Buyer Mappping Not De-Activated';
                }
                return buyerMappingResponse;
            }catch(err){
                buyerMappingResponse.status = false;
                buyerMappingResponse.errInfo = 'Error Occured While De-Activating';
                return buyerMappingResponse;
            }
        }else{
            buyerMappingResponse.status = false;
            buyerMappingResponse.errInfo = 'Buyer Division Mapping Does Not Exist to Delete';
            return buyerMappingResponse;
        }
    }

    //This function is for the pps(systematic production order) for getting the customer name for the buyer_desc
    @Post('/loadMappedBuyerDivisions')
    async loadMappedBuyerDivisions():Promise<BuyerMappings[]>{
        try{
            return await this.buyerMappingService.loadMappedBuyerDivisions();
        }catch(err){
            console.log(err);
            return null;
        }
    }
}
