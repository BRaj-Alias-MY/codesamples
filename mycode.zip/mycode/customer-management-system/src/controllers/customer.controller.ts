import { Controller,Logger, Post,Body } from '@nestjs/common';
import {CmsCustomer} from 'src/entities/cms_customer';
import {customerDTO} from 'src/dtos/customer.dto';
import {CustomerService} from 'src/services/customer.service';
import {CustomerCreateResponse,GetCustomersResponse} from 'src/models/customer.response';
import {CustomerRequest} from 'src/models/customer.request';
import {BuyerMappingService} from 'src/services/buyer-mapping.service';

@Controller('customer')
export class CustomerController {

    private logger = new Logger('CustomerController')
     constructor(private customerservice : CustomerService,  private buyermappingservice : BuyerMappingService ){

     }

     @Post('/createCustomer')
     async createCustomer(@Body()  customerdata: customerDTO) {
        const verifycustomer = await this.customerservice.verifyCustomer(customerdata.customer_code);
       if(!verifycustomer){
        return await this.customerservice.createCustomer(customerdata).then((response)=>{
            const response_obj = new CustomerCreateResponse();
            response_obj.errorInfo = "success";
            response_obj.data = response;
            response_obj.status=true;
            return response_obj;
        }).catch((err)=>{
            const response_obj = new CustomerCreateResponse();
            response_obj.errorInfo = "failed";
            response_obj.status=false;
            return response_obj;
        })
       }
       else{
            const response_obj = new CustomerCreateResponse();
            response_obj.errorInfo = "Customer Already Exist";
            response_obj.status=false;
            return response_obj;
       }

       
    }

    @Post('/updateCustomer')
    async updateCustomer(@Body() customerdata: customerDTO) {
            const verifycustomer = await this.customerservice.verifyCustomer(customerdata.customer_code);
            const customermapped = await this.buyermappingservice.checkIfCustomerMapped(customerdata.customer_code); 
        if(verifycustomer)
        {
        if(customermapped){
            const response_obj = new CustomerCreateResponse();
            response_obj.errorInfo = "Customer is Already Mapped";
            response_obj.status=false;
            return response_obj;
        }else{
            return await this.customerservice.createCustomer(customerdata).then((response)=>{
            const response_obj = new CustomerCreateResponse();
            response_obj.errorInfo = "Updated Sucessfully";
            response_obj.status=true;
            response_obj.data = response;
            return response_obj;
            }).catch((err)=>{
            const response_obj = new CustomerCreateResponse();
            response_obj.errorInfo = "failed";
            response_obj.status=false;
            return response_obj;
            })
          } 
       }else{
            const response_obj = new CustomerCreateResponse();
            response_obj.errorInfo = "NO Customer Found";
            response_obj.status=false;
            return response_obj;
       }
            
    }

    @Post('/getAllCustomers')
    async getAllCustomers(): Promise<GetCustomersResponse> {
            const response = new GetCustomersResponse();
            const obj = await this.customerservice.getAllCustomers();
        if (obj.length > 0) {
            response.status = true;
            response.data  =  obj;
            return response;
        } else {
            response.status = false;
            response.errorInfo = "No Data Found";
            return response;
        }
    } 

    @Post('/deActivateCustomer')
    async deActivateCustomer(@Body() customerinfo: CustomerRequest)
    {
            const response_obj = new CustomerCreateResponse();
            const verifycustomer = await this.customerservice.verifyCustomer(customerinfo.customer_code);
        if (verifycustomer) {
            return await this.customerservice.deActivateCustomer(customerinfo.customer_code).then((response)=>{
            response_obj.errorInfo = "De-Activated Sucessfully";
            response_obj.status=true;
            return response_obj;
            }).catch((err)=>{
            response_obj.errorInfo = "failed";
            response_obj.status=false;
            return response_obj;
            })
        } else {
            response_obj.status = false;
            response_obj.errorInfo = 'Customer not found.';
            return response_obj;
        } 
    }

    @Post('/getCustomer')
    async getCustomer(@Body() customerinfo : CustomerRequest):Promise<CustomerCreateResponse> {
            const response = new CustomerCreateResponse();
            const verifycustomer = await this.customerservice.verifyCustomer(customerinfo.customer_code);
        if (verifycustomer) {
            const obj = await this.customerservice.getCustomer(customerinfo.customer_code);
            response.status = true;
            response.data = obj;
            return response;
        } else {
            response.status = false;
            response.errorInfo = 'Customer Not Found.';
            return response;
        }
    }


      



}
