import { Injectable } from '@nestjs/common';
import { BuyerMappingRequest } from 'src/models/buyer-mapping.request';
import axios from 'axios';

@Injectable()
export class MoBuyermapping {
    async checkBuyerDivisionExist(buyermap: BuyerMappingRequest): Promise<boolean> {
        const oms_base_url = process.env.PO_UPDATE_URL;
        const buyer_map = buyermap.buyer_division;
        return await axios.post(oms_base_url, { buyer_division: buyer_map }).then(res => {
          return res.data;
        }).catch(err => {
            return false;
        });
    }
}
