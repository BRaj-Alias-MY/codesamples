import { BuyerMappingDto } from '../src/dtos/buyer-mapping.dto';
import { BuyerMappingService } from '../src/services/buyer-mapping.service';
import { CmsBuyerMapping } from '../src/entities/cms_buyer_mapping';
import { CmsCustomer } from '../src/entities/cms_customer';
import { InfrastructureModule } from '../src/infrastructure/infrastructure.module';
import { Test, TestingModule } from '@nestjs/testing';
import { TypeOrmModule } from '@nestjs/typeorm';


describe('BuyerMappingService', () => {
  let buyerMappingService: BuyerMappingService;
  let buyerMappingRequestDto = new BuyerMappingDto();
  let customers = new CmsCustomer();
  let buyer_mapping = new CmsBuyerMapping();

  beforeAll(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [InfrastructureModule, TypeOrmModule.forRoot()],
    }).compile();
    buyerMappingService = module.get<BuyerMappingService>(BuyerMappingService);
  });

  it('should return the list of Buyer Mappings', async () => {
    expect(await buyerMappingService.getAllBuyerMappings()).toMatchObject(
      buyer_mapping,
    );
  });

  it('should return true if the buyer mapping is de activated', async () => {
    const buyer_division = 'buyer div 1';
    expect(
      await buyerMappingService.deActivateBuyerMapping(buyer_division),
    ).toBeTruthy();
  });

  it('should return mapped buyer division if the buyer mapping is created', async () => {
    buyerMappingRequestDto.buyer_division = 'buyer div 1';
    buyerMappingRequestDto.customer_code = 'customer 1';
    expect(
      await buyerMappingService.createBuyerMapping(buyerMappingRequestDto),
    ).toMatchObject(buyer_mapping);
  });
});
