import { CmsBuyerMapping } from 'src/entities/cms_buyer_mapping';
import { CmsCustomer } from 'src/entities/cms_customer';
import { customerDTO } from 'src/dtos/customer.dto';
import { CustomerService } from 'src/services/customer.service';
import { InfrastructureModule } from '../src/infrastructure/infrastructure.module';
import { Test, TestingModule } from '@nestjs/testing';
import { TypeOrmModule } from '@nestjs/typeorm';


describe('CustomerService', () => {
  let service: CustomerService;
  let customerdto = new customerDTO();
  let customers = new CmsCustomer();

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      imports: [InfrastructureModule, TypeOrmModule.forRoot()],
    }).compile();
    service = module.get<CustomerService>(CustomerService);
  });

  it('should return the list of Customers', async () => {
    expect(await service.getAllCustomers()).toMatchObject(customers);
  });
  it('should return true if the customer is de activated', async () => {
    const customername = 'cus1';
    expect(await service.deActivateCustomer(customername)).toBeTruthy();
  });

  it('should return Customer if the new customer is created', async () => {
    expect(await service.createCustomer(customerdto)).toMatchObject(customers);
  });
});
