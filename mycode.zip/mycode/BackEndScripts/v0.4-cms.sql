-- Table: public.cms_customer

-- DROP TABLE public.cms_customer;

CREATE TABLE public.cms_customer
(
    customer_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    customer_name character varying(20) COLLATE pg_catalog."default" NOT NULL,
    customer_description character varying(40) COLLATE pg_catalog."default",
    created_date date,
    deactivated_date date,
    "isActive" boolean DEFAULT true,
    CONSTRAINT cms_customer_pkey PRIMARY KEY (customer_code),
    CONSTRAINT customer_name UNIQUE (customer_name)

)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.cms_customer
    OWNER to postgres;
-- Table: public.cms_buyer_mapping

-- DROP TABLE public.cms_buyer_mapping;

CREATE TABLE public.cms_buyer_mapping
(
  buyer_division character varying(40) NOT NULL,
  "isActive" boolean,
  activated_date date,
  deactivated_date date,
  customer_code character varying(10) NOT NULL,
  uid integer NOT NULL DEFAULT nextval('cms_buyer_mapping_uid_seq'::regclass),
  CONSTRAINT pk_buyer_mapping PRIMARY KEY (uid),
  CONSTRAINT fk_customer_buyer FOREIGN KEY (customer_code)
      REFERENCES public.cms_customer (customer_code) MATCH SIMPLE
      ON UPDATE NO ACTION ON DELETE NO ACTION
)
WITH (
  OIDS=FALSE
);
ALTER TABLE public.cms_buyer_mapping
  OWNER TO postgres;

-- Index: public.fki_customer_buyer_fk

-- DROP INDEX public.fki_customer_buyer_fk;

CREATE INDEX fki_customer_buyer_fk
  ON public.cms_buyer_mapping
  USING btree
  (customer_code COLLATE pg_catalog."default");


-- Index: fki_customer_buyer_fk

-- DROP INDEX public.fki_customer_buyer_fk;

CREATE INDEX fki_customer_buyer_fk
    ON public.cms_buyer_mapping USING btree
    (customer_code COLLATE pg_catalog."default")
    TABLESPACE pg_default;