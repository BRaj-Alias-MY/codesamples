CREATE TYPE operations_operation_type_enum AS ENUM ('Cut', 'embellishment', 'sewing','packing');
CREATE TYPE operations_operation_category_enum AS ENUM ('Panel Form', 'Semi-Finished', 'Garment Form','Carton Form');

-- Table: public.pps_operations

-- DROP TABLE public.pps_operations;
CREATE TABLE public.pps_operations
(
    operation_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    operation_name character varying(20) COLLATE pg_catalog."default" NOT NULL,
    operation_description character varying(50) COLLATE pg_catalog."default",
    is_external_operation boolean NOT NULL,
    operation_category operations_operation_category_enum NOT NULL,
    operation_type operations_operation_type_enum NOT NULL,
    "isActive" boolean NOT NULL,
    activated_date date,
    deactivated_date date,
    CONSTRAINT "PK_ce75043f964e544aaf696da6059" PRIMARY KEY (operation_code)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pps_operations
    OWNER to postgres;

-- Table: public.pps_graph

-- DROP TABLE public.pps_graph;

CREATE TABLE public.pps_graph
(
    graph_id uuid NOT NULL DEFAULT uuid_generate_v4(),
    root_operation character varying COLLATE pg_catalog."default",
    CONSTRAINT "PK_f8f106ee54c025e6dfbb366c2ee" PRIMARY KEY (graph_id)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pps_graph
    OWNER to postgres;

-- Table: public.pps_graph_routing

-- DROP TABLE public.pps_graph_routing;

CREATE TABLE public.pps_graph_routing
(
    uid uuid NOT NULL DEFAULT uuid_generate_v4(),
    from_operation character varying(10) COLLATE pg_catalog."default" NOT NULL,
    to_operation character varying(10) COLLATE pg_catalog."default" NOT NULL,
    graph_id uuid NOT NULL,
    CONSTRAINT "PK_63548c64093560506916f69bec5" PRIMARY KEY (uid),
    CONSTRAINT "FK_462cb1000430408bc2ede29365a" FOREIGN KEY (graph_id)
        REFERENCES public.pps_graph (graph_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pps_graph_routing
    OWNER to postgres;

-- Index: fki_fk_graphrouting_from_graph

-- DROP INDEX public.fki_fk_graphrouting_from_graph;

CREATE INDEX fki_fk_graphrouting_from_graph
    ON public.pps_graph_routing USING btree
    (from_operation COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Index: fki_fk_graphrouting_graph

-- DROP INDEX public.fki_fk_graphrouting_graph;

CREATE INDEX fki_fk_graphrouting_graph
    ON public.pps_graph_routing USING btree
    (graph_id)
    TABLESPACE pg_default;

-- Index: fki_fk_graphrouting_to_graph

-- DROP INDEX public.fki_fk_graphrouting_to_graph;

CREATE INDEX fki_fk_graphrouting_to_graph
    ON public.pps_graph_routing USING btree
    (to_operation COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Table: public.pps_operation_routing

-- DROP TABLE public.pps_operation_routing;

CREATE TABLE public.pps_operation_routing
(
    level character varying(20) COLLATE pg_catalog."default" NOT NULL,
    unique_reference_id character varying(100) COLLATE pg_catalog."default" NOT NULL,
    uid uuid NOT NULL DEFAULT uuid_generate_v4(),
    "isActive" boolean,
    activated_date date,
    graph_id uuid NOT NULL,
    CONSTRAINT "PK_3b385fdc959a897fa6c5f5c961b" PRIMARY KEY (uid),
    CONSTRAINT "REL_e7a2277a4caae2955ecc455d0a" UNIQUE (graph_id)
,
    CONSTRAINT "FK_e7a2277a4caae2955ecc455d0a1" FOREIGN KEY (graph_id)
        REFERENCES public.pps_graph (graph_id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pps_operation_routing
    OWNER to postgres;

-- Index: fki_fk_graphlevel_graph

-- DROP INDEX public.fki_fk_graphlevel_graph;

CREATE INDEX fki_fk_graphlevel_graph
    ON public.pps_operation_routing USING btree
    (graph_id)
    TABLESPACE pg_default;

-- Table: public.pps_production_order

-- DROP TABLE public.pps_production_order;

CREATE TABLE public.pps_production_order
(
    po_number uuid NOT NULL DEFAULT uuid_generate_v4(),
    po_description character varying(40) COLLATE pg_catalog."default",
    CONSTRAINT purchase_order_pkey PRIMARY KEY (po_number)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pps_production_order
    OWNER to postgres;