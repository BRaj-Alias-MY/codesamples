
create extension "uuid-ossp"; //To import uuid module

-- Table: public.idms_address

-- DROP TABLE public.idms_address;

CREATE TABLE public.idms_address
(
    address_uid uuid NOT NULL DEFAULT uuid_generate_v4(),
    door_no character varying(20) COLLATE pg_catalog."default",
    address_line_1 character varying(50) COLLATE pg_catalog."default" NOT NULL,
    address_line_2 character varying(50) COLLATE pg_catalog."default",
    land_mark character varying(50) COLLATE pg_catalog."default",
    state character varying(20) COLLATE pg_catalog."default",
    country character varying(20) COLLATE pg_catalog."default" NOT NULL,
    zipcode character varying(10) COLLATE pg_catalog."default",
    CONSTRAINT "PK_409511e83826f1694c493f423dd" PRIMARY KEY (address_uid)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.idms_address
    OWNER to postgres;

-- Table: public.idms_location

-- DROP TABLE public.idms_location;

CREATE TABLE public.idms_location
(
    location_uid uuid NOT NULL DEFAULT uuid_generate_v4(),
    location_type character varying(20) COLLATE pg_catalog."default",
    lat character varying(10) COLLATE pg_catalog."default",
    "long" character varying(10) COLLATE pg_catalog."default",
    address_uid uuid NOT NULL,
    CONSTRAINT "PK_5a451c33297db975ba749a11619" PRIMARY KEY (location_uid),
    CONSTRAINT "FK_b5d92d724d6acc9953372aad733" FOREIGN KEY (address_uid)
        REFERENCES public.idms_address (address_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.idms_location
    OWNER to postgres;

-- Index: fki_fk_address

-- DROP INDEX public.fki_fk_address;

CREATE INDEX fki_fk_address
    ON public.idms_location USING btree
    (address_uid)
    TABLESPACE pg_default;

-- Table: public.idms_contact

-- DROP TABLE public.idms_contact;

CREATE TABLE public.idms_contact
(
    contact_uid uuid NOT NULL DEFAULT uuid_generate_v4(),
    land_line_no character varying(20) COLLATE pg_catalog."default",
    mobile_no character varying(15) COLLATE pg_catalog."default" NOT NULL,
    email character varying(50) COLLATE pg_catalog."default",
    address_uid uuid,
    CONSTRAINT "PK_69e400f940f798a7763de17e1a7" PRIMARY KEY (contact_uid),
    CONSTRAINT "FK_33400fea2feb5c9f2e54c77f837" FOREIGN KEY (address_uid)
        REFERENCES public.idms_address (address_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.idms_contact
    OWNER to postgres;

-- Index: fki_fk01_address

-- DROP INDEX public.fki_fk01_address;

CREATE INDEX fki_fk01_address
    ON public.idms_contact USING btree
    (address_uid)
    TABLESPACE pg_default;

-- Table: public.idms_user_details

-- DROP TABLE public.idms_user_details;

CREATE TABLE public.idms_user_details
(
    user_uid uuid NOT NULL DEFAULT uuid_generate_v4(),
    first_name character varying(20) COLLATE pg_catalog."default" NOT NULL,
    middle_name character varying(20) COLLATE pg_catalog."default",
    last_name character varying(20) COLLATE pg_catalog."default" NOT NULL,
    gender character varying(10) COLLATE pg_catalog."default" NOT NULL,
    ref_uid character varying(20) COLLATE pg_catalog."default",
    uid_country character varying(20) COLLATE pg_catalog."default",
    date_of_birth date,
    contact_uid uuid NOT NULL,
    CONSTRAINT "PK_653e70ac3ea5382af808421c57f" PRIMARY KEY (user_uid),
    CONSTRAINT "FK_73b0bb8db83192916f416b93feb" FOREIGN KEY (contact_uid)
        REFERENCES public.idms_contact (contact_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.idms_user_details
    OWNER to postgres;

-- Index: fki_fk_contact

-- DROP INDEX public.fki_fk_contact;

CREATE INDEX fki_fk_contact
    ON public.idms_user_details USING btree
    (contact_uid)
    TABLESPACE pg_default;