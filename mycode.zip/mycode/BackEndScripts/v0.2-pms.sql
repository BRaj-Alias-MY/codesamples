-- Table: public.pms_companies

-- DROP TABLE public.pms_companies;

CREATE TABLE public.pms_companies
(
    company_code character varying(20) COLLATE pg_catalog."default" NOT NULL,
    company_name character varying(30) COLLATE pg_catalog."default" NOT NULL,
    activated_date date,
    deactivated_date date,
    "isActive" boolean NOT NULL DEFAULT true,
    location_uid uuid,
    user_uid uuid,
    CONSTRAINT "PK_5573411324f447f646e21a78316" PRIMARY KEY (company_code),
    CONSTRAINT "FK_4b014cb2b327702ab7097a5c948" FOREIGN KEY (location_uid)
        REFERENCES public.idms_location (location_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_fe2f363477603e61596809e6961" FOREIGN KEY (user_uid)
        REFERENCES public.idms_user_details (user_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pms_companies
    OWNER to postgres;

-- Index: fki_location

-- DROP INDEX public.fki_location;

CREATE INDEX fki_location
    ON public.pms_companies USING btree
    (location_uid)
    TABLESPACE pg_default;

-- Index: fki_user

-- DROP INDEX public.fki_user;

CREATE INDEX fki_user
    ON public.pms_companies USING btree
    (user_uid)
    TABLESPACE pg_default;

-- Table: public.pms_cluster

-- DROP TABLE public.pms_cluster;

CREATE TABLE public.pms_cluster
(
    cluster_code character varying(20) COLLATE pg_catalog."default" NOT NULL,
    cluster_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    "isActive" boolean,
    activated_date date,
    deactivated_date date,
    corporate_code character varying(20) COLLATE pg_catalog."default" NOT NULL,
    location_uid uuid,
    user_uid uuid,
    CONSTRAINT "PK_5405bd0896bf831a507db015265" PRIMARY KEY (cluster_code),
    CONSTRAINT "FK_2aabf833c91c1526057e2eb21e4" FOREIGN KEY (location_uid)
        REFERENCES public.idms_location (location_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_5127e9ad8d22c58705653bb8d6b" FOREIGN KEY (corporate_code)
        REFERENCES public.pms_companies (company_code) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_befb8ddebf083a8ad524503f720" FOREIGN KEY (user_uid)
        REFERENCES public.idms_user_details (user_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pms_cluster
    OWNER to postgres;

-- Index: fki_company_fk

-- DROP INDEX public.fki_company_fk;

CREATE INDEX fki_company_fk
    ON public.pms_cluster USING btree
    (corporate_code COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Index: fki_location_fkey

-- DROP INDEX public.fki_location_fkey;

CREATE INDEX fki_location_fkey
    ON public.pms_cluster USING btree
    (location_uid)
    TABLESPACE pg_default;

-- Index: fki_user_fk

-- DROP INDEX public.fki_user_fk;

CREATE INDEX fki_user_fk
    ON public.pms_cluster USING btree
    (user_uid)
    TABLESPACE pg_default;

-- Table: public.pms_plant

-- DROP TABLE public.pms_plant;

CREATE TABLE public.pms_plant
(
    plant_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    plant_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    m3_production_plant_code character varying(20) COLLATE pg_catalog."default",
    plant_type character varying(10) COLLATE pg_catalog."default",
    activated_date date,
    deactivated_date date,
    "isActive" boolean,
    plant_start_time time without time zone,
    plant_end_time time without time zone,
    parent_plant_code character varying(10) COLLATE pg_catalog."default",
    plant_location uuid NOT NULL,
    contact_details uuid NOT NULL,
    cluster_code character varying(20) COLLATE pg_catalog."default",
    CONSTRAINT "PK_c9db5f66fd3a22c54f5a2a65ea3" PRIMARY KEY (plant_code),
    CONSTRAINT "FK_40d2490a2a75531f28dde9de71c" FOREIGN KEY (cluster_code)
        REFERENCES public.pms_cluster (cluster_code) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_696c331ee2700c7c94c0cbcbe1d" FOREIGN KEY (plant_location)
        REFERENCES public.idms_location (location_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_7858aef26925ce8c52a338682d3" FOREIGN KEY (contact_details)
        REFERENCES public.idms_user_details (user_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_cba5e2ec6d66094f0cc8cb15599" FOREIGN KEY (parent_plant_code)
        REFERENCES public.pms_plant (plant_code) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pms_plant
    OWNER to postgres;

-- Index: fk_cluster_code

-- DROP INDEX public.fk_cluster_code;

CREATE INDEX fk_cluster_code
    ON public.pms_plant USING btree
    (cluster_code COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Index: fk_location

-- DROP INDEX public.fk_location;

CREATE INDEX fk_location
    ON public.pms_plant USING btree
    (plant_location)
    TABLESPACE pg_default;

-- Index: fk_userdetails

-- DROP INDEX public.fk_userdetails;

CREATE INDEX fk_userdetails
    ON public.pms_plant USING btree
    (contact_details)
    TABLESPACE pg_default;

-- Index: fki_plant_fk

-- DROP INDEX public.fki_plant_fk;

CREATE INDEX fki_plant_fk
    ON public.pms_plant USING btree
    (parent_plant_code COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Table: public.pms_departments

-- DROP TABLE public.pms_departments;

CREATE TABLE public.pms_departments
(
    department_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    department_name character varying(30) COLLATE pg_catalog."default" NOT NULL,
    department_type character varying(10) COLLATE pg_catalog."default" NOT NULL,
    sla bigint NOT NULL,
    is_active boolean NOT NULL,
    deactivated_date date,
    user_uid uuid NOT NULL,
    plant_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "PK_f89894bb520602956e71b4c27f1" PRIMARY KEY (department_code),
    CONSTRAINT "FK_53b2c0ae1335be40830dd45ecf4" FOREIGN KEY (plant_code)
        REFERENCES public.pms_plant (plant_code) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_9dcc8eb3027a49e5bff87c2694a" FOREIGN KEY (user_uid)
        REFERENCES public.idms_user_details (user_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pms_departments
    OWNER to postgres;

-- Index: fki_fk_departmenthead

-- DROP INDEX public.fki_fk_departmenthead;

CREATE INDEX fki_fk_departmenthead
    ON public.pms_departments USING btree
    (user_uid)
    TABLESPACE pg_default;

-- Index: fki_fk_plantcode

-- DROP INDEX public.fki_fk_plantcode;

CREATE INDEX fki_fk_plantcode
    ON public.pms_departments USING btree
    (plant_code COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Table: public.pms_sections

-- DROP TABLE public.pms_sections;

CREATE TABLE public.pms_sections
(
    section_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    section_name character varying(30) COLLATE pg_catalog."default" NOT NULL,
    "isActive" boolean NOT NULL,
    user_id uuid NOT NULL,
    department_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT "PK_23583fc58845b63a0593560f9df" PRIMARY KEY (section_code),
    CONSTRAINT "FK_6a736d57c3adf22fb77f3b38b6e" FOREIGN KEY (department_code)
        REFERENCES public.pms_departments (department_code) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT "FK_91bdc0e7a1bd406f19d70b3ca07" FOREIGN KEY (user_id)
        REFERENCES public.idms_user_details (user_uid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.pms_sections
    OWNER to postgres;

-- Index: fki_fk_section_dept

-- DROP INDEX public.fki_fk_section_dept;

CREATE INDEX fki_fk_section_dept
    ON public.pms_sections USING btree
    (department_code COLLATE pg_catalog."default")
    TABLESPACE pg_default;

-- Index: fki_fk_section_user

-- DROP INDEX public.fki_fk_section_user;

CREATE INDEX fki_fk_section_user
    ON public.pms_sections USING btree
    (user_id)
    TABLESPACE pg_default;