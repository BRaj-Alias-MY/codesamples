-- Table: public.oms_mo_details

-- DROP TABLE public.oms_mo_details;

CREATE TABLE public.oms_mo_details
(
    mo_number character varying(20) COLLATE pg_catalog."default" NOT NULL,
    vpo character varying(30) COLLATE pg_catalog."default" NOT NULL,
    customer_order_no character varying(30) COLLATE pg_catalog."default" NOT NULL,
    customer_order_line_no character varying(30) COLLATE pg_catalog."default" NOT NULL,
    packing_method character varying(30) COLLATE pg_catalog."default" NOT NULL,
    destination character varying(50) COLLATE pg_catalog."default" NOT NULL,
    cpo character varying(30) COLLATE pg_catalog."default" NOT NULL,
    schedule character varying(30) COLLATE pg_catalog."default" NOT NULL,
    mo_status character varying(20) COLLATE pg_catalog."default" NOT NULL,
    max_operations character varying(20) COLLATE pg_catalog."default",
    max_status_operated character varying(50) COLLATE pg_catalog."default",
    buyer_desc text COLLATE pg_catalog."default" NOT NULL,
    plant_code character varying(20) COLLATE pg_catalog."default" NOT NULL,
    business_area_code character varying(30) COLLATE pg_catalog."default" NOT NULL,
    mo_quantity character varying(20) COLLATE pg_catalog."default" NOT NULL,
    planned_delivery_date character varying(20) COLLATE pg_catalog."default",
    requested_planned_delivery_date character varying(20) COLLATE pg_catalog."default",
    planned_cut_date character varying(20) COLLATE pg_catalog."default",
    "	end_date" character varying(20) COLLATE pg_catalog."default",
    transaction_id character varying(20) COLLATE pg_catalog."default" NOT NULL,
    po_number character varying(20) COLLATE pg_catalog."default",
    "isActive" boolean,
    deactivated_date character varying(20) COLLATE pg_catalog."default",
    handled_po boolean,
    CONSTRAINT mo_details_pkey PRIMARY KEY (mo_number)
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.oms_mo_details
    OWNER to postgres;
	
	
	
-- Table: public.oms_products_info

-- DROP TABLE public.oms_products_info;

CREATE TABLE public.oms_products_info
(
    product_sku character varying(20) COLLATE pg_catalog."default" NOT NULL,
    product_name character varying(30) COLLATE pg_catalog."default" NOT NULL,
    product_desc text COLLATE pg_catalog."default",
    color_name character varying(30) COLLATE pg_catalog."default",
    color_desc text COLLATE pg_catalog."default",
    size_name character varying(20) COLLATE pg_catalog."default",
    zfeature_name character varying(30) COLLATE pg_catalog."default",
    zfeature_desc text COLLATE pg_catalog."default",
    style character varying(30) COLLATE pg_catalog."default" NOT NULL,
    customer_style_no character varying(50) COLLATE pg_catalog."default",
    mo_number character varying(30) COLLATE pg_catalog."default" NOT NULL,
    size_desc text COLLATE pg_catalog."default",
    CONSTRAINT products_info_pkey PRIMARY KEY (product_sku),
    CONSTRAINT fk_products_mos FOREIGN KEY (mo_number)
        REFERENCES public.oms_mo_details (mo_number) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.oms_products_info
    OWNER to postgres;

-- Index: fki_fk_products_mos

-- DROP INDEX public.fki_fk_products_mos;

CREATE INDEX fki_fk_products_mos
    ON public.oms_products_info USING btree
    (mo_number COLLATE pg_catalog."default")
    TABLESPACE pg_default;
	
-- Table: public.oms_mo_items

-- DROP TABLE public.oms_mo_items;

CREATE TABLE public.oms_mo_items
(
    material_item_code character varying(20) COLLATE pg_catalog."default" NOT NULL,
    material_sequence character varying(30) COLLATE pg_catalog."default",
    consumption character varying(50) COLLATE pg_catalog."default",
    operation_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    uom character varying(30) COLLATE pg_catalog."default",
    wastage_perc character varying(30) COLLATE pg_catalog."default",
    mo_number character varying(20) COLLATE pg_catalog."default" NOT NULL,
    CONSTRAINT mo_items_pkey PRIMARY KEY (material_item_code),
    CONSTRAINT "fk_moItems_mo" FOREIGN KEY (mo_number)
        REFERENCES public.oms_mo_details (mo_number) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.oms_mo_items
    OWNER to postgres;

-- Index: fki_fk_moItems_mo

-- DROP INDEX public."fki_fk_moItems_mo";

CREATE INDEX "fki_fk_moItems_mo"
    ON public.oms_mo_items USING btree
    (mo_number COLLATE pg_catalog."default")
    TABLESPACE pg_default;
	
-- Table: public.oms_item_info

-- DROP TABLE public.oms_item_info;

CREATE TABLE public.oms_item_info
(
    item_desc text COLLATE pg_catalog."default",
    color_code character varying COLLATE pg_catalog."default",
    size_code character varying COLLATE pg_catalog."default",
    z_code character varying COLLATE pg_catalog."default",
    color_desc text COLLATE pg_catalog."default",
    size_desc text COLLATE pg_catalog."default",
    z_feature_desc text COLLATE pg_catalog."default",
    mo_number character varying COLLATE pg_catalog."default",
    material_mo_unique_ref_id character varying COLLATE pg_catalog."default" NOT NULL,
    material_item_code character varying COLLATE pg_catalog."default",
    CONSTRAINT oms_item_pkey PRIMARY KEY (material_mo_unique_ref_id),
    CONSTRAINT fk_item_mo FOREIGN KEY (mo_number)
        REFERENCES public.oms_mo_details (mo_number) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.oms_item_info
    OWNER to postgres;

-- Index: fki_fk_item_mo

-- DROP INDEX public.fki_fk_item_mo;

CREATE INDEX fki_fk_item_mo
    ON public.oms_item_info USING btree
    (mo_number COLLATE pg_catalog."default")
    TABLESPACE pg_default;
	
-- Table: public.oms_mo_operations

-- DROP TABLE public.oms_mo_operations;

CREATE TABLE public.oms_mo_operations
(
    op_mo_unique_ref_id character varying(20) COLLATE pg_catalog."default" NOT NULL,
    operation_code character varying(10) COLLATE pg_catalog."default" NOT NULL,
    operation_type character varying(30) COLLATE pg_catalog."default" NOT NULL,
    smv character varying(30) COLLATE pg_catalog."default",
    workstation_id character varying(20) COLLATE pg_catalog."default",
    mo_number character varying(50) COLLATE pg_catalog."default" NOT NULL,
    operation_desc text COLLATE pg_catalog."default",
    CONSTRAINT mo_operations_pkey PRIMARY KEY (op_mo_unique_ref_id),
    CONSTRAINT fk_op_mo FOREIGN KEY (mo_number)
        REFERENCES public.oms_mo_details (mo_number) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
TABLESPACE pg_default;

ALTER TABLE public.oms_mo_operations
    OWNER to postgres;

-- Index: fki_fk_op_mo

-- DROP INDEX public.fki_fk_op_mo;

CREATE INDEX fki_fk_op_mo
    ON public.oms_mo_operations USING btree
    (mo_number COLLATE pg_catalog."default")
    TABLESPACE pg_default;