import { ApiModelProperty } from "@nestjs/swagger";
import { OmsMoDetails } from "../entities/oms_mo_details";
import { MoDetailss } from "../dtos/mo.dto";

export class CreateOmsResponse {
    status: boolean
    data: OmsMoDetails[]
    errInfo: string
}

export class DeleteOmsRequest {
    @ApiModelProperty()
    mo_number: string;
}

export class GetAllOmsResponse {
    status: boolean
    data: OmsMoDetails[]
    errInfo: string
}

export class MoRequest {
    @ApiModelProperty()
    mo_number: string
}

export class BuyerDuvisonRequest {
    @ApiModelProperty()
    buyer_division: string
}

export class PlantCodeRequest{
    @ApiModelProperty()
    plant_code : string
}