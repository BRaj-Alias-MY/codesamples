import { OmsMoDetails } from '../entities/oms_mo_details';
import { ApiModelProperty } from "@nestjs/swagger";

export class MoCreateResponse {
    status: boolean;
    data?: any;
    errorInfo?: string;
}

export class GetAllMosResponse {
    status: boolean;
    data?: OmsMoDetails[];
    errorInfo?: string;
}


export class GetMoResponse {
    status: boolean;
    data?: OmsMoDetails;
    errorInfo?: string;
}

export class GetMoResponseStatus {
    status: boolean;
    data?: boolean;
    errorInfo?: string;
}

export class BuyerDivisons{
    buyer_desc : string
}

export class MoWiseOperations {
    mo_number : string;
    operation_codes : string;
}

export class StyleScheduleColorGroupedMos{
    style : string;
    schedule : string;
    color_name : string;
    mo_list : string;
    buyer_desc : string;
}

