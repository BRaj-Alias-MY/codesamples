import { ApiModelProperty } from "@nestjs/swagger";

export class MoPoRequest {
    @ApiModelProperty()
    monumbers: string
    @ApiModelProperty()
    ponumber: string
    @ApiModelProperty()
    postatus: boolean
}