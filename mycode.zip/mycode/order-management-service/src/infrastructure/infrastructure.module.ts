import { Module } from '@nestjs/common';
import { OmsMoDetails } from '../entities/oms_mo_details';
import { OrderManagementService } from '../services/order-management-service.service';
import { OrderManagementServiceController } from '../controllers/order-management-service.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { UpdatePoMoController } from 'src/controllers/update-po-mo-client.controller';
import { UpdatePoMoService } from 'src/services/update-po-mo-client.service';





@Module({
    imports: [TypeOrmModule.forFeature([OmsMoDetails])],
    controllers: [OrderManagementServiceController,UpdatePoMoController],
    providers: [OrderManagementService,UpdatePoMoService],
})
export class InfrastructureModule { }
