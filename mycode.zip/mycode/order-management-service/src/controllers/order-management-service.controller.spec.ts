import { Test, TestingModule } from '@nestjs/testing';
import { OrderManagementServiceController } from './order-management-service.controller';

describe('OrderManagementService Controller', () => {
  let controller: OrderManagementServiceController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [OrderManagementServiceController],
    }).compile();

    controller = module.get<OrderManagementServiceController>(OrderManagementServiceController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
