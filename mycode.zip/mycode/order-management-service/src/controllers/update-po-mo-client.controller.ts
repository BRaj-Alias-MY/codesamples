import { Controller, Post, Body } from '@nestjs/common';
import { MoPoRequest } from 'src/models/mo_po.request';
import { UpdatePoMoService } from 'src/services/update-po-mo-client.service';

@Controller('update-po-mo')
export class UpdatePoMoController {
    constructor(private moPoService: UpdatePoMoService) { }
    @Post('/poMoUpdate')
    async updateMoPoStatus(@Body() inputRequest: MoPoRequest) {
        return this.moPoService.updatePo(inputRequest)
    }
}
