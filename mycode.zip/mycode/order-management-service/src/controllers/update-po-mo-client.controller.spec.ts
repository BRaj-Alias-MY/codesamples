import { Test, TestingModule } from '@nestjs/testing';
import { UpdatePoMoController } from './update-po-mo-client.controller';

describe('UpdatePoMo Controller', () => {
  let controller: UpdatePoMoController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UpdatePoMoController],
    }).compile();

    controller = module.get<UpdatePoMoController>(UpdatePoMoController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
