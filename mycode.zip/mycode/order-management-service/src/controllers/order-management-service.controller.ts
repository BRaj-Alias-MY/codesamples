import { Controller, Post, Body } from '@nestjs/common';
import { MoDetailss } from '../dtos/mo.dto';
import { CreateOmsResponse, DeleteOmsRequest, GetAllOmsResponse, MoRequest,BuyerDuvisonRequest,PlantCodeRequest } 
from '../models/mo.request';
import { MoCreateResponse, GetAllMosResponse, GetMoResponse, GetMoResponseStatus,MoWiseOperations,StyleScheduleColorGroupedMos,BuyerDivisons } from '../models/mo.response';
import { OrderManagementService } from '../services/order-management-service.service';

@Controller('order-management-service')
export class OrderManagementServiceController {
  response = new MoCreateResponse();
  constructor(private orderService: OrderManagementService) {}
  @Post('/createMo')
  async create(@Body() moDetails: MoDetailss): Promise<MoCreateResponse> {
    const response = new MoCreateResponse();
    return await this.orderService
      .saveMo(moDetails)
      .then(mo => {
        response.status = true;
        response.data = mo;
        return response;
      })
      .catch(err => {
        response.status = false;
        response.errorInfo = err.message;
        return response;
      });
  }
  @Post('/updateMo')
  async update(@Body() moDetails: MoDetailss): Promise<any> {
    const response = new MoCreateResponse();
    return await this.orderService
      .saveMo(moDetails)
      .then(mo => {
        response.status = true;
        response.data = mo;
        return response;
      })
      .catch(err => {
        response.status = false;
        response.errorInfo = err.message;
        return response;
      });
  }
  @Post('/getAllMos')
  async getAllMos(): Promise<GetAllMosResponse> {
    const response = new GetAllMosResponse();
    return await this.orderService
      .getAllMos()
      .then(mos => {
        response.status = true;
        response.data = mos;
        return response;
      })
      .catch(err => {
        response.status = false;
        response.errorInfo = err.message;
        return response;
      });
  }

  @Post('/getMoByNumber')
  async getMoByNumber(@Body() moRequest: MoRequest): Promise<GetMoResponse> {
    const response = new GetMoResponse();
    return await this.orderService
      .getMoByNumber(moRequest.mo_number)
      .then(mos => {
        if (mos.mo_number != '') {
          response.status = true;
          response.data = mos;
          return response;
        }
      })
      .catch(err => {
        response.status = false;
        response.errorInfo = err.message;
        return response;
      });
  }

  @Post('/deActivateMo')
  async deActivateMo(
    @Body() moRequest: MoRequest,
  ): Promise<GetMoResponseStatus> {
    const response = new GetMoResponseStatus();
    const Exists = await this.orderService.verifyMoStatus(moRequest.mo_number);

    if (Exists) {
      return await this.orderService
        .deActivateMo(moRequest.mo_number)
        .then(moStatus => {
          //  console.log(moStatus)
          if (moStatus) {
            response.status = true;
            return response;
          } else {
            response.status = false;
            response.errorInfo = 'Sorry, Something went wrong !';
            return response;
          }
        })
        .catch(err => {
          response.status = false;
          response.errorInfo = err.message;
          return response;
        });
    } else {
      response.status = false;
      response.errorInfo = 'Sorry, Something went wrong !';
      return response;
    }
  }

    //This function returns true if the given buyer_divisons exists
    @Post('/getBuyerDivision')
    async getBuyerDivision(@Body() buyer_division: BuyerDuvisonRequest): Promise<boolean> {
        try {
            console.log(buyer_division);
            return await this.orderService.getBuyerDivision(buyer_division.buyer_division);
        }catch(err){
            console.log(err);
            return false;
        }
    }

    //This function returns all the buyer_divisons for buyer mapping
    @Post('/getAllBuyerDivisions')
    async getAllBuyerDivisions():Promise<BuyerDivisons[]>{
        try{
            return await this.orderService.getAllBuyerDivisions();
        }catch(err){
            console.log(err);
            return null;
        };
    }

    //This function returns all the mo wise operations for po creation
    @Post('/getMoWiseOperations')
    async getMoWiseOperations(@Body() plant_code : PlantCodeRequest):Promise<MoWiseOperations[]>{
        try{
            return await this.orderService.getMoWiseOperations(plant_code.plant_code);
        }catch(err){
            console.log(err);
            return null;
        };
    }
    
    //This function returns all the grouped mos grouped by style,schedule,color for po creation
    @Post('/getStyleScheduleColorGroupedMos')
    async getStyleScheduleColorGroupedMos(@Body() plant_code:PlantCodeRequest):Promise<StyleScheduleColorGroupedMos[]>{
        try{
            return await this.orderService.getStyleScheduleColorGroupedMos(plant_code.plant_code);
        }catch(err){
            console.log(err);
            return null;
        };
    }
}
