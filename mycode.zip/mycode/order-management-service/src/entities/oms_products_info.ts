import { BaseEntity, Column, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryColumn, PrimaryGeneratedColumn, RelationId } from "typeorm";
import { OmsMoDetails } from "./oms_mo_details";


@Entity("oms_products_info", { schema: "public" })
@Index("fki_fk_products_mos", ["moNumber",])
export class OmsProductsInfo {

    @Column("character varying", {
        nullable: false,
        primary: true,
        length: 20,
        name: "product_sku"
    })
    product_sku: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "product_name"
    })
    product_name: string;


    @Column("text", {
        nullable: true,
        name: "product_desc"
    })
    product_desc: string | null;


    @Column("character varying", {
        nullable: true,
        length: 30,
        name: "color_name"
    })
    color_name: string | null;


    @Column("text", {
        nullable: true,
        name: "color_desc"
    })
    color_desc: string | null;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "size_name"
    })
    size_name: string | null;


    @Column("character varying", {
        nullable: true,
        length: 30,
        name: "zfeature_name"
    })
    zfeature_name: string | null;


    @Column("text", {
        nullable: true,
        name: "zfeature_desc"
    })
    zfeature_desc: string | null;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "style"
    })
    style: string;


    @Column("character varying", {
        nullable: true,
        length: 50,
        name: "customer_style_no"
    })
    customer_style_no: string | null;



    @OneToOne(type => OmsMoDetails, oms_mo_details => oms_mo_details.omsProductsInfos, { nullable: false, })
    @JoinColumn({ name: 'mo_number' })
    moNumber: OmsMoDetails | null;


    @Column("text", {
        nullable: true,
        name: "size_desc"
    })
    size_desc: string | null;

}
