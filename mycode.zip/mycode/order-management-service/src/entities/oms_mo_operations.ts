import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {OmsMoDetails} from "./oms_mo_details";


@Entity("oms_mo_operations",{schema:"public" } )
@Index("fki_fk_op_mo",["moNumber",])
export class OmsMoOperations {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:20,
        name:"op_mo_unique_ref_id"
        })
    op_mo_unique_ref_id:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:10,
        name:"operation_code"
        })
    operation_code:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:30,
        name:"operation_type"
        })
    operation_type:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:30,
        name:"smv"
        })
    smv:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"workstation_id"
        })
    workstation_id:string | null;
        

   
    @ManyToOne(type=>OmsMoDetails, oms_mo_details=>oms_mo_details.omsMoOperationss,{  nullable:false, })
    @JoinColumn({ name:'mo_number'})
    moNumber:OmsMoDetails | null;


    @Column("text",{ 
        nullable:true,
        name:"operation_desc"
        })
    operation_desc:string | null;
        
}
