import { BaseEntity, Column, Entity, Index, JoinColumn, JoinTable, ManyToMany, ManyToOne, OneToMany, OneToOne, PrimaryColumn, PrimaryGeneratedColumn, RelationId } from "typeorm";
import { OmsItemInfo } from "./oms_item_info";
import { OmsMoItems } from "./oms_mo_items";
import { OmsMoOperations } from "./oms_mo_operations";
import { OmsProductsInfo } from "./oms_products_info";


@Entity("oms_mo_details", { schema: "public" })
export class OmsMoDetails {

    @Column("character varying", {
        nullable: false,
        primary: true,
        length: 20,
        name: "mo_number"
    })
    mo_number: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "vpo"
    })
    vpo: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "customer_order_no"
    })
    customer_order_no: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "customer_order_line_no"
    })
    customer_order_line_no: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "packing_method"
    })
    packing_method: string;


    @Column("character varying", {
        nullable: false,
        length: 50,
        name: "destination"
    })
    destination: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "cpo"
    })
    cpo: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "schedule"
    })
    schedule: string;


    @Column("character varying", {
        nullable: false,
        length: 20,
        name: "mo_status"
    })
    mo_status: string;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "max_operations"
    })
    max_operations: string | null;


    @Column("character varying", {
        nullable: true,
        length: 50,
        name: "max_status_operated"
    })
    max_status_operated: string | null;


    @Column("text", {
        nullable: false,
        name: "buyer_desc"
    })
    buyer_desc: string;


    @Column("character varying", {
        nullable: false,
        length: 20,
        name: "plant_code"
    })
    plant_code: string;


    @Column("character varying", {
        nullable: false,
        length: 30,
        name: "business_area_code"
    })
    business_area_code: string;


    @Column("character varying", {
        nullable: false,
        length: 20,
        name: "mo_quantity"
    })
    mo_quantity: string;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "planned_delivery_date"
    })
    planned_delivery_date: string | null;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "requested_planned_delivery_date"
    })
    requested_planned_delivery_date: string | null;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "planned_cut_date"
    })
    planned_cut_date: string | null;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "	end_date"
    })
    end_date: string | null;


    @Column("character varying", {
        nullable: false,
        length: 20,
        name: "transaction_id"
    })
    transaction_id: string;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "po_number"
    })
    po_number: string | null;


    @Column("boolean", {
        nullable: true,
        name: "isActive"
    })
    isActive: boolean | null;


    @Column("character varying", {
        nullable: true,
        length: 20,
        name: "deactivated_date"
    })
    deactivated_date: string | null;


    @Column("boolean", {
        nullable: true,
        name: "handled_po"
    })
    handled_po: boolean | null;



    @OneToMany(type => OmsItemInfo, oms_item_info => oms_item_info.moNumber, { cascade: true })
    omsItemInfos: OmsItemInfo[];



    @OneToMany(type => OmsMoItems, oms_mo_items => oms_mo_items.moNumber, { cascade: true })
    omsMoItemss: OmsMoItems[];



    @OneToMany(type => OmsMoOperations, oms_mo_operations => oms_mo_operations.moNumber, { cascade: true })
    omsMoOperationss: OmsMoOperations[];



    @OneToOne(type => OmsProductsInfo, oms_products_info => oms_products_info.moNumber, { cascade: true })
    omsProductsInfos: OmsProductsInfo;

}
