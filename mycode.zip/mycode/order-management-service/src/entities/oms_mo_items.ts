import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {OmsMoDetails} from "./oms_mo_details";


@Entity("oms_mo_items",{schema:"public" } )
@Index("fki_fk_moItems_mo",["moNumber",])
export class OmsMoItems {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:20,
        name:"material_item_code"
        })
    material_item_code:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:30,
        name:"material_sequence"
        })
    material_sequence:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:50,
        name:"consumption"
        })
    consumption:string | null;
        

    @Column("character varying",{ 
        nullable:false,
        length:10,
        name:"operation_code"
        })
    operation_code:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:30,
        name:"uom"
        })
    uom:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:30,
        name:"wastage_perc"
        })
    wastage_perc:string | null;
        

   
    @ManyToOne(type=>OmsMoDetails, oms_mo_details=>oms_mo_details.omsMoItemss,{  nullable:false, })
    @JoinColumn({ name:'mo_number'})
    moNumber:OmsMoDetails | null;

}
