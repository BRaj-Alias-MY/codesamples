import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {OmsMoDetails} from "./oms_mo_details";


@Entity("oms_item_info",{schema:"public" } )
@Index("fki_fk_item_mo",["moNumber",])
export class OmsItemInfo {

    @Column("text",{ 
        nullable:true,
        name:"item_desc"
        })
    item_desc:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        name:"color_code"
        })
    color_code:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        name:"size_code"
        })
    size_code:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        name:"z_code"
        })
    z_code:string | null;
        

    @Column("text",{ 
        nullable:true,
        name:"color_desc"
        })
    color_desc:string | null;
        

    @Column("text",{ 
        nullable:true,
        name:"size_desc"
        })
    size_desc:string | null;
        

    @Column("text",{ 
        nullable:true,
        name:"z_feature_desc"
        })
    z_feature_desc:string | null;
        

   
    @ManyToOne(type=>OmsMoDetails, oms_mo_details=>oms_mo_details.omsItemInfos,{  })
    @JoinColumn({ name:'mo_number'})
    moNumber:OmsMoDetails | null;


    @Column("character varying",{ 
        nullable:false,
        primary:true,
        name:"material_mo_unique_ref_id"
        })
    material_mo_unique_ref_id:string;
        

    @Column("character varying",{ 
        nullable:true,
        name:"material_item_code"
        })
    material_item_code:string | null;
        
}
