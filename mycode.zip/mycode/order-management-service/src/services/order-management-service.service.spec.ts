import { OrderManagementService } from './order-management-service.service';
import { Test, TestingModule } from '@nestjs/testing';




describe('OrderManagementServiceService', () => {
  let service: OrderManagementService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [OrderManagementService],
    }).compile();

    service = module.get<OrderManagementService>(OrderManagementService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
