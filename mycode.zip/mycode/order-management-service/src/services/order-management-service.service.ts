import { Injectable, Post } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { OmsMoDetails } from '../entities/oms_mo_details';
import { Repository, getRepository } from 'typeorm';
import { OmsMoOperations } from '../entities/oms_mo_operations';
import { MoWiseOperations,StyleScheduleColorGroupedMos,BuyerDivisons } from '../models/mo.response';

@Injectable()
export class OrderManagementService {
  constructor(
    @InjectRepository(OmsMoDetails)
    private moRepository: Repository<OmsMoDetails>,
  ) {}

  async saveMo(moDetails): Promise<OmsMoDetails> {
    try {
      const moModel = new OmsMoDetails();
      moModel.mo_number = moDetails.mo_number;
      moModel.vpo = moDetails.vpo;
      moModel.customer_order_no = moDetails.customer_order_no;
      moModel.customer_order_line_no = moDetails.customer_order_line_no;
      moModel.packing_method = moDetails.packing_method;
      moModel.destination = moDetails.destination;
      moModel.cpo = moDetails.cpo;
      moModel.schedule = moDetails.schedule;
      moModel.mo_status = moDetails.mo_status;
      moModel.max_operations = moDetails.max_operations;
      moModel.max_status_operated = moDetails.max_status_operated;
      moModel.buyer_desc = moDetails.buyer_desc;
      moModel.plant_code = 'EKG';
      moModel.business_area_code = moDetails.business_area_code;
      moModel.mo_quantity = moDetails.mo_quantity;
      moModel.planned_delivery_date = moDetails.planned_delivery_date;
      moModel.planned_cut_date = moDetails.planned_cut_date;
      moModel.requested_planned_delivery_date =
        moDetails.requested_planned_delivery_date;
      moModel.end_date = moDetails.end_date;
      moModel.transaction_id = moDetails.mo_number + '2323';
      moModel.handled_po = moDetails.handled_po;
      moModel.po_number = moDetails.po_number;
      moModel.isActive = true;
      moModel.omsProductsInfos = moDetails['omsProductsInfos'];
      // console.log(moModel.omsProductsInfos)
      console.log(moDetails['omsItemInfos']);
      moModel.omsMoItemss = moDetails['omsMoItemss'];
      moModel.omsItemInfos = moDetails['omsItemInfos'];
      moModel.omsMoOperationss = moDetails['omsMoOperationss'];
      return this.moRepository.save(moModel);
    } catch (err) {
      return err;
    }
  }
  async getAllMos(): Promise<OmsMoDetails[]> {
    try {
      const moResponse = await this.moRepository.find({
        where: { isActive: true },
        order: { mo_number: 'ASC' },
        relations: [
          'omsProductsInfos',
          'omsMoItemss',
          'omsItemInfos',
          'omsMoOperationss',
        ],
      });
      return moResponse;
    } catch (err) {
      return err;
    }
  }
  async getMoByNumber(mo_number: string): Promise<OmsMoDetails> {
    try {
      const moResponse = await this.moRepository.findOne({
        where: { mo_number: mo_number, isActive: true },
        relations: [
          'omsProductsInfos',
          'omsMoItemss',
          'omsItemInfos',
          'omsMoOperationss',
        ],
      });
      return moResponse;
    } catch (err) {
      return err;
    }
  }
  async verifyMoStatus(mo_number: string): Promise<boolean> {
    const status = await this.moRepository
      .findOne({ where: { mo_number: mo_number, isActive: true } })
      .then(response => {
        if (response) {
          return true;
        } else {
          return false;
        }
      })
      .catch(err => {
        return err;
      });
    console.log(status);
    return status;
  }
  async deActivateMo(mo_number: string): Promise<boolean> {
    try {
      const deactived_date = new Date().toISOString().slice(0, 10);
      //  console.log(deactived_date)

      return await this.moRepository
        .update(
          { mo_number: mo_number },
          { isActive: false, deactivated_date: deactived_date },
        )
        .then(response => {
          if (response) {
            return true;
          } else {
            return false;
          }
        })
        .catch(err => {
          return false;
        });
    } catch (err) {
      return err;
    }
  }

    //This function returns all the buyer_divisons for buyer mapping
    async getAllBuyerDivisions():Promise<BuyerDivisons[]>{
        return await this.moRepository.find({select:['buyer_desc']}).then(buyer_divisions=>{
            const unique_buyer_divisons = buyer_divisions.filter((ele, pos)=>{
                return buyer_divisions.indexOf(ele) == pos;
            }) 
            return unique_buyer_divisons;
        }).catch(err=>{
            console.log(err);
            return null;
        })
    }

    //This function returns true if the given buyer_divisons exists
    @Post('/getBuyerDivision')
    async getBuyerDivision(buyer_division: string): Promise<boolean> {
        try {
          return await this.moRepository.find({select:['buyer_desc'],where:{buyer_desc:buyer_division}}).then(buyer_divisions => {
                return buyer_divisions.length ? true : false;
            }).catch(err => {
              // console.log(err);
              return false;
            });
        }catch(err){
            console.log(err);
            return false;
        }
    }

    //This function returns all the mo wise operations for po creation
    async getMoWiseOperations(plant_code : string):Promise<MoWiseOperations[]>{
        try{
            const plantWiseMos = getRepository(OmsMoDetails).createQueryBuilder("oms_mo_details")
            .select("mo_number")
            .where("handled_po = false and plant_code = '"+plant_code+"'")

            const moWiseOperations = await getRepository(OmsMoOperations).createQueryBuilder("oms_mo_operations")
            .select("oms_mo_operations.mo_number")
            .addSelect("string_agg(oms_mo_operations.operation_code,',' ORDER BY operation_code)","operation_codes")
            .leftJoin('('+plantWiseMos.getQuery()+')','mos','mos.mo_number=oms_mo_operations.mo_number')
            .groupBy("oms_mo_operations.mo_number")
            .getRawMany();
            
            return moWiseOperations;
        }catch(err){
            console.log(err);
            return null; 
        }
    }

    //This function returns all the grouped mos grouped by style,schedule,color for po creation
    async getStyleScheduleColorGroupedMos(plant_code : string):Promise<StyleScheduleColorGroupedMos[]>{
        try{
            const groupedMos = await getRepository(OmsMoDetails).createQueryBuilder("oms_mo_details")
                .select("schedule,style,color_name,buyer_desc")
                .addSelect("string_agg(oms_mo_details.mo_number,',')","mo_list")
                .leftJoin("oms_mo_details.omsProductsInfos","oms_products_info")
                .where("handled_po = false and plant_code =  '"+plant_code+"'") //adding the condition for is already PO created MO
                .groupBy("style")
                .addGroupBy("schedule")
                .addGroupBy("color_name")
                .addGroupBy("buyer_desc") //added buyer desc in groupBy because postgre is restricting to select a filed that is not a part of groupBy.Since buyer_desc is unique for a style , added buyer_desc also in groupBy clause
                .getRawMany();
            return groupedMos;    
        }catch(err){
            console.log(err);
            return null; 
        }
    }
}
