import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, getConnection, getRepository } from 'typeorm';
import { MoPoRequest } from 'src/models/mo_po.request';
import { OmsMoDetails } from 'src/entities/oms_mo_details';
import { response } from 'express';

@Injectable()
export class UpdatePoMoService {
    constructor(@InjectRepository(OmsMoDetails) private moRepository: Repository<OmsMoDetails>) { }

    async updatePo(mopoRequestInput: MoPoRequest): Promise<boolean> {
        try {
            const poRequest = new MoPoRequest()
            poRequest.monumbers = mopoRequestInput.monumbers
            poRequest.ponumber = mopoRequestInput.ponumber
            poRequest.postatus = mopoRequestInput.postatus
            let mo_numbers_array = JSON.parse("[" + poRequest.monumbers + "]");
            return await getRepository(OmsMoDetails).createQueryBuilder().update(OmsMoDetails).set({ po_number: poRequest.ponumber, handled_po: true }).where("mo_number IN (:...mo_numbers)", { mo_numbers: mo_numbers_array }).execute()
                .then(
                    response => {
                        if (response) {
                            return true
                        } else {
                            return false
                        }
                    }
                ).catch(err => {
                    return false
                })
        }
        catch (err) {
            return err;
        }

    }
}
