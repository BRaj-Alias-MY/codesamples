import { Test, TestingModule } from '@nestjs/testing';
import { UpdatePoMoService } from './update-po-mo-client.service';

describe('UpdatePoMoService', () => {
  let service: UpdatePoMoService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [UpdatePoMoService],
    }).compile();

    service = module.get<UpdatePoMoService>(UpdatePoMoService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
