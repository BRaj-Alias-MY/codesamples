import { Injectable, HttpService } from '@nestjs/common';
@Injectable()
export class AppService {
  constructor() { }

}
