import { Injectable } from '@nestjs/common';
import axios from 'axios';
import { BomRequest } from 'src/models/bom.request';
import { BomResponse } from 'src/models/bom.response';
import { WastageDataRequest } from 'src/models/wastageData.request';
import { WastageDataResponse } from 'src/models/wastageData.response';
import { FeatureDescRequest } from 'src/models/featuredesc.request';
import { FeatureDescResponse } from 'src/models/featuredesc.response';
import { MetainfoBomRequest } from 'src/models/metaInfoBom.request';
import { MetainfoBomResponse } from 'src/models/metaInfoBom.response';
import 'dotenv/config';
@Injectable()
export class BomDetailsClient {
      constructor() { }

      async getBomData(input: BomRequest): Promise<BomResponse[]> {
            try {
                  const url = process.env.BASE_URL + '/m3api-rest/execute/PMS100MI/SelMaterials?CONO=' + process.env.COMPANY_NUMBER + '&FACI=' +
                  input.FACI + '&MFNO=' + input.MFNO;
                  const response = await axios({method: 'GET', url, auth: { username: process.env.USER_NAME, password: process.env.PASSWORD},
                  headers: { 'Content-Type': 'application/json' } });
                  if (response.data.MIRecord.length > 0) {
                        return response.data.MIRecord.map(val => {
                              const obj = {};
                              val.NameValue.forEach(subval => {
                                    obj[subval.Name] = subval.Value;
                              });
                              return obj;
                        });
                  } else {
                        return null;
                  }
            } catch (err) {
                  return null;
            }
      }

      async getWastageData(input: WastageDataRequest): Promise<WastageDataResponse> {
            try {
                  const url = process.env.BASE_URL + '/m3api-rest/execute/MDBREADMI/GetMWOMATX3;returncols=MESQ,WAPC,PEUN?CONO=' +
                  process.env.COMPANY_NUMBER + '&FACI=' + input.FACI + '&MFNO=' + input.MFNO + '&PRNO=' + input.PRNO + '&MSEQ=' + input.MSEQ;

                  const response = await axios({method: 'GET', url, auth: { username: process.env.USER_NAME, password: process.env.PASSWORD},
                  headers: { 'Content-Type': 'application/json' } });

                  if (response.data.MIRecord.length > 0) {
                        return response.data.MIRecord.map(val => {
                              const obj = {};
                              val.NameValue.forEach(subval => {
                                    obj[subval.Name] = subval.Value;
                              });
                              return obj;
                        })[0];
                  } else {
                        return null;
                  }
            } catch (err) {
                  return null;
            }
      }

      async getFeatureDescription(input: FeatureDescRequest): Promise<FeatureDescResponse> {
            try {
                  const url = process.env.BASE_URL + '/m3api-rest/execute/MDBREADMI/GetMITMAHX1?CONO=' + process.env.COMPANY_NUMBER +
                  '&ITNO=' + input.ITNO;

                  const response = await axios({method: 'GET', url, auth: { username: process.env.USER_NAME, password: process.env.PASSWORD},
                  headers: { 'Content-Type': 'application/json' } });

                  if (response.data.MIRecord.length > 0) {
                        return response.data.MIRecord.map(val => {
                              const obj = {};
                              val.NameValue.forEach(subval => {
                                    obj[subval.Name] = subval.Value;
                              });
                              return obj;
                        })[0];
                  } else {
                        return null;
                  }
            } catch (err) {
                  return null;
            }
      }

      async getMetainfo(input: MetainfoBomRequest): Promise<MetainfoBomResponse> {
            try {
                  const url = process.env.BASE_URL + '/m3api-rest/execute/PDS050MI/Get?CONO=' + process.env.COMPANY_NUMBER + '&OPTN=' + input.OPTN;

                  const response = await axios({method: 'GET', url, auth: { username: process.env.USER_NAME, password: process.env.PASSWORD},
                  headers: { 'Content-Type': 'application/json' } });
                  if (response.data.MIRecord.length > 0) {
                        return response.data.MIRecord.map(val => {
                              const obj = {};
                              val.NameValue.forEach(subval => {
                                    obj[subval.Name] = subval.Value;
                              });
                              return obj;
                        })[0];
                  } else {
                        return null;
                  }
            } catch (err) {
                  return null;
            }
      }
}
