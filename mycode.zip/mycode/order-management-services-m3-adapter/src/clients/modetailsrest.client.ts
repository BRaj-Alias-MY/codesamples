import { Injectable } from '@nestjs/common';
import axios from 'axios';
import 'dotenv/config';
import { PackingDetailsRequest } from 'src/models/packingdetails.request';
import { BussinesAreaCodeRequest } from 'src/models/bussinessareacode.request';
import { BuyerDescriptionRequest } from 'src/models/buyerdescription.request';
import { PackingDetailsResponse } from 'src/models/packingdetails.response';
import { BuyerAreaCodeResponse } from 'src/models/bussinessareacode.response';
import { BuyerDescriptionResponse } from 'src/models/buyerdescription.response';

@Injectable()
export class MoDetailsRestClient {
    // MoDetail Rest Service Calls

    // To Get packing method,destination,CPO
    async getPackingDetails(inputData: PackingDetailsRequest): Promise<PackingDetailsResponse> {
        try {
            const auth = 'Basic ' + Buffer.from(`${process.env.USER_NAME}:${process.env.PASSWORD}`).toString('base64');
            const headersRequest = {
                Authorization: `${auth}`,
            };

            const path = `${process.env.BASE_URL}` + '/m3api-rest/execute/OIS100MI/GetLine?CONO=' + `${process.env.COMPANY_NUMBER}` 
            + '&ORNO=' + inputData.CustomerOrderNo + '&PONR=' + inputData.CustomerOrderLineNo;
            const response = await axios.get(path, { headers: headersRequest });
            if (response.data) {
                if (response.data.MIRecord) {
                    if (response.data.MIRecord[0].NameValue) {
                        return response.data.MIRecord.map( (record) => {
                            const respObj = {};
                            record.NameValue.forEach(element => {
                                respObj[element.Name] = element.Value;
                            });
                            return respObj;
                        })[0];
                    } else {
                        return null;
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (error) {
            return error;
        }
    }

    // To Get Business Area Code
    async getBusinessAreaCode(inputData: BussinesAreaCodeRequest): Promise<BuyerAreaCodeResponse> {
        try {
            const auth = 'Basic ' + Buffer.from(`${process.env.USER_NAME}:${process.env.PASSWORD}`).toString('base64');
            const headersRequest = {
                Authorization: `${auth}`,
            };
            const path = `${process.env.BASE_URL}` + '/m3api-rest/execute/MDBREADMI/GetMITMASX1?CONO=' + 
            `${process.env.COMPANY_NUMBER}` + '&ITNO=' + inputData.ProductSKU;

            const response = await axios.get(path, { headers: headersRequest });
            if (response.data) {
                if (response.data.MIRecord) {
                    if (response.data.MIRecord[0].NameValue) {
                        return response.data.MIRecord.map( (record) => {
                            const respObj = {};
                            record.NameValue.forEach(element => {
                                respObj[element.Name] = element.Value;
                            });
                            return respObj;
                        })[0];
                    } else {
                        return null;
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (error) {
            return error;
        }
    }

    // To Get Buyer Description
    async getBuyerDescription(inputData: BuyerDescriptionRequest): Promise<BuyerDescriptionResponse> {
        try {
            const auth = 'Basic ' + Buffer.from(`${process.env.USER_NAME}:${process.env.PASSWORD}`).toString('base64');
            const headersRequest = {
                Authorization: `${auth}`,
            };
            const path = `${process.env.BASE_URL}` + '/m3api-rest/execute/CRS036MI/LstBusinessArea?CONO=' + `${process.env.COMPANY_NUMBER}` +
             '&FRBU=' + inputData.BusinessAreaCode + '&TOBU=' + inputData.BusinessAreaCode;

            const response = await axios.get(path, { headers: headersRequest });
            if (response.data) {
                if (response.data.MIRecord) {
                    if (response.data.MIRecord[0].NameValue) {
                        return response.data.MIRecord.map( (record) => {
                            const respObj = {};
                            record.NameValue.forEach(element => {
                                respObj[element.Name] = element.Value;
                            });
                            return respObj;
                        })[0];
                    } else {
                        return null;
                    }
                } else {
                    return null;
                }
            } else {
                return null;
            }
        } catch (error) {
            return error;
        }
    }

}
