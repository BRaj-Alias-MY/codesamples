import { Injectable } from '@nestjs/common';
import 'dotenv/config';
import { OperationsRequest } from 'src/models/operations.request';
import { OperationsResponse } from 'src/models/operations.response';

@Injectable()
export class OperationsClient {
      constructor() {  }

      async getOperationsData(operationsRequest: OperationsRequest): Promise<OperationsResponse[]> {
        const axios = require('axios');
        //const operationsResponse = new OperationsResponse();
        const url = process.env.BASE_URL+'/m3api-rest/execute/PMS100MI/SelOperations?CONO='+process.env.COMPANY_NUMBER+'&FACI='+operationsRequest.FACI+'&MFNO='+operationsRequest.MFNO+'&PRNO='+operationsRequest.PRNO;
        return await axios({
            method: 'GET',
            url: url,
            auth: {
                username: process.env.USER_NAME,
                password: process.env.PASSWORD,
            },
            headers: {
                'Content-Type': 'application/json'
            }
        }).then(async response=>{
            return await response.data.MIRecord.map(operation=>{ 
                let res = {}; 
                operation.NameValue.forEach(field=>{ 
                    //if( operationsResponse.responseArrayKeys.find(res=> field.Name==res ) )
                        res[field.Name] = field.Value;
                });
                return res;
            });
        }).catch(err=>{
            //console.log(err);
            return null;
        });
    }
}