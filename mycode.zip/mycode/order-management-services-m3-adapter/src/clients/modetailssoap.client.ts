import { Injectable } from '@nestjs/common';
import { MoDetailsRequest } from 'src/models/modetails.request';
import { MoDetailsSoapResponse } from 'src/models/modetailssoap.response';
import 'dotenv/config';

@Injectable()
export class MoDetailsSoapClient {
    // MoDetail Soap Service Call
    async getMoDetailsResponse(inputData: MoDetailsRequest): Promise <MoDetailsSoapResponse[]> {
        const soap = require('soap');
        try {
            const auth = 'Basic ' + Buffer.from(`${process.env.USER_NAME}:${process.env.PASSWORD}`).toString('base64');
            return await new Promise((resolve , reject) => {
                soap.createClient(`${process.env.BASE_URL}` + `${process.env.WSDL_URL}`, (err, client) => {
                    if (err) {
                        return reject(null);
                    }
                    client.addHttpHeader('Authorization', auth);
                    client.MOData(inputData, (error, result) => {
                        if (error) {
                            return reject(null);
                        } else {
                            if (result.new1Collection) {
                                return resolve(result.new1Collection.new1Item);
                            } else {
                                return reject(null);
                            }
                        }
                    });
                });
            });
        } catch (err) {
            return null;
        }
    }
}
