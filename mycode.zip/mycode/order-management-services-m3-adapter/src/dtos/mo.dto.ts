import { ApiModelProperty } from '@nestjs/swagger'
export class ProductsInfoss {
    @ApiModelProperty()
    product_sku: string;
    @ApiModelProperty()
    product_name: string;
    @ApiModelProperty()
    product_desc: string;
    @ApiModelProperty()
    color_name: string;
    @ApiModelProperty()
    color_desc: string;
    @ApiModelProperty()
    size_name: string;
    @ApiModelProperty()
    zfeature_name: string;
    @ApiModelProperty()
    size_desc: string;
    @ApiModelProperty()
    zfeature_desc: string;
    @ApiModelProperty()
    style: string;
    @ApiModelProperty()
    customer_style_no: string;


}
export class MoItemss {
    @ApiModelProperty()
    material_item_code: string;
    @ApiModelProperty()
    material_sequence: string;
    @ApiModelProperty()
    consumption: string;
    @ApiModelProperty()
    operation_code: string;
    @ApiModelProperty()
    uom: string;
    @ApiModelProperty()
    wastage_perc: string;

}
export class ItemsInfoss {
    @ApiModelProperty()
    item_desc: string;
    @ApiModelProperty()
    color_code: string;
    @ApiModelProperty()
    size_code: string;
    @ApiModelProperty()
    z_code: string;
    @ApiModelProperty()
    color_desc: string;
    @ApiModelProperty()
    size_desc: string;
    @ApiModelProperty()
    z_feature_desc: string;
    @ApiModelProperty()
    material_mo_unique_ref_id: string;
    @ApiModelProperty()
    material_item_code: string;
}
export class MoOperationss {
    @ApiModelProperty()
    op_mo_unique_ref_id: string;
    @ApiModelProperty()
    operation_code: string;
    @ApiModelProperty()
    operation_desc: string;
    @ApiModelProperty()
    operation_type: string;
    @ApiModelProperty()
    smv: string;
    @ApiModelProperty()
    workstation_id: string;

}
export class MoDetailss {
    @ApiModelProperty()
    mo_number: string;
    @ApiModelProperty()
    vpo: string;
    @ApiModelProperty()
    customer_order_no: string;
    @ApiModelProperty()
    customer_order_line_no: string;
    @ApiModelProperty()
    packing_method: string;
    @ApiModelProperty()
    destination: string;
    @ApiModelProperty()
    cpo: string;
    @ApiModelProperty()
    schedule: string;
    @ApiModelProperty()
    mo_status: string;
    @ApiModelProperty()
    max_operations: string;
    @ApiModelProperty()
    max_status_operated: string;
    @ApiModelProperty()
    buyer_desc: string;
    @ApiModelProperty()
    plant_code: string;
    @ApiModelProperty()
    business_area_code: string;
    @ApiModelProperty()
    mo_quantity: string;
    @ApiModelProperty()
    planned_delivery_date: string;
    @ApiModelProperty()
    requested_planned_delivery_date: string;
    @ApiModelProperty()
    planned_cut_date: string;
    @ApiModelProperty()
    end_date: string;
    @ApiModelProperty()
    transaction_id: string;
    @ApiModelProperty()
    po_status: boolean;
    @ApiModelProperty()
    po_number: string;
    @ApiModelProperty()
    isActive: boolean;
    @ApiModelProperty()
    omsProductsInfos: ProductsInfoss
    @ApiModelProperty({ "isArray": true })
    omsMoItemss: MoItemss[]
    @ApiModelProperty({ "isArray": true })
    omsItemInfos: ItemsInfoss[]
    @ApiModelProperty({ "isArray": true })
    omsMoOperationss: MoOperationss[]

}