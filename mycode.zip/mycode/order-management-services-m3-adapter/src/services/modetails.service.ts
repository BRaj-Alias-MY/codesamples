import { Injectable } from '@nestjs/common';
import { MoDetailsRequest } from 'src/models/modetails.request';
import { MoDetailsSoapResponse } from 'src/models/modetailssoap.response';
import { MoDetailsSoapClient } from 'src/clients/modetailssoap.client';

@Injectable()
export class MoDetailsService {

    constructor(private readonly moDetailsClient: MoDetailsSoapClient) {}

    // Call MoDetails Client
    async callMoDetailsClient(inputData: MoDetailsRequest): Promise <MoDetailsSoapResponse[]> {
        try {
            const moList = await this.moDetailsClient.getMoDetailsResponse(inputData);
            return moList;
        } catch (err) {
            return err;
        }
    }
}
