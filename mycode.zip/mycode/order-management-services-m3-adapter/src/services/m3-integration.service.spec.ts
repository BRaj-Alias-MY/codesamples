import { Test, TestingModule } from '@nestjs/testing';
import { M3IntegrationService } from './m3-integration.service';

describe('M3IntegrationService', () => {
  let service: M3IntegrationService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [M3IntegrationService],
    }).compile();

    service = module.get<M3IntegrationService>(M3IntegrationService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
