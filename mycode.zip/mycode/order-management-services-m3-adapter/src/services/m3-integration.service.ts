import { BomDetailsClient } from '../clients/bomdetailsrest.client';
import { BussinesAreaCodeRequest } from '../models/bussinessareacode.request';
import { BuyerDescriptionRequest } from '../models/buyerdescription.request';
import { Controller, Post, Body, Injectable } from '@nestjs/common';
import { BomRequest } from '../models/bom.request'
import { FeatureDescRequest } from '../models/featureDesc.request';
import { MetainfoBomRequest } from '../models/metaInfoBom.request';
import { WastageDataRequest } from '../models/wastageData.request';
import { MoDetailsRequest } from '../models/modetails.request';
import { MoDetailsRestClient } from '../clients/modetailsrest.client';
import { MoDetailss, MoItemss, ItemsInfoss, MoOperationss, ProductsInfoss } from '../dtos/mo.dto';
import { MoDetailsSoapClient } from '../clients/modetailssoap.client';
import { OperationsClient } from '../clients/operations.client';
import { OperationsRequest } from '../models/operations.request';
import { PackingDetailsRequest } from '../models/packingdetails.request';
import { PackingDetailsResponse } from '../models/packingdetails.response';
import 'dotenv/config';
import axios from 'axios';

@Injectable()
export class M3IntegrationService {

    constructor() { }
    async moSyncData(input: MoDetailsRequest) {
        try {
            const moDetails = new MoDetailsSoapClient();
            const inputMo = new MoDetailsRequest();
            inputMo.Facility = input.Facility
            inputMo.FromDate = input.FromDate
            inputMo.ToDate = input.ToDate
            const mo = await moDetails.getMoDetailsResponse(inputMo);
            let i = 0;
            Array.from(mo.keys()).forEach(async key => {
                const moModel = new MoDetailss()
                const productsInfosss = new ProductsInfoss()
                const packingResponse = new PackingDetailsResponse()
                productsInfosss.color_name = mo[key]['COLORNAME'].toString()
                productsInfosss.color_desc = mo[key]['COLOURDESC']
                productsInfosss.customer_style_no = null
                productsInfosss.style = mo[key]['STYLE']
                productsInfosss.product_desc = mo[key]['PRDDESC']
                productsInfosss.product_name = mo[key]['PRDNAME']
                productsInfosss.product_sku = mo[key]['PRODUCT']
                productsInfosss.size_desc = mo[key]['SIZEDESC']
                productsInfosss.size_name = mo[key]['SIZENAME']
                productsInfosss.zfeature_desc = mo[key]['ZDESC']
                productsInfosss.zfeature_name = mo[key]['ZNAME']
                moModel.omsProductsInfos = productsInfosss
                const moDetailsRestClient = new MoDetailsRestClient()
                const packingRequest = new PackingDetailsRequest();
                packingRequest.CustomerOrderNo = mo[key]['REFERENCEORDER'];
                packingRequest.CustomerOrderLineNo = mo[key]['REFORDLINE'];

                //GET PACKING DETAILS - PACKIGN METHOD-DESTINATION-CPO
                if (packingRequest) {
                    const packingDetails = await moDetailsRestClient.getPackingDetails(packingRequest);
                    if (packingDetails) {
                        //console.log(packingDetails['TEPA'])
                        moModel.packing_method = packingDetails['TEPA'] ? packingDetails['TEPA'] : ''
                        moModel.destination = packingDetails['ADID'] ? packingDetails['ADID'] : ''
                        moModel.cpo = packingDetails['CUOR'] ? packingDetails['CUOR'] : ''

                    }
                }
                //GET BUSINESS AREA CODE
                const businessAreaCode = new BussinesAreaCodeRequest()
                businessAreaCode.ProductSKU = mo[key]['PRODUCT'];
                if (businessAreaCode) {
                    const businessAreaCodeObject = await moDetailsRestClient.getBusinessAreaCode(businessAreaCode)
                    if (businessAreaCodeObject) {
                        moModel.business_area_code = businessAreaCodeObject['BUAR']
                    }
                }
                //GET BUYDER DESCRIPTION
                const buyerDescription = new BuyerDescriptionRequest();
                buyerDescription.BusinessAreaCode = moModel.business_area_code;
                const buyerDesc = await moDetailsRestClient.getBuyerDescription(buyerDescription)
                if (buyerDesc) {
                    moModel.buyer_desc = buyerDesc['TX40']
                }


                //GETTING BOM DETAILS
                const bomClient = new BomDetailsClient();
                const getBomDataRequest = new BomRequest();
                getBomDataRequest.MFNO = mo[key]['MONUMBER']
                const getBomDataObject = await bomClient.getBomData(getBomDataRequest)
                let moItemList = []
                let itemList = []
                for (let moItem in getBomDataObject) {
                    const moItemss = new MoItemss()
                    moItemss.material_item_code = getBomDataObject[moItem]['MTNO']
                    moItemss.material_sequence = getBomDataObject[moItem]['MSEQ']
                    moItemss.consumption = getBomDataObject[moItem]['CNQT']
                    moItemss.operation_code = getBomDataObject[moItem]['OPNO']
                    moItemss.wastage_perc = ''
                    moItemss.material_item_code = getBomDataObject[moItem]['MTNO']

                    //GETTING BOM WASTAGE
                    const getWastage = new WastageDataRequest();
                    getWastage.MFNO = getBomDataObject[moItem]['MFNO']
                    getWastage.PRNO = getBomDataObject[moItem]['PRNO']
                    getWastage.MSEQ = getBomDataObject[moItem]['MSEQ']
                    const bomClientWastage = new BomDetailsClient();
                    const bomWaste = await bomClientWastage.getWastageData(getWastage);
                    if (bomWaste['WAPC']) {
                        moItemss.wastage_perc = bomWaste['WAPC'] ? bomWaste['WAPC'] : ''
                    }
                    if (bomWaste['PEUN']) {
                        moItemss.uom = bomWaste['PEUN'] ? bomWaste['PEUN'] : ''
                    }

                    const getFeatureRequest = new FeatureDescRequest();
                    getFeatureRequest.ITNO = getBomDataObject[moItem]['MTNO'];
                    const bomFeatureClient = new BomDetailsClient();
                    const bomFeatureDesc = await bomFeatureClient.getFeatureDescription(getFeatureRequest)
                    const itemInfoObject = new ItemsInfoss();

                    if (bomFeatureDesc) {
                        const getMetaRequestSize = new MetainfoBomRequest();
                        const getMetaRequestColor = new MetainfoBomRequest();
                        const getMetaRequestZcode = new MetainfoBomRequest();

                        if (bomFeatureDesc["OPTX"]) {
                            getMetaRequestSize.OPTN = bomFeatureDesc["OPTX"];
                            const getMetaObjectforSize = await bomFeatureClient.getMetainfo(getMetaRequestSize)
                            if (getMetaObjectforSize) {
                                itemInfoObject.size_desc = (getMetaObjectforSize["TX30"]) ? getMetaObjectforSize["TX30"] : ''
                            }
                            itemInfoObject.size_code = bomFeatureDesc["OPTX"]
                        }

                        if (bomFeatureDesc["OPTY"]) {
                            getMetaRequestColor.OPTN = bomFeatureDesc["OPTY"];
                            const getMetaObjectforColor = await bomFeatureClient.getMetainfo(getMetaRequestColor)
                            if (getMetaObjectforColor) {
                                itemInfoObject.color_desc = (getMetaObjectforColor["TX30"]) ? getMetaObjectforColor["TX30"] : ''
                            }
                            itemInfoObject.color_code = bomFeatureDesc["OPTY"]
                        }

                        if (bomFeatureDesc["OPTZ"]) {
                            getMetaRequestZcode.OPTN = bomFeatureDesc["OPTZ"];
                            const getMetaObjectforZcode = await bomFeatureClient.getMetainfo(getMetaRequestZcode)
                            if (getMetaObjectforZcode) {
                                itemInfoObject.z_feature_desc = (getMetaObjectforZcode["TX30"]) ? getMetaObjectforZcode["TX30"] : ''
                            }
                            itemInfoObject.z_code = bomFeatureDesc["OPTZ"]
                        }
                    } else {
                        itemInfoObject.size_desc = ''
                        itemInfoObject.size_code = ''
                        itemInfoObject.color_desc = ''
                        itemInfoObject.color_code = ''
                        itemInfoObject.z_feature_desc = ''
                        itemInfoObject.z_code = ''
                    }

                    itemInfoObject.material_item_code = getBomDataObject[moItem]['MTNO'];
                    itemInfoObject.material_mo_unique_ref_id = getBomDataObject[moItem]['MTNO'] + getBomDataObject[moItem]['MTNO'] + i
                    itemList.push(itemInfoObject)
                    moModel.omsItemInfos = itemList
                    moItemList.push(moItemss)
                    moModel.omsMoItemss = moItemList


                }

                //GETTING MO-OPERATIONS

                const operationsRequest = new OperationsRequest()
                operationsRequest.MFNO = mo[key]['MONUMBER']
                operationsRequest.PRNO = mo[key]['PRODUCT']
                let moOperationList = []
                const getOperation = new OperationsClient()
                const getOperationObject = await getOperation.getOperationsData(operationsRequest)

                if (getOperationObject) {
                    getOperationObject.map(operation => {
                        const moOperation = new MoOperationss()
                        moOperation.operation_desc = operation["OPDS"] ? operation["OPDS"] : ''
                        moOperation.workstation_id = operation["PLG1"] ? operation["PLG1"] : ''
                        moOperation.smv = operation["PITI"] ? operation["PITI"] : ''
                        moOperation.operation_code = operation["OPNO"] ? operation["OPNO"] : ''
                        moOperation.operation_type = ''
                        moOperation.op_mo_unique_ref_id = operation["OPNO"] + operation["MFNO"]
                        moOperationList.push(moOperation)

                    })
                    moModel.omsMoOperationss = moOperationList

                }
                const productsInfos_list = moModel.omsProductsInfos
                const moItems_list = moModel.omsMoItemss
                const itemInfos_list = moModel.omsItemInfos
                const moOperation_list = moModel.omsMoOperationss

                const arr =
                {
                    mo_number: mo[key]['MONUMBER'],
                    vpo: mo[key]['VPO'] ? mo[key]['VPO'] : '',
                    customer_order_no: mo[key]['REFERENCEORDER'] ? mo[key]['REFERENCEORDER'] : '',
                    customer_order_line_no: mo[key]['REFORDLINE'] ? mo[key]['REFORDLINE'] : '',
                    packing_method: moModel.packing_method,
                    destination: moModel.destination,
                    cpo: moModel.cpo,
                    schedule: mo[key]['SCHEDULE'] ? mo[key]['SCHEDULE'] : '',
                    mo_status: mo[key]['MOSTS'],
                    max_operations: mo[key]['MAXOPERATIONSTS'],
                    max_status_operated: '',
                    buyer_desc: moModel.buyer_desc,
                    plant_code: `${process.env.PLANT_CODE}`,
                    business_area_code: moModel.business_area_code,
                    mo_quantity: mo[key]['MOQTY'],
                    planned_delivery_date: mo[key]['COPLANDELDATE'],
                    requested_planned_delivery_date: mo[key]['COREQUESTEDDELDATE'],
                    planned_cut_date: mo[key]['COPLANDELDATE'],
                    end_date: '',
                    transaction_id: mo[key]['MONUMBER'] + moModel.buyer_desc,
                    po_number: '',
                    deactivated_date: '',
                    omsProductsInfos: productsInfos_list,
                    omsMoItemss: moItems_list,
                    omsItemInfos: itemInfos_list,
                    omsMoOperationss: moOperation_list


                }

                await axios.post(`${process.env.MOSYNC_CLIENT_BASE_URL}`, arr).then(response => {
                    console.log(response.data)

                })



            })

        }
        catch (err) {
            return err
        }
    }
}
