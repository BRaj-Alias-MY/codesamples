import { BomDetailsClient } from 'src/clients/bomdetailsrest.client';
import { M3IntegrationController } from '../controllers/m3-integration.controller';
import { M3IntegrationService } from 'src/services/m3-integration.service';
import { MoDetailsController } from 'src/controllers/modetails.controller';
import { MoDetailsRestClient } from 'src/clients/modetailsrest.client';
import { MoDetailsService } from 'src/services/modetails.service';
import { MoDetailsSoapClient } from 'src/clients/modetailssoap.client';
import { Module } from '@nestjs/common';
import { OperationsClient } from 'src/clients/operations.client';





@Module({
    imports: [],
    controllers: [MoDetailsController, M3IntegrationController],
    providers: [MoDetailsService, MoDetailsSoapClient, MoDetailsRestClient, OperationsClient, BomDetailsClient, M3IntegrationService],

})

export class InfrastructureModule { }
