import { Controller, Post, Body} from '@nestjs/common';
import {M3IntegrationService} from 'src/services/m3-integration.service';
import {MoDetailsRequest} from 'src/models/modetails.request'

@Controller('m3-integration')
export class M3IntegrationController {
    constructor(private moService: M3IntegrationService) { }
    @Post('/moSync')
    async moSync(@Body() input: MoDetailsRequest) {
        return await this.moService.moSyncData(input)


}
}
