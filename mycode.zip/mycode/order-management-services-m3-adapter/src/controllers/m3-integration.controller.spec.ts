import { Test, TestingModule } from '@nestjs/testing';
import { M3IntegrationController } from './m3-integration.controller';

describe('M3Integration Controller', () => {
  let controller: M3IntegrationController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [M3IntegrationController],
    }).compile();

    controller = module.get<M3IntegrationController>(M3IntegrationController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
