import { Controller, Post, Body, Logger } from '@nestjs/common';
import { MoDetailsService } from '../services/modetails.service';
import { MoDetailsRequest } from 'src/models/modetails.request';
import { ModetailsResponse } from 'src/models/modetails.response';
import { MoDetailsRestClient } from 'src/clients/modetailsrest.client';

@Controller('modetailsservice')
export class MoDetailsController {
  private logger = new Logger('MoDetailsController');
  constructor(private readonly moDetailsService: MoDetailsService, private readonly restService: MoDetailsRestClient) {}

  @Post('soapservice')
  async callMoDetailsService(@Body() soapInputData: MoDetailsRequest): Promise <ModetailsResponse> {
    this.logger.log(JSON.stringify(soapInputData));
    const response = new ModetailsResponse();
    return await this.moDetailsService.callMoDetailsClient(soapInputData).then(
      soapresults => {
            if (soapresults) {
              response.status = true;
              response.data = soapresults;
              return response;
            } else {
              response.status = false;
              response.errorInfo = 'No Data Found';
              return response;
            }
          },
      ).catch(err => {
          response.status = false;
          response.errorInfo = err.message;
          return response;
      });
  }

  // @Post('getservicedata')
  // async getData(@Body() inputData: BuyerDescriptionRequest): Promise <PackingDetailsResponse> {
  //   this.logger.log(JSON.stringify(inputData));
  //   return await this.restService.getBuyerDescription(inputData).then(
  //     soapresults => {
  //           return soapresults;
  //       },
  //     ).catch(err => {
  //         return err;
  //     });
  // }
}
