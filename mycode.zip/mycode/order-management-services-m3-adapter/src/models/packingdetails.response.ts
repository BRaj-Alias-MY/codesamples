export class PackingDetailsResponse {
    PackingMethod: string;
    Destination: string;
    CustomerPurchaseOrder: string;
}
