import { ApiModelProperty } from '@nestjs/swagger';

export class MoDetailsRequest {
    @ApiModelProperty()
    Facility: string;
    @ApiModelProperty()
    FromDate: string;
    @ApiModelProperty()
    ToDate: string;
}
