export class BuyerDescriptionResponse {
    BuyerDescription: string;
}
