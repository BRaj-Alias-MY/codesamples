export class WastageDataRequest {

    FACI: string = `${process.env.PLANT_CODE}`; // Facility Id

    MFNO: string; // MO Number

    PRNO: string; // Product SKU

    MSEQ: string; // Material Sequence
}
