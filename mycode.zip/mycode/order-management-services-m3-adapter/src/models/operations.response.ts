export class OperationsResponse{
    OPDS: string
    MFNO: string
    PLG1: string
    PITI: string
    OPNO: string
    //responseArrayKeys = ['OPDS','MFNO','PLG1','PITI','OPNO'];
}