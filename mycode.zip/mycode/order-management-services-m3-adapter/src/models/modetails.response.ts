import { MoDetailsSoapResponse } from 'src/models/modetailssoap.response';

export class ModetailsResponse {
    status: boolean;
    data?: MoDetailsSoapResponse[];
    errorInfo?: string;
}
