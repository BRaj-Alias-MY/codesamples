export class BuyerAreaCodeResponse {
    BusinessAreaCode: string;
}
