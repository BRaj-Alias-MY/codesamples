import { ApiModelProperty } from '@nestjs/swagger';

export class BussinesAreaCodeRequest {
    @ApiModelProperty()
    ProductSKU: string;
}
