export class MetainfoBomResponse {
      CONO: string;
      OPTN: string;
      TX30: string;
      TX15: string;
      SQNU: string;
      XCOC: string;
      OGRP: string;
      MTCT: string;
}
