export class FeatureDescResponse {
      CONO: string;
      ITNO: string;
      CHID: string;
      CHNO: string;
      FTIY: string;
      FTIX: string;
      FTIZ: string;
      LMDT: string;
      OPTX: string;
      OPTY: string;
      OPTZ: string;
      RGDT: string;
      RGTM: string;
      SECH: string;
      SQFX: string;
      SQFY: string;
      SQFZ: string;
      SQNX: string;
      SQNY: string;
      SQNZ: string;
      STYN: string;
      TX15: string;
      TY15: string;
      TZ15: string;
}