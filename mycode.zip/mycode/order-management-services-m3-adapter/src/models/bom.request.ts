export class BomRequest {

    FACI: string = `${process.env.PLANT_CODE}`; // Facility Id

    MFNO: string; // MO Number
}