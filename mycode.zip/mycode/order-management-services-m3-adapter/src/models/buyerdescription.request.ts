import { ApiModelProperty } from '@nestjs/swagger';

export class BuyerDescriptionRequest {
    @ApiModelProperty()
    BusinessAreaCode: string;
}
