export class MoDetailsSoapResponse {

    MONUMBER: string;

    MOQTY: string;

    STARTDATE: string;

    VPO: string;

    COLORNAME: boolean;

    COLOURDESC: string;

    SIZENAME: string;

    SIZEDESC: string;

    ZNAME: string;

    ZDESC: string;

    SCHEDULE: string;

    STYLE: string;

    PRODUCT: string;

    PRDNAME: string;

    PRDDESC: string;

    REFERENCEORDER: string;

    REFORDLINE: string;

    MOSTS: string;

    MAXOPERATIONSTS: string;

    COPLANDELDATE: string;

    COREQUESTEDDELDATE: string;
}
