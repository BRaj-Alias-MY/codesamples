import { ApiModelProperty } from '@nestjs/swagger';

export class PackingDetailsRequest {
    @ApiModelProperty()
    CustomerOrderNo: string;
    @ApiModelProperty()
    CustomerOrderLineNo: string;
}
