export class BomResponse {
    MESQ: string; //Material Sequence

    MFNO: string; // MO Number

    MTNO: string; // Material Item Code

    CNQT: string; // Consumption

    OPNO: string; // Operation Code

    PRNO: string; // Finish good SKU

    ITDS: string; // Item Description

}