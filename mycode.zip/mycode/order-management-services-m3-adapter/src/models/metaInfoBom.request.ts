export class MetainfoBomRequest {
      OPTN: string;
}