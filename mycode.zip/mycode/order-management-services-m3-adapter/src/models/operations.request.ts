
export class OperationsRequest {
    CONO: string
    FACI: string = `${process.env.PLANT_CODE}`
    MFNO: string
    PRNO: string
}


