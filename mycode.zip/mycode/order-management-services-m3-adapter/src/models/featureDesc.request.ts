export class FeatureDescRequest {
      ITNO: string;
}
