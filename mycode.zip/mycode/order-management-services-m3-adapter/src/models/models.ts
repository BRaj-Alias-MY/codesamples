export type ProductsInfo = {
  color_name: string;
  customer_style_no?: string;
  product_desc?: string;
  product_name?: string;
  product_sku?: string;
  size_desc?: string;
  size_name?: string;
  style?: string;
  zfeature_desc?: string;
  zfeature_name?: string;
};

export type ItemInfo = {
  material_item_code: string;
  item_desc?: string;
  color_code?: string;
  size_code?: string;
  z_code?: string;
  color_desc?: string;
  size_desc?: string;
  z_feature_desc?: string;
};

export type MoItems = {
  material_item_code: string;
  material_sequence?: string;
  consumption?: string;
  operation_code?: string;
  wastage_perc?: number;
  uom?: string;
};

export type PoOperations = {
  unqiue_identitfier: string;
  operation_code?: string;
  operation_type?: string;
  operation_desc?: string;
  smv?: string;
  workstation_id?: string;
};

export type MoDetailss = {
  mo_number: string;
  business_area_code?: string;
  buyer_desc?: string;
  cpo?: string;
  customer_order_line_no?: string;
  customer_order_no?: string;
  destination?: string;
  end_date?: string;
  max_operations?: number;
  max_status_operated?: string;
  mo_quantity?: number;
  mo_status?: string;
  packing_method?: string;
  planned_cut_date?: string;
  planned_delivery_date?: string;
  plant_code?: string;
  requested_planned_delivery_date?: string;
  schedule?: string;
  vpo?: string;
  productsInfos?: ProductsInfo;
  itemInfos?: ItemInfo;
  moItemss?: MoItems;
  poOperationss?: PoOperations;
};

export type MoDetails = void;

