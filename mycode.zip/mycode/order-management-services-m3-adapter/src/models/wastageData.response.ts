export class WastageDataResponse {
    MESQ: string; //Material Sequence

    WAPC: string; // Wastage Percentage

    PEUN: string; // UOM

}