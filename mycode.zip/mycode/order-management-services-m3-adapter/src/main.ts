import { AppModule } from './app.module';
import { NestFactory } from '@nestjs/core';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';

import 'dotenv/config';
import { Logger } from '@nestjs/common';

const port = process.env.PORT || 8000

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  const options = new DocumentBuilder()
    .setTitle('OrderManagementService ')
    .setDescription('The SFCS 2.0 API description')
    .setVersion('2.0')
    .addTag('sfcs')
    .build();
  const document = SwaggerModule.createDocument(app, options);
  SwaggerModule.setup('api', app, document);


  await app.listen(port);
  Logger.log(`Server running at port ${port}`)
}
bootstrap();
