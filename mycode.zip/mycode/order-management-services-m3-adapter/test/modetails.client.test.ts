import { Test, TestingModule } from '@nestjs/testing';
import { MoDetailsSoapClient } from '../src/clients/modetailssoap.client';
import { MoDetailsRequest } from '../src/models/modetails.request';
import { PackingDetailsRequest } from '../src/models/packingdetails.request';
import { MoDetailsRestClient } from '../src/clients/modetailsrest.client';
import { BussinesAreaCodeRequest } from '../src/models/bussinessareacode.request';
import { BuyerDescriptionRequest } from '../src/models/buyerdescription.request';

describe('MoDetailsController', () => {
  let moDetailsSoapClient: MoDetailsSoapClient;
  let moDetailsRestClient: MoDetailsRestClient;

  const moDetailsRequest = new MoDetailsRequest();
  moDetailsRequest.Facility = 'EKG';
  moDetailsRequest.FromDate = '20180501';
  moDetailsRequest.ToDate = '20180601';

  const packingDetailsRequest = new PackingDetailsRequest();
  packingDetailsRequest.CustomerOrderNo = '0014175313';
  packingDetailsRequest.CustomerOrderLineNo = '3';

  const businessAreaCodeDetailsRequest = new BussinesAreaCodeRequest();
  businessAreaCodeDetailsRequest.ProductSKU = 'ABZ04SS8   0412';

  const buyerDescriptionDetailsRequest = new BuyerDescriptionRequest();
  buyerDescriptionDetailsRequest.BusinessAreaCode = 'T47';

  beforeEach(async () => {
    jest.setTimeout(30000);
    const app: TestingModule = await Test.createTestingModule({
      controllers: [],
      providers: [MoDetailsSoapClient, MoDetailsRestClient],
    }).compile();

    moDetailsSoapClient = app.get<MoDetailsSoapClient>(MoDetailsSoapClient);
    moDetailsRestClient = app.get<MoDetailsRestClient>(MoDetailsRestClient);
  });

  // Calling SOAP service
  describe('Call MoDetails Soap Service', () => {
    it('should return Mo Objects List', async () => {
      expect(await moDetailsSoapClient.getMoDetailsResponse(moDetailsRequest)).toBeTruthy();
    });
  });

  // Calling REST service for packmethod details
  describe('Call PackmethodDetails Rest Service', () => {
    it('should return any Packmethod object', async () => {
      expect(await moDetailsRestClient.getPackingDetails(packingDetailsRequest)).toBeTruthy();
    });
  });

  // Calling REST service for Bussiness area details
  describe('Call BussinessAreaDetails Rest Service', () => {
    it('should return BussinessArea object', async () => {
      expect(await moDetailsRestClient.getBusinessAreaCode(businessAreaCodeDetailsRequest)).toBeTruthy();
    });
  });

  // Calling REST service for Buyer Description details
  describe('Call  BuyerDescription Details Rest Service', () => {
    it('should return BuyerDescription object', async () => {
      expect(await moDetailsRestClient.getBuyerDescription(buyerDescriptionDetailsRequest)).toBeTruthy();
    });
  });


});
