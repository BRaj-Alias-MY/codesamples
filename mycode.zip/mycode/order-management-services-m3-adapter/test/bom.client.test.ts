import { Test, TestingModule } from '@nestjs/testing';
import {BomDetailsClient} from '../src/clients/bomdetailsrest.client'
describe('BomDetailsClient', () => {
  let bomDetailsClient: BomDetailsClient;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [],
      providers: [BomDetailsClient],
    }).compile();
    bomDetailsClient = app.get<BomDetailsClient>(BomDetailsClient);
  });

  describe('getBomData', () => {
    it('should return an boolean if success', async () => {
      expect(await bomDetailsClient.getBomData({FACI: 'Q01', MFNO: '7512409'})).toBeTruthy();
    });
  });

  describe('getWastageData', () => {
    it('should return an boolean if success', async () => {
      expect(await bomDetailsClient.getWastageData({FACI: 'Q01', MFNO: '7512409', PRNO: 'M05083AB   0190', MSEQ: '30'})).toBeTruthy();
    });
  });

  describe('getFeatureDescription', () => {
    it('should return an boolean if success', async () => {
        expect(await bomDetailsClient.getFeatureDescription({ITNO: 'M05083AB   0190'})).toBeTruthy();
    });
  });

  describe('GetMetainfo', () => {
    it('should return an boolean if success', async () => {
        expect(await bomDetailsClient.getMetainfo({OPTN: 'VPO23'})).toBeTruthy();
    });
  });

});
