import { Test, TestingModule } from '@nestjs/testing';
import { OperationsClient } from './../src/clients/operations.client';
import { OperationsRequest  } from './../src/models/operations.request';

describe('OperationsClient', () => {
  let operationsClient  : OperationsClient;
  let operationsRequest = new OperationsRequest;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      imports : [],
      controllers: [],
      providers: [OperationsClient],
    }).compile();
    operationsClient = app.get<OperationsClient>(OperationsClient);
  });

  describe('getOperationsData', () => {
    operationsRequest.CONO = '200';
    operationsRequest.FACI = 'Q01';
    operationsRequest.MFNO = '7512409';
    operationsRequest.PRNO = 'M05083AB   0190';

    it('should return any response except null', async () => {
      expect(await operationsClient.getOperationsData(operationsRequest)).toBeTruthy();
    });
  });

});

