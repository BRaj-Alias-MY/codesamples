import { Injectable} from '@nestjs/common';
import {SectionDTO} from 'src/dtos/section.dto';
import { PmsSections } from 'src/entities/pms_sections';
import { PmsDepartments } from 'src/entities/pms_departments';
import { IdmsUserDetails } from 'src/entities/idms_user_details';
import { IdmsContact } from 'src/entities/idms_contact';

@Injectable()
export class SectionAdapter {
    public convertDtoToEntity(sectionobj :SectionDTO):PmsSections{
        const section = new PmsSections()
        section.section_code = sectionobj.section_code;
        section.section_name = sectionobj.section_name;

        section.departmentCode = new PmsDepartments()
        section.departmentCode.department_code = sectionobj.departmentCode;

        section.user = new IdmsUserDetails()
        if(sectionobj.user_uid){
            section.user.user_uid = sectionobj.user_uid;
        }

        section.user.first_name = sectionobj.first_name;
        section.user.middle_name = sectionobj.middle_name;
        section.user.last_name = sectionobj.last_name;
        section.user.gender = sectionobj.gender;
        section.user.ref_uid = sectionobj.ref_uid;
        section.user.uid_country = sectionobj.uid_country;
        section.user.date_of_birth = sectionobj.date_of_birth;

        section.user.contactU = new IdmsContact()
        if(sectionobj.contact_uid){
            section.user.contactU.contact_uid = sectionobj.contact_uid;
        }
        section.user.contactU.land_line_no = sectionobj.land_line_no;
        section.user.contactU.mobile_no = sectionobj.mobile_no;
        section.user.contactU.email = sectionobj.email;

        return section;
    }

    public convertEntityToDto(sectiondto : PmsSections):SectionDTO{
        let secdtoobj = new SectionDTO()
   
        secdtoobj.section_code = sectiondto.section_code;
        secdtoobj.section_name = sectiondto.section_name;
        secdtoobj.first_name = sectiondto.user.first_name;
        secdtoobj.middle_name = sectiondto.user.middle_name;
        secdtoobj.last_name   = sectiondto.user.last_name;
        secdtoobj.gender     = sectiondto.user.gender;
        secdtoobj.ref_uid    = sectiondto.user.ref_uid;
        secdtoobj.uid_country = sectiondto.user.uid_country;
        secdtoobj.date_of_birth = sectiondto.user.date_of_birth;
        secdtoobj.land_line_no = sectiondto.user.contactU.land_line_no;
        secdtoobj.mobile_no = sectiondto.user.contactU.mobile_no;
        secdtoobj.email = sectiondto.user.contactU.email;
        secdtoobj.user_uid = sectiondto.user.user_uid;
        secdtoobj.first_name = sectiondto.user.first_name;
        secdtoobj.middle_name = sectiondto.user.middle_name;
        secdtoobj.last_name = sectiondto.user.last_name;
        secdtoobj.gender = sectiondto.user.gender;
        secdtoobj.date_of_birth = sectiondto.user.date_of_birth;
        secdtoobj.departmentCode = sectiondto.departmentCode.department_code;
        secdtoobj.contact_uid = sectiondto.user.contactU.contact_uid;
        secdtoobj.land_line_no = sectiondto.user.contactU.land_line_no;
        secdtoobj.mobile_no = sectiondto.user.contactU.mobile_no;
        secdtoobj.email = sectiondto.user.contactU.email;

        return secdtoobj;
    }
    
}