import { ClusterDto } from 'src/dtos/cluster.dto';
import { PmsCluster } from 'src/entities/pms_cluster';
import { IdmsLocation } from 'src/entities/idms_location';
import { IdmsAddress } from 'src/entities/idms_address';
import { IdmsUserDetails } from 'src/entities/idms_user_details';
import { IdmsContact } from 'src/entities/idms_contact';

export class ClusterAdapter{

    public convertDtoToEntity(clusterDto : ClusterDto):PmsCluster{
        let clusterEntity = new PmsCluster();

        clusterEntity.cluster_code  = clusterDto.cluster_code;
        clusterEntity.cluster_name  = clusterDto.cluster_name;
        clusterEntity.corporateCode = clusterDto.corporate_code;
        clusterEntity.activated_date = clusterDto.activated_date;
        clusterEntity.isActive = true;

        clusterEntity.locationU = new IdmsLocation();
        clusterDto.location_uid ? clusterEntity.locationU.location_uid = clusterDto.location_uid : false;
        clusterEntity.locationU.location_type = clusterDto.location_type;
        clusterEntity.locationU.lat = clusterDto.lat;
        clusterEntity.locationU.long = clusterDto.long;

        clusterEntity.locationU.addressU = new IdmsAddress();
        clusterDto.address_uid ? clusterEntity.locationU.addressU.address_uid = clusterDto.address_uid : false;
        clusterEntity.locationU.addressU.door_no = clusterDto.location_type; 
        clusterEntity.locationU.addressU.address_line_1 = clusterDto.address_line_1; 
        clusterEntity.locationU.addressU.address_line_2 = clusterDto.address_line_2; 
        clusterEntity.locationU.addressU.land_mark = clusterDto.land_mark; 
        clusterEntity.locationU.addressU.state = clusterDto.state; 
        clusterEntity.locationU.addressU.country = clusterDto.country; 
        clusterEntity.locationU.addressU.zipcode = clusterDto.zipcode;       
      
        clusterEntity.userU = new IdmsUserDetails();
        clusterDto.user_uid ? clusterEntity.userU.user_uid = clusterDto.user_uid : false;
        clusterEntity.userU.first_name = clusterDto.first_name;
        clusterEntity.userU.middle_name = clusterDto.middle_name;
        clusterEntity.userU.last_name = clusterDto.last_name;
        clusterEntity.userU.gender = clusterDto.gender;
        clusterEntity.userU.ref_uid = clusterDto.ref_uid;
        clusterEntity.userU.uid_country = clusterDto.uid_country;
        clusterEntity.userU.date_of_birth = clusterDto.date_of_birth;
      
        clusterEntity.userU.contactU = new IdmsContact();
        clusterDto.contact_uid ? clusterEntity.userU.contactU.contact_uid = clusterDto.contact_uid : false;
        clusterEntity.userU.contactU.land_line_no = clusterDto.land_line_no;
        clusterEntity.userU.contactU.mobile_no = clusterDto.mobile_no;
        clusterEntity.userU.contactU.email = clusterDto.email;

        return clusterEntity;
    }

    public convertEntityToDto(clusterEntity : PmsCluster):ClusterDto{
        let clusterDto = new ClusterDto();
       
        clusterDto.cluster_code = clusterEntity.cluster_code;
        clusterDto.cluster_name = clusterEntity.cluster_name;
        clusterDto.cluster_code = clusterEntity.cluster_code ;
        clusterDto.corporate_code =clusterEntity.corporateCode.company_code ;
        clusterDto.corporate_name =clusterEntity.corporateCode.company_name ;
        clusterDto.activated_date =clusterEntity.activated_date ;
        clusterDto.isActive = clusterEntity.isActive;

        clusterDto.location_type =  clusterEntity.locationU.location_type ;
        clusterDto.lat =  clusterEntity.locationU.lat;
        clusterDto.long = clusterEntity.locationU.long ;

        clusterDto.door_no =  clusterEntity.locationU.addressU.door_no; 
        clusterDto.address_line_1 = clusterEntity.locationU.addressU.address_line_1; 
        clusterDto.address_line_2 = clusterEntity.locationU.addressU.address_line_2; 
        clusterDto.land_mark = clusterEntity.locationU.addressU.land_mark; 
        clusterDto.state = clusterEntity.locationU.addressU.state ; 
        clusterDto.country = clusterEntity.locationU.addressU.country; 
        clusterDto.zipcode = clusterEntity.locationU.addressU.zipcode ;       
      
        clusterDto.first_name = clusterEntity.userU.first_name;
        clusterDto.middle_name =  clusterEntity.userU.middle_name;
        clusterDto.last_name = clusterEntity.userU.last_name ;
        clusterDto.gender = clusterEntity.userU.gender;
        clusterDto.ref_uid = clusterEntity.userU.ref_uid;
        clusterDto.uid_country = clusterEntity.userU.uid_country ;
        clusterDto.date_of_birth =  clusterEntity.userU.date_of_birth ;
      
        clusterDto.land_line_no = clusterEntity.userU.contactU.land_line_no ;
        clusterDto.mobile_no = clusterEntity.userU.contactU.mobile_no ;
        clusterDto.email = clusterEntity.userU.contactU.email;

        clusterDto.user_uid     = clusterEntity.userU.user_uid;
        clusterDto.location_uid = clusterEntity.locationU.location_uid;
        clusterDto.contact_uid  = clusterEntity.userU.contactU.contact_uid;
        clusterDto.address_uid  = clusterEntity.locationU.addressU.address_uid;

        return clusterDto;
    }
}