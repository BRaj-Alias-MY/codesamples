import { Injectable } from '@nestjs/common';
import { PlantDTO } from 'src/dtos/plant.dto';
import { SubPlantDTO } from 'src/dtos/subplant.dto';
import { PmsPlant } from 'src/entities/pms_plant';
import { IdmsLocation } from 'src/entities/idms_location';
import { IdmsAddress } from 'src/entities/idms_address';
import { IdmsUserDetails } from 'src/entities/idms_user_details';
import { IdmsContact } from 'src/entities/idms_contact';
import { PmsCluster } from 'src/entities/pms_cluster';

@Injectable()
export class PlantAdapter {
      public convertDtoToPlant(plantDto: PlantDTO): PmsPlant {
            const plant = new PmsPlant();
            plant.plantLocation = new IdmsLocation();
            plant.plantLocation.addressU = new IdmsAddress();
            plant.contactDetails = new IdmsUserDetails();
            plant.contactDetails.contactU = new IdmsContact();
            plant.clusterCode = new PmsCluster();

            plant.plant_code = plantDto.plant_code;
            plant.plant_name = plantDto.plant_name;
            plant.isActive = plantDto.is_active;
            plant.m3_production_plant_code = plantDto.plant_ref_code;
            plant.plant_type = plantDto.plant_type;
            plant.activated_date = plantDto.activated_date;
            plant.plant_start_time = plantDto.plant_start_time;
            plant.plant_end_time = plantDto.plant_end_time;
            plant.plantLocation.location_type = plantDto.location_type;
            plant.plantLocation.lat = plantDto.lat;
            plant.plantLocation.long = plantDto.long;
            plant.plantLocation.addressU.door_no = plantDto.door_no;
            plant.plantLocation.addressU.address_line_1 = plantDto.address_line_1;
            plant.plantLocation.addressU.address_line_2 = plantDto.address_line_2;
            plant.plantLocation.addressU.land_mark = plantDto.land_mark;
            plant.plantLocation.addressU.state = plantDto.state;
            plant.plantLocation.addressU.country = plantDto.country;
            plant.plantLocation.addressU.zipcode = plantDto.zipcode;
            plant.contactDetails.contactU.land_line_no = plantDto.land_line_no;
            plant.contactDetails.contactU.mobile_no = plantDto.mobile_no;
            plant.contactDetails.contactU.email = plantDto.email;
            plant.clusterCode.cluster_code = plantDto.cluster_code;
            plant.contactDetails.first_name = plantDto.first_name;
            plant.contactDetails.middle_name = plantDto.middle_name;
            plant.contactDetails.last_name = plantDto.last_name;
            plant.contactDetails.gender = plantDto.gender;
            plant.contactDetails.ref_uid = plantDto.ref_uid;
            plant.contactDetails.uid_country = plantDto.uid_country;
            plant.contactDetails.date_of_birth = plantDto.date_of_birth;

            if (plantDto.user_uid) {
                  plant.contactDetails.user_uid = plantDto.user_uid;
            }

            if (plantDto.contact_uid) {
                  plant.contactDetails.contactU.contact_uid = plantDto.contact_uid;
            }

            if (plantDto.address_uid) {
                  plant.plantLocation.addressU.address_uid = plantDto.address_uid;
            }

            if (plantDto.location_uid) {
                  plant.plantLocation.location_uid = plantDto.location_uid;
            }

            return plant;
      }

      public convertPlantToDto(plant: PmsPlant): PlantDTO {
            const plantDto = new PlantDTO();
            plantDto.plant_code = plant.plant_code ;
            plantDto.plant_name = plant.plant_name ;
            plantDto.is_active = plant.isActive;
            plantDto.plant_ref_code = plant.m3_production_plant_code ;
            plantDto.plant_type = plant.plant_type ;
            plantDto.activated_date = plant.activated_date ;
            plantDto.plant_start_time = plant.plant_start_time ;
            plantDto.plant_end_time = plant.plant_end_time ;
            plantDto.location_type = plant.plantLocation.location_type ;
            plantDto.lat = plant.plantLocation.lat ;
            plantDto.long = plant.plantLocation.long ;
            plantDto.door_no = plant.plantLocation.addressU.door_no ;
            plantDto.address_line_1 = plant.plantLocation.addressU.address_line_1 ;
            plantDto.address_line_2 = plant.plantLocation.addressU.address_line_2 ;
            plantDto.land_mark = plant.plantLocation.addressU.land_mark ;
            plantDto.state = plant.plantLocation.addressU.state ;
            plantDto.country = plant.plantLocation.addressU.country ;
            plantDto.zipcode = plant.plantLocation.addressU.zipcode ;
            plantDto.land_line_no = plant.contactDetails.contactU.land_line_no ;
            plantDto.mobile_no = plant.contactDetails.contactU.mobile_no ;
            plantDto.email = plant.contactDetails.contactU.email ;
            plantDto.cluster_code = plant.clusterCode ? plant.clusterCode.cluster_code : null ;
            plantDto.first_name = plant.contactDetails.first_name ;
            plantDto.middle_name = plant.contactDetails.middle_name ;
            plantDto.last_name = plant.contactDetails.last_name ;
            plantDto.gender = plant.contactDetails.gender ;
            plantDto.ref_uid = plant.contactDetails.ref_uid ;
            plantDto.uid_country = plant.contactDetails.uid_country ;
            plantDto.date_of_birth = plant.contactDetails.date_of_birth ;
            plantDto.user_uid = plant.contactDetails.user_uid;
            plantDto.contact_uid = plant.contactDetails.contactU.contact_uid;
            plantDto.address_uid = plant.plantLocation.addressU.address_uid;
            plantDto.location_uid = plant.plantLocation.location_uid;

            return plantDto;
      }


      public convertDtoToSubPlant(plantDto: SubPlantDTO): PmsPlant {
            const plant = new PmsPlant();
            plant.parentPlantCode = new PmsPlant();
            plant.plantLocation = new IdmsLocation();
            plant.plantLocation.addressU = new IdmsAddress();
            plant.contactDetails = new IdmsUserDetails();
            plant.contactDetails.contactU = new IdmsContact();
            plant.clusterCode = new PmsCluster();

            plant.plant_code = plantDto.plant_code;
            plant.plant_name = plantDto.plant_name;
            plant.isActive = plantDto.is_active;
            plant.m3_production_plant_code = plantDto.plant_ref_code;
            plant.parentPlantCode.plant_code = plantDto.parent_plant_code;
            plant.plant_type = plantDto.plant_type;
            plant.activated_date = plantDto.activated_date;
            plant.plant_start_time = plantDto.plant_start_time;
            plant.plant_end_time = plantDto.plant_end_time;
            plant.plantLocation.location_type = plantDto.location_type;
            plant.plantLocation.lat = plantDto.lat;
            plant.plantLocation.long = plantDto.long;
            plant.plantLocation.addressU.door_no = plantDto.door_no;
            plant.plantLocation.addressU.address_line_1 = plantDto.address_line_1;
            plant.plantLocation.addressU.address_line_2 = plantDto.address_line_2;
            plant.plantLocation.addressU.land_mark = plantDto.land_mark;
            plant.plantLocation.addressU.state = plantDto.state;
            plant.plantLocation.addressU.country = plantDto.country;
            plant.plantLocation.addressU.zipcode = plantDto.zipcode;
            plant.contactDetails.contactU.land_line_no = plantDto.land_line_no;
            plant.contactDetails.contactU.mobile_no = plantDto.mobile_no;
            plant.contactDetails.contactU.email = plantDto.email;
            plant.clusterCode.cluster_code = plantDto.cluster_code;
            plant.contactDetails.first_name = plantDto.first_name;
            plant.contactDetails.middle_name = plantDto.middle_name;
            plant.contactDetails.last_name = plantDto.last_name;
            plant.contactDetails.gender = plantDto.gender;
            plant.contactDetails.ref_uid = plantDto.ref_uid;
            plant.contactDetails.uid_country = plantDto.uid_country;
            plant.contactDetails.date_of_birth = plantDto.date_of_birth;

            if (plantDto.user_uid) {
                  plant.contactDetails.user_uid = plantDto.user_uid;
            }

            if (plantDto.contact_uid) {
                  plant.contactDetails.contactU.contact_uid = plantDto.contact_uid;
            }

            if (plantDto.address_uid) {
                  plant.plantLocation.addressU.address_uid = plantDto.address_uid;
            }

            if (plantDto.location_uid) {
                  plant.plantLocation.location_uid = plantDto.location_uid;
            }

            return plant;
      }

      public convertSubPlantToDto(plant: PmsPlant): SubPlantDTO {
            const plantDto = new SubPlantDTO();
            plantDto.plant_code = plant.plant_code ;
            plantDto.plant_name = plant.plant_name ;
            plantDto.is_active = plant.isActive;
            plantDto.plant_ref_code = plant.m3_production_plant_code ;
            plantDto.parent_plant_code = plant.parentPlantCode ? plant.parentPlantCode.plant_code : null ;
            plantDto.plant_type = plant.plant_type ;
            plantDto.activated_date = plant.activated_date ;
            plantDto.plant_start_time = plant.plant_start_time ;
            plantDto.plant_end_time = plant.plant_end_time ;
            plantDto.location_type = plant.plantLocation.location_type ;
            plantDto.lat = plant.plantLocation.lat ;
            plantDto.long = plant.plantLocation.long ;
            plantDto.door_no = plant.plantLocation.addressU.door_no ;
            plantDto.address_line_1 = plant.plantLocation.addressU.address_line_1 ;
            plantDto.address_line_2 = plant.plantLocation.addressU.address_line_2 ;
            plantDto.land_mark = plant.plantLocation.addressU.land_mark ;
            plantDto.state = plant.plantLocation.addressU.state ;
            plantDto.country = plant.plantLocation.addressU.country ;
            plantDto.zipcode = plant.plantLocation.addressU.zipcode ;
            plantDto.land_line_no = plant.contactDetails.contactU.land_line_no ;
            plantDto.mobile_no = plant.contactDetails.contactU.mobile_no ;
            plantDto.email = plant.contactDetails.contactU.email ;
            plantDto.cluster_code = plant.clusterCode ? plant.clusterCode.cluster_code : null ;
            plantDto.first_name = plant.contactDetails.first_name ;
            plantDto.middle_name = plant.contactDetails.middle_name ;
            plantDto.last_name = plant.contactDetails.last_name ;
            plantDto.gender = plant.contactDetails.gender ;
            plantDto.ref_uid = plant.contactDetails.ref_uid ;
            plantDto.uid_country = plant.contactDetails.uid_country ;
            plantDto.date_of_birth = plant.contactDetails.date_of_birth ;
            plantDto.user_uid = plant.contactDetails.user_uid;
            plantDto.contact_uid = plant.contactDetails.contactU.contact_uid;
            plantDto.address_uid = plant.plantLocation.addressU.address_uid;
            plantDto.location_uid = plant.plantLocation.location_uid;

            return plantDto;
      }
}
