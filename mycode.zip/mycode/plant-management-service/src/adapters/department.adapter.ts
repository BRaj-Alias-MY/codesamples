import { Injectable } from "@nestjs/common";
import { DepartmentDto } from "src/dtos/department.dto";
import { PmsDepartments } from "src/entities/pms_departments";
import { PmsPlant } from "src/entities/pms_plant";
import { IdmsUserDetails } from "src/entities/idms_user_details";
import { IdmsContact } from "src/entities/idms_contact";

@Injectable()
export class DepartmentsAdapter
{
    public convertDtoToEntity(departmentObj : DepartmentDto):PmsDepartments{
        const departmentEntity = new PmsDepartments;
        departmentEntity.department_code = departmentObj.department_code;
        departmentEntity.department_name = departmentObj.department_name;
        departmentEntity.department_type = departmentObj.department_type;
        departmentEntity.is_active = departmentObj.is_active;
        departmentEntity.sla = departmentObj.sla;

        departmentEntity.plantCode = new PmsPlant();
        departmentEntity.plantCode.plant_code = departmentObj.plant_code;

        departmentEntity.userU = new IdmsUserDetails();
        departmentEntity.userU.date_of_birth = departmentObj.date_of_birth;
        departmentEntity.userU.first_name = departmentObj.first_name;
        departmentEntity.userU.gender = departmentObj.gender;
        departmentEntity.userU.last_name = departmentObj.last_name;

        departmentEntity.userU.contactU = new IdmsContact();
        departmentEntity.userU.contactU.email = departmentObj.email;
        departmentEntity.userU.contactU.land_line_no = departmentObj.land_line_no;
        departmentEntity.userU.contactU.mobile_no = departmentObj.mobile_no;

        departmentObj.user_uid ? departmentEntity.userU.user_uid = departmentObj.user_uid : false;
        departmentObj.contact_uid ? departmentEntity.userU.contactU.contact_uid = departmentObj.contact_uid : false;
        return departmentEntity;
    }
    
    public convertEntityToDto(departmentDto : PmsDepartments):DepartmentDto{
        let departmentDtoobj = new DepartmentDto();
        departmentDtoobj.department_code = departmentDto.department_code;
        departmentDtoobj.department_name = departmentDto.department_name;
        departmentDtoobj.department_type = departmentDto.department_type;
        departmentDtoobj.sla = departmentDto.sla;
        departmentDtoobj.plant_code= departmentDto.plantCode.plant_code;
        departmentDtoobj.date_of_birth = departmentDto.userU.date_of_birth;
        departmentDtoobj.first_name = departmentDto.userU.first_name;
        departmentDtoobj.gender = departmentDto.userU.gender;
        departmentDtoobj.last_name = departmentDto.userU.last_name;
        departmentDtoobj.email = departmentDto.userU.contactU.email;
        departmentDtoobj.land_line_no = departmentDto.userU.contactU.land_line_no;
        departmentDtoobj.mobile_no = departmentDto.userU.contactU.mobile_no;
        departmentDtoobj.user_uid = departmentDto.userU.user_uid;
        departmentDtoobj.contact_uid = departmentDto.userU.contactU.contact_uid;
        departmentDtoobj.is_active = departmentDto.is_active;
        departmentDtoobj.middle_name = departmentDto.userU.middle_name;
        departmentDtoobj.ref_uid = departmentDto.userU.ref_uid;
        departmentDtoobj.uid_country = departmentDto.userU.uid_country;
        return departmentDtoobj;
    }
    

}