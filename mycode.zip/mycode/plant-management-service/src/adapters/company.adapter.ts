import { CompanyDTO } from '../dtos/company.dto';
import { Injectable } from '@nestjs/common';
import { PmsCompanies } from 'src/entities/pms_companies';
import { IdmsLocation } from 'src/entities/idms_location';
import { IdmsAddress } from 'src/entities/idms_address';
import { IdmsUserDetails } from 'src/entities/idms_user_details';
import { IdmsContact } from 'src/entities/idms_contact';

@Injectable()
export class CompanyAdapter {

    public convertDtoToEntity(companyDetails: CompanyDTO): PmsCompanies {

        const company = new PmsCompanies();
        company.company_code = companyDetails.company_code;
        company.company_name = companyDetails.company_name;
        company.activated_date = companyDetails.activated_date;
        company.deactivated_date = companyDetails.deactivated_date;
        company.isActive = companyDetails.isActive;

        company.locationU = new IdmsLocation();
        if (companyDetails.location_uid) {
            company.locationU.location_uid = companyDetails.location_uid;
        }
        company.locationU.location_type = companyDetails.location_type;
        company.locationU.lat = companyDetails.lat;
        company.locationU.long = companyDetails.long;

        company.locationU.addressU = new IdmsAddress();
        if (companyDetails.address_uid) {
            company.locationU.addressU.address_uid = companyDetails.address_uid;
        }
        company.locationU.addressU.address_line_1 = companyDetails.address_line_1;
        company.locationU.addressU.address_line_2 = companyDetails.address_line_2;
        company.locationU.addressU.door_no = companyDetails.door_no;
        company.locationU.addressU.land_mark = companyDetails.land_mark;
        company.locationU.addressU.country = companyDetails.country;
        company.locationU.addressU.state = companyDetails.state;
        company.locationU.addressU.zipcode = companyDetails.zipcode;

        company.userU = new IdmsUserDetails();
        if (companyDetails.user_uid) {
            company.userU.user_uid = companyDetails.user_uid;
        }

        company.userU.first_name = companyDetails.first_name;
        company.userU.middle_name = companyDetails.middle_name;
        company.userU.last_name = companyDetails.last_name;
        company.userU.gender = companyDetails.gender;
        company.userU.date_of_birth = companyDetails.date_of_birth;
        company.userU.uid_country = companyDetails.uid_country;

        company.userU.contactU = new IdmsContact();
        if (companyDetails.contact_uid) {
            company.userU.contactU.contact_uid = companyDetails.contact_uid;
        }

        company.userU.contactU.land_line_no = companyDetails.land_line_no;
        company.userU.contactU.mobile_no = companyDetails.mobile_no;
        company.userU.contactU.email = companyDetails.email;

        return company;
    }

    public convertEntityToDto(companyDetails: PmsCompanies): CompanyDTO {

        const companyDto = new CompanyDTO();
        companyDto.company_code = companyDetails.company_code;
        companyDto.company_name = companyDetails.company_name;
        companyDto.activated_date = companyDetails.activated_date;
        companyDto.deactivated_date = companyDetails.deactivated_date;
        companyDto.isActive = companyDetails.isActive;
        companyDto.location_uid = companyDetails.locationU.location_uid;
        companyDto.location_type = companyDetails.locationU.location_type;
        companyDto.lat = companyDetails.locationU.lat;
        companyDto.long = companyDetails.locationU.long;
        companyDto.address_uid = companyDetails.locationU.addressU.address_uid;
        companyDto.address_line_1 = companyDetails.locationU.addressU.address_line_1;
        companyDto.address_line_2 = companyDetails.locationU.addressU.address_line_2;
        companyDto.door_no = companyDetails.locationU.addressU.door_no;
        companyDto.land_mark = companyDetails.locationU.addressU.land_mark;
        companyDto.country = companyDetails.locationU.addressU.country;
        companyDto.state = companyDetails.locationU.addressU.state;
        companyDto.zipcode = companyDetails.locationU.addressU.zipcode;
        companyDto.user_uid = companyDetails.userU.user_uid;
        companyDto.first_name = companyDetails.userU.first_name;
        companyDto.middle_name = companyDetails.userU.middle_name;
        companyDto.last_name = companyDetails.userU.last_name;
        companyDto.gender = companyDetails.userU.gender;
        companyDto.date_of_birth = companyDetails.userU.date_of_birth;
        companyDto.uid_country = companyDetails.userU.uid_country;
        companyDto.contact_uid = companyDetails.userU.contactU.contact_uid;
        companyDto.land_line_no = companyDetails.userU.contactU.land_line_no;
        companyDto.mobile_no = companyDetails.userU.contactU.mobile_no;
        companyDto.email = companyDetails.userU.contactU.email;

        return companyDto;
    }

}
