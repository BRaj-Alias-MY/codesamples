import { IsNumber, IsString, IsBoolean } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

export class SectionDTO{

    @ApiModelProperty() 
    @IsString()   
    section_code: string;
    @ApiModelProperty() 
    @IsString() 
    section_name: string;
    @ApiModelProperty() 
    @IsString() 
    departmentCode: string;


    @ApiModelProperty()
    @IsString()
    first_name : string;
    @ApiModelProperty()
    @IsString()
    middle_name ?: string;
    @ApiModelProperty()
    @IsString()
    last_name : string;
    @ApiModelProperty()
    @IsString()
    gender : string;
    @ApiModelProperty()
    @IsString()
    ref_uid ?: string;
    @ApiModelProperty()
    @IsString()
    uid_country ?: string;
    @ApiModelProperty()
    @IsString()
    date_of_birth ?: string;

    @ApiModelProperty()
    @IsString()
    land_line_no : string;
    @ApiModelProperty()
    @IsString()
    mobile_no : string;
    @ApiModelProperty()
    @IsString()
    email ?: string;
    @ApiModelProperty()
    user_uid?: string;
    @ApiModelProperty()
    contact_uid?: string;


    
}