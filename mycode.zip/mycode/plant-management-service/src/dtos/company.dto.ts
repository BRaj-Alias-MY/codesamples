import {IsInt, IsEmail, IsString, IsDateString} from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

export class CompanyDTO {
    @ApiModelProperty()
    company_code: string;
    @ApiModelProperty()
    company_name: string;
    @ApiModelProperty()
    @IsDateString()
    activated_date?: string;
    @ApiModelProperty()
    @IsDateString()
    deactivated_date?: string;
    @ApiModelProperty()
    isActive: boolean;
    @ApiModelProperty()
    @IsString()
    first_name: string;
    @ApiModelProperty()
    @IsString()
    middle_name?: string;
    @ApiModelProperty()
    last_name: string;
    @ApiModelProperty()
    @IsString()
    gender: string;
    @ApiModelProperty()
    uid_country: string;
    @ApiModelProperty()
    @IsDateString()
    date_of_birth: string;
    @ApiModelProperty()
    door_no: string;
    @ApiModelProperty()
    address_line_1: string;
    @ApiModelProperty()
    address_line_2?: string;
    @ApiModelProperty()
    land_mark?: string;
    @ApiModelProperty()
    @IsString()
    state?: string;
    @ApiModelProperty()
    @IsString()
    country?: string;
    @ApiModelProperty()
    zipcode?: string;
    @ApiModelProperty()
    location_type?: string;
    @ApiModelProperty()
    lat?: string;
    @ApiModelProperty()
    long?: string;
    @ApiModelProperty()
    land_line_no?: string;
    @ApiModelProperty()    
    mobile_no: string;
    @ApiModelProperty()
    @IsEmail()
    email?: string;
    @ApiModelProperty()
    location_uid?: string;
    @ApiModelProperty()
    user_uid?: string;
    @ApiModelProperty()
    contact_uid?: string;
    @ApiModelProperty()
    address_uid?: string;
}