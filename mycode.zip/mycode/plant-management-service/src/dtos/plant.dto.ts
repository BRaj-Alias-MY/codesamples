import { ApiModelProperty } from '@nestjs/swagger';
import { IsString } from 'class-validator';

export class PlantDTO {
      @ApiModelProperty()
      @IsString()
      plant_code: string;
      @ApiModelProperty()
      plant_name: string;
      @ApiModelProperty()
      plant_ref_code?: string;
      @ApiModelProperty()
      plant_type: string;
      @ApiModelProperty()
      activated_date: string;
      @ApiModelProperty()
      plant_start_time: string;
      @ApiModelProperty()
      plant_end_time: string;
      @ApiModelProperty()
      is_active: boolean;
      @ApiModelProperty()
      location_type: string;
      @ApiModelProperty()
      lat: string;
      @ApiModelProperty()
      long: string;
      @ApiModelProperty()
      door_no: string;
      @ApiModelProperty()
      address_line_1: string;
      @ApiModelProperty()
      address_line_2: string;
      @ApiModelProperty()
      land_mark: string;
      @ApiModelProperty()
      state: string;
      @ApiModelProperty()
      country: string;
      @ApiModelProperty()
      zipcode: string;
      @ApiModelProperty()
      land_line_no: string;
      @ApiModelProperty()
      mobile_no: string;
      @ApiModelProperty()
      email: string;
      @ApiModelProperty()
      cluster_code: string;
      @ApiModelProperty()
      first_name: string;
      @ApiModelProperty()
      middle_name: string;
      @ApiModelProperty()
      last_name: string;
      @ApiModelProperty()
      gender: string;
      @ApiModelProperty()
      ref_uid: string;
      @ApiModelProperty()
      uid_country: string;
      @ApiModelProperty()
      date_of_birth: string;

      @ApiModelProperty()
      user_uid?: string;
      @ApiModelProperty()
      contact_uid?: string;
      @ApiModelProperty()
      address_uid?: string;
      @ApiModelProperty()
      location_uid?: string;
}
