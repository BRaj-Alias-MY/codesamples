import { IsNumber, IsString, IsBoolean ,IsArray } from 'class-validator';
import { ApiModelProperty }  from '@nestjs/swagger';
import { IdMSDTO } from 'src/dtos/idms.dto';
import { PmsCompanies } from 'src/entities/pms_companies';

export class ClusterDto extends IdMSDTO{
    
    
    @ApiModelProperty()
    @IsString()
    cluster_code : string;
    @ApiModelProperty()
    @IsString()
    cluster_name : string;
    @ApiModelProperty()
    @IsString()
    corporate_code : any;
    @IsString()
    corporate_name : string;
    @ApiModelProperty()
    @IsString()
    activated_date : string;
    @ApiModelProperty()
    @IsBoolean()
    isActive : boolean;

    //All Uids
    @ApiModelProperty()
    @IsString()
    user_uid ?: string;
    @ApiModelProperty()
    @IsString()
    address_uid ?: string;
    @ApiModelProperty()
    @IsString()
    contact_uid ?: string;
    @ApiModelProperty()
    @IsString()
    location_uid ?: string;
}

