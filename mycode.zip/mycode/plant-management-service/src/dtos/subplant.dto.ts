import { ApiModelProperty } from "@nestjs/swagger";
import { PlantDTO } from "./plant.dto";

export class SubPlantDTO extends PlantDTO {
      @ApiModelProperty()
      parent_plant_code: string;
}
