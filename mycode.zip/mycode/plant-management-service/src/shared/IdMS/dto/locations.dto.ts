import { IsNumber, IsString, IsBoolean ,IsArray } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';
export class locationsDTO
{
    @ApiModelProperty()
    @IsString()
    location_type ?: string;
    @ApiModelProperty()
    @IsString()
    lat ?: string;
    @ApiModelProperty()
    @IsString()
    long ?: string;
}