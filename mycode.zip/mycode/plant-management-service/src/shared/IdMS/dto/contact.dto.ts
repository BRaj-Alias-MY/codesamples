import { IsNumber, IsString, IsBoolean ,IsArray } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';
export class contactDTO
{
    @ApiModelProperty()
    @IsString()
    land_line_no ?: string;
    @ApiModelProperty()
    @IsString()
    mobile_no : string;
    @ApiModelProperty()
    @IsString()
    email ?: string;
}