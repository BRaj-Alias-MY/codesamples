import { IsNumber, IsString, IsBoolean ,IsArray } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';
export class userdetailsDTO
{
    @ApiModelProperty()
    @IsString()
    first_name : string;
    @ApiModelProperty()
    @IsString()
    middle_name ?: string;
    @ApiModelProperty()
    @IsString()
    last_name : string;
    @ApiModelProperty()
    @IsString()
    gender : string;
    @ApiModelProperty()
    @IsString()
    ref_uid ?: string;
    @ApiModelProperty()
    @IsString()
    uid_country ?: string;
    @ApiModelProperty()
    @IsString()
    date_of_birth ?: string;
}