import { IsNumber, IsString, IsBoolean ,IsArray } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';
export class AddressDTO{
    @ApiModelProperty()
    @IsString()
    door_no : string;
    @ApiModelProperty()
    @IsString()
    address_line_1 : string;
    @ApiModelProperty()
    @IsString()
    address_line_2 ?: string;
    @ApiModelProperty()
    @IsString()
    land_mark ?: string;
    @ApiModelProperty()
    @IsString()
    state : string;
    @ApiModelProperty()
    @IsString()
    country : string;
    @ApiModelProperty()
    @IsString()
    zipcode ?: string;
}