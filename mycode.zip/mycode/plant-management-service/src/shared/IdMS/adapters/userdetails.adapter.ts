import { userdetailsDTO } from "../dto/userdetails.dto";

export class UserAdapter
{
    actual_Idms_obj : userdetailsDTO;
    idmsobject = {
        user:{
            first_name : null,
            middle_name : null,
            last_name : null,
            gender : null,
            ref_uid : null,
            uid_country : null,
            date_of_birth : null,
            contactU:null,
        },
    }
    public constructor(incomingidmsobject:userdetailsDTO){
        this.actual_Idms_obj = incomingidmsobject;
    }
    public getUser()
    {
        this.idmsobject.user.first_name = this.actual_Idms_obj.first_name;
        this.idmsobject.user.middle_name = this.actual_Idms_obj.middle_name;
        this.idmsobject.user.last_name = this.actual_Idms_obj.last_name;
        this.idmsobject.user.gender = this.actual_Idms_obj.gender
        this.idmsobject.user.date_of_birth = this.actual_Idms_obj.date_of_birth;
        this.idmsobject.user.ref_uid = this.actual_Idms_obj.ref_uid;
        this.idmsobject.user.uid_country = this.actual_Idms_obj.uid_country;
        return this.idmsobject.user;
    }
    
}