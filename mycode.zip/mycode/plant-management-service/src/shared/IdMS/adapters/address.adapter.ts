import { AddressDTO } from "../dto/address.dto";
export class AddressAdapter
{
    addressdtoobj : AddressDTO;
    idmsobject = {
        address:{
            door_no : null,
            address_line_1 : null,
            address_line_2 : null,
            land_mark : null,
            state : null,
            country : null,
            zipcode : null
        }
    }
    public constructor(addressdtoobj:AddressDTO){
        this.addressdtoobj = addressdtoobj;
    }
    public getAddress()
    {
        this.idmsobject.address.address_line_1 = this.addressdtoobj.address_line_1;
        this.idmsobject.address.address_line_2 = this.addressdtoobj.address_line_2;
        this.idmsobject.address.country = this.addressdtoobj.country;
        this.idmsobject.address.door_no = this.addressdtoobj.door_no;
        this.idmsobject.address.land_mark=this.addressdtoobj.land_mark;
        this.idmsobject.address.state=this.addressdtoobj.state;
        this.idmsobject.address.zipcode = this.addressdtoobj.zipcode;
        return this.idmsobject.address;
    }
    
}