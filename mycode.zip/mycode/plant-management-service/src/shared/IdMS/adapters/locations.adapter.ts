import { locationsDTO } from "../dto/locations.dto";

export class LocationAdapter
{
    actual_Idms_obj : locationsDTO;
    idmsobject = {
        location:{
            location_type : null,
            lat : null,
            long : null,
            addressU:null,
        },
    }
    public constructor(incomingidmsobject:locationsDTO){
        this.actual_Idms_obj = incomingidmsobject;
    }
    public getLocation()
    {
        this.idmsobject.location.lat = this.actual_Idms_obj.lat;
        this.idmsobject.location.location_type = this.actual_Idms_obj.location_type;
        this.idmsobject.location.long = this.actual_Idms_obj.long;        
        return this.idmsobject.location;
    }
    
}