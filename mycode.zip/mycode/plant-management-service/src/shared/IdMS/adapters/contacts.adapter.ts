import { contactDTO } from "../dto/contact.dto";

export class ContactAdapter
{
    actual_Idms_obj : contactDTO;
    idmsobject = {
        contact:{
            land_line_no : null,
            mobile_no : null,
            email : null,
            addressU:null,
        },
    }
    public constructor(incomingidmsobject:contactDTO){
        this.actual_Idms_obj = incomingidmsobject;
    }
    public getContact()
    {
        this.idmsobject.contact.land_line_no = this.actual_Idms_obj.land_line_no;
        this.idmsobject.contact.mobile_no = this.actual_Idms_obj.mobile_no;
        this.idmsobject.contact.email = this.actual_Idms_obj.email;
        return this.idmsobject.contact;
    }
    
}