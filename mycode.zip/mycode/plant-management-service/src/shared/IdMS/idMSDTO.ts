import { IsNumber, IsString, IsBoolean ,IsArray } from 'class-validator';
import { ApiModelProperty } from '@nestjs/swagger';

export class IdMSDTO {
    @ApiModelProperty()
    @IsString()
    first_name : string;
    @ApiModelProperty()
    @IsString()
    middle_name ?: string;
    @ApiModelProperty()
    @IsString()
    last_name : string;
    @ApiModelProperty()
    @IsString()
    gender : string;
    @ApiModelProperty()
    @IsString()
    ref_uid ?: string;
    @ApiModelProperty()
    @IsString()
    uid_country ?: string;
    @ApiModelProperty()
    @IsString()
    date_of_birth ?: string;

    @ApiModelProperty()
    @IsString()
    land_line_no ?: string;
    @ApiModelProperty()
    @IsString()
    mobile_no : string;
    @ApiModelProperty()
    @IsString()
    email ?: string;

    @ApiModelProperty()
    @IsString()
    door_no : string;
    @ApiModelProperty()
    @IsString()
    address_line_1 : string;
    @ApiModelProperty()
    @IsString()
    address_line_2 ?: string;
    @ApiModelProperty()
    @IsString()
    land_mark ?: string;
    @ApiModelProperty()
    @IsString()
    state : string;
    @ApiModelProperty()
    @IsString()
    country : string;
    @ApiModelProperty()
    @IsString()
    zipcode ?: string;
    
    @ApiModelProperty()
    @IsString()
    location_type ?: string;
    @ApiModelProperty()
    @IsString()
    lat ?: string;
    @ApiModelProperty()
    @IsString()
    long ?: string;
}
