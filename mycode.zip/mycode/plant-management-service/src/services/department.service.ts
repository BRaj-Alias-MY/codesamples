import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository} from 'typeorm';
import { DepartmentDto } from '../dtos/department.dto';
import { DepartmentsAdapter } from '../adapters/department.adapter';
import { PmsDepartments } from 'src/entities/pms_departments';
import { PmsSections } from 'src/entities/pms_sections';

@Injectable()
export class DepartmentsService {
    constructor(
    @InjectRepository(PmsDepartments) private departmentRepository: Repository<PmsDepartments>,
    @InjectRepository(PmsSections) private sectionRepository: Repository<PmsSections>) { }

    async validatingDepartmentExists(department_code : String):Promise<boolean>{
        return await this.departmentRepository.
        findOne({where:{department_code:department_code}}).then((data)=>{
            if(data){
                return true;
            }
            else{
                return false;
            }
        }).catch(()=>{
            return false;
        });
    }

    createDepartment(departmentOBJ:DepartmentDto):Promise<DepartmentDto>{
        const departmentAdapter = new DepartmentsAdapter();
        const departmentEntity = departmentAdapter.convertDtoToEntity(departmentOBJ);
        return this.departmentRepository.save(departmentEntity).then((response)=>{
            return departmentAdapter.convertEntityToDto(response);
        }).catch((err)=>{
            return err;
        })
    }

    async deActivateDepartmentValidation(departmentvalidationobj:String):Promise<Boolean>{
        return await this.sectionRepository.findOne({where:{departmentCode:departmentvalidationobj}}).then((data)=>{
            if(data){
                if(data.isActive){
                    return false
                }
                else{
                    return true;
                }
            }
            else{
                return true;
            }
        }).catch((err)=>{
            return false;
        })
    }

    async deActivateDepartment(departmentCode:string):Promise<boolean>{
        const deactive_date = new Date().toISOString().slice(0, 10);
        return await this.departmentRepository.update({department_code:departmentCode},{is_active:false,deactivated_date:deactive_date}).then((response)=>{
            return true;
        }).catch((err)=>{
           return false;
        })
    }

    async getAllDepartments():Promise<DepartmentDto[]>{
        const departmentAdapter = new DepartmentsAdapter();
        try{
            const departmentsall =  await this.departmentRepository.find({order:{department_name:"ASC"},
            relations: ["plantCode","userU","userU.contactU"]});
            return departmentsall.map((department)=>{
                return departmentAdapter.convertEntityToDto(department);
            })
        }
        catch(err){
            return err;
        }
    }

    async getDepartment(departmentCode:string):Promise<DepartmentDto>{
        return await this.departmentRepository.
        findOne({where:{department_code:departmentCode}, relations: ["plantCode","userU","userU.contactU"]}).then((res)=>{
           const departmentAdapter = new DepartmentsAdapter();
           return departmentAdapter.convertEntityToDto(res);
        }).catch((err)=>{
            return err;
        });
    }

}
