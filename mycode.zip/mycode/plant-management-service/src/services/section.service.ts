import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { Repository, Transaction, TransactionRepository } from 'typeorm';
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm';
import {SectionDTO} from 'src/dtos/section.dto';
import {SectionAdapter} from 'src/adapters/section.adapter';
import { PmsSections } from 'src/entities/pms_sections';


@Injectable()
export class SectionService {
    constructor( private sectionadapter : SectionAdapter, @InjectRepository(PmsSections) private sectionRepository: Repository<PmsSections>) {
    }

    async validateSection(sectionobj : String):Promise<Boolean>{
        const sectioncount = await this.sectionRepository.findOne({where:{section_code:sectionobj} });
        return sectioncount ? true : false;
    }

    async createSection(sectiondata: SectionDTO):Promise<SectionDTO>{
        try{
            const section = this.sectionadapter.convertDtoToEntity(sectiondata);
            const savesec = {...section, isActive: true};
            const response = await this.sectionRepository.save(savesec);
            return await this.sectionadapter.convertEntityToDto(response);
        } catch(error){
            console.log(error);
        }
    }

    async getAllSections(): Promise<SectionDTO[]> {
        const  sectionall = await this.sectionRepository.find({order:{section_code:"ASC"},relations: ["departmentCode","user","user.contactU"]});
        console.log(sectionall);
        return sectionall.map(data => {
            return this.sectionadapter.convertEntityToDto(data);
        });
    }

    async getSection (sectionCode:string):Promise<SectionDTO>{
        return await this.sectionadapter.convertEntityToDto(await this.sectionRepository.findOne({where:{section_code:sectionCode}, relations: ["departmentCode","user","user.contactU"]}));
    }

    async deActivateSection(sectionCode:string):Promise<boolean>{
        const obj =  await this.sectionRepository.update({section_code:sectionCode},{isActive:false})
        return obj ? true : false;
    }
}
