import { Injectable} from '@nestjs/common';
import { Repository } from 'typeorm';
import { CompanyDTO } from 'src/dtos/company.dto';
import { CompanyAdapter } from 'src/adapters/company.adapter';
import { InjectRepository } from '@nestjs/typeorm';
import { promises } from 'fs';
import { PmsCompanies } from 'src/entities/pms_companies';
import { PmsCluster } from 'src/entities/pms_cluster';

@Injectable()
export class CompanyService {
    constructor(
        private companyAdapter: CompanyAdapter,
        @InjectRepository(PmsCompanies) private companyRepository: Repository<PmsCompanies>,
        @InjectRepository(PmsCluster) private clusterRepository: Repository<PmsCluster>){
    }

    async verifyIfCompanyExists(company_code: string): Promise<boolean> {
        return await this.companyRepository.findOne({company_code}).then(
            companyexists => {
                if (companyexists) {
                    return true;
                } else {
                    return false;
                }
            },
        ).catch(err => {
            return false;
        });
    }
    // Creating Company
    async saveCompany(companyDetails: CompanyDTO): Promise <CompanyDTO> {
        try {
            const companyEntity = this.companyAdapter.convertDtoToEntity(companyDetails);
            const companyResponse = await this.companyRepository.save(companyEntity);
            return this.companyAdapter.convertEntityToDto(companyResponse);
        } catch (err) {
           return err;
        }
    }

    async getCompanyDetails(company_code: string): Promise<CompanyDTO> {
        const companyResponse = await this.companyRepository.findOne({where:{company_code:company_code},
            relations: ['locationU', 'userU', 'locationU.addressU', 'userU.contactU']});
        if (companyResponse) {
            return this.companyAdapter.convertEntityToDto(companyResponse);
        } else {
            return null;
        }
    }

    // Getting all Companies
    async getAllCompanies(): Promise<CompanyDTO[]> {
        try {
            const page: number = 1;
            const companyResponse = await this.companyRepository.find({order: { company_code: 'ASC' },
                relations: ['locationU', 'userU', 'locationU.addressU', 'userU.contactU'] });
            return companyResponse.map(companies => {
                return this.companyAdapter.convertEntityToDto(companies);
            });
        } catch (err) {
            return err;
        }
    }

    async checkActiveCluster(company_code: string):Promise<boolean>{
        return  (await this.clusterRepository.find({where:{corporateCode:company_code,isActive:true}}) ).length > 0 ? true : false;
    }

    // Update status of Company
    async deActivateCompany(company_code: string): Promise <boolean> {
        try {
            const deactive_date = new Date().toISOString().slice(0, 10);
            return await this.companyRepository.update({company_code:company_code},{isActive:false,deactivated_date:deactive_date}).then(
                company => {
                    return true;
                }).catch(err => {
                   return false;
                });
        } catch (err) {
            return err;
        }
    }
}
