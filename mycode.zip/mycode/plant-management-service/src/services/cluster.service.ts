import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectEntityManager, InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { ClusterDto } from 'src/dtos/cluster.dto';
import { ClusterAdapter } from 'src/adapters/cluster.adapter';
import { PmsCluster } from 'src/entities/pms_cluster';
import { PmsPlant } from 'src/entities/pms_plant';
import { PmsCompanies } from 'src/entities/pms_companies';

@Injectable()
export class ClusterService {
    private clusterAdapter;
    constructor(
                @InjectRepository(PmsCluster) private clusterRepository:Repository<PmsCluster>,
                @InjectRepository(PmsPlant) private plantRepository : Repository<PmsPlant>,
                @InjectRepository(PmsCompanies) private companiesRepository : Repository<PmsCompanies>
            ){
        //Do Nothing
        this.clusterAdapter = new ClusterAdapter();
    }
    
    async findIfClusterExist(cluster_code:string):Promise<boolean>{
        let cluster = await this.clusterRepository.findOne({where : {cluster_code:cluster_code} });
        if(cluster){return true } else{ return false };    
    }

    async getAllClusters():Promise<ClusterDto[]>{
        try{
            let clusters = await this.clusterRepository.find({ relations: ["corporateCode","locationU","userU","userU.contactU","locationU.addressU"] });
            if(clusters.length > 0){
                return clusters.map(cluster => {
                    return this.clusterAdapter.convertEntityToDto(cluster);
                });    
            }else{
                return null;
            }
        }catch(err){
            return err;
        }
    }
    
    async getClustersForCompany(company_code : string):Promise<ClusterDto[]>{
        try{
            let clusters = await this.clusterRepository.find({ where:{corporateCode : company_code },
                                                        relations: ["corporateCode","locationU","userU","userU.contactU","locationU.addressU"]});
            if(clusters.length > 0){
                return clusters.map(cluster => {
                    return this.clusterAdapter.convertEntityToDto(cluster);
                }); 
            }else{
                return null;
            }
        }catch(err){
            return err;
        }
    }

    async createCluster(clusterDto : ClusterDto):Promise<ClusterDto>{
        const company = await this.companiesRepository.findOne({where : {company_code : clusterDto.corporate_code} });
        if(company){
            try{
                const clusterEntity = this.clusterAdapter.convertDtoToEntity(clusterDto);
                const savedCluster = await this.clusterRepository.save(clusterEntity);
                return await this.clusterAdapter.convertEntityToDto(savedCluster);
            }catch(err){
                return err;
            }
        }else{
            return null;
        }
    }

    async getCluster(cluster_code : string):Promise<ClusterDto>{
        try{
            const clusterEntity =  await this.clusterRepository.findOne({where : {cluster_code:cluster_code},
                relations: ["corporateCode","locationU","userU","userU.contactU","locationU.addressU"] });
            if(clusterEntity){
                const clusterDto = await this.clusterAdapter.convertEntityToDto(clusterEntity);
                return clusterDto;
            }else{
                return null;
            }
        }catch(err){
            return err;
        }
    }

    async updateCluster(clusterDto: ClusterDto): Promise<ClusterDto> {
        try{
            const clusterEntity = this.clusterAdapter.convertDtoToEntity(clusterDto);
            await this.clusterRepository.save(clusterEntity);
            const updatedCluster = await this.getCluster(clusterDto.cluster_code);
            return updatedCluster;
        }catch(err){
            return err;
        }
    }

    async deActivateCluster(cluster_code: string):Promise<boolean>{
        //getting if any plant active under the cluser
        const plants = await this.plantRepository.findOne({ where: {clusterCode:cluster_code,isActive:true} } );
        if(plants){
            return false;
        }else{
            const deactivatedDate = new Date().toISOString().slice(0, 10);
            return await this.clusterRepository.update({cluster_code:cluster_code},{isActive:false,deactivated_date:deactivatedDate})
            .then(res=>{
                return true;
            }).catch(err=>{
                return false;
            });
        }
    }
}