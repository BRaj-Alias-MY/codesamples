import { Injectable } from '@nestjs/common';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';
import { PlantDTO } from 'src/dtos/plant.dto';
import { PlantAdapter } from 'src/adapters/plant.adapter';
import { ClusterService } from 'src/services/cluster.service';
import { SubPlantDTO } from 'src/dtos/subplant.dto';
import { PmsPlant } from 'src/entities/pms_plant';
import { PmsDepartments } from 'src/entities/pms_departments';

@Injectable()
export class PlantService {
      constructor(@InjectRepository(PmsPlant) private entity: Repository<PmsPlant>, @InjectRepository(PmsDepartments) private departmentEntity: Repository<PmsDepartments>,
                  private plantAdpter: PlantAdapter, private clusterService: ClusterService) { }

      async getAllPlants(): Promise<SubPlantDTO[]> {
            const plantdata = await this.entity.find({relations: ['plantLocation', 'plantLocation.addressU',
            'contactDetails', 'contactDetails.contactU', 'parentPlantCode', 'clusterCode']});
            return plantdata.map(data => {
                  return this.plantAdpter.convertSubPlantToDto(data);
            });
      }

      async createPlant(plantDTO: PlantDTO): Promise<SubPlantDTO> {
            try {
                  const plantData = this.plantAdpter.convertDtoToPlant(plantDTO);
                  const plant = {...plantData};
                  const response = await this.entity.save(plant);
                  return this.plantAdpter.convertSubPlantToDto(response);
            } catch (error) {
                  return null;
            }
      }

      async createSubPlant(plantDTO: SubPlantDTO): Promise<SubPlantDTO> {
            try {
                  const plantData = this.plantAdpter.convertDtoToSubPlant(plantDTO);
                  const plant = {...plantData};
                  const response = await this.entity.save(plant);
                  return this.plantAdpter.convertSubPlantToDto(response);
            } catch (error) {
                  return null;
            }
      }

      async updatePlant(plantDTO: PlantDTO, plantcode: string): Promise<boolean> {
            const plantData = this.plantAdpter.convertDtoToPlant(plantDTO);
            const obj = await this.entity.save(plantData);
            return obj ? true : false;
      }

      async deActivatePlant(plantcode: string): Promise<boolean> {
            const obj = await this.entity.update({plant_code: plantcode}, {isActive: false, deactivated_date: new Date().toISOString().slice(0, 10)});
            return obj ? true : false;
      }     

      async checkPlantCode(plantcode: string): Promise<boolean> {
            const a = await this.entity.findOne({where: {plant_code: plantcode}});
            return a ? true : false;
      }

      async checkSubPlantcode(plantcode: string): Promise<boolean> {
            const a = await this.entity.find({where: {isActive: true, parentPlantCode: {plant_code: plantcode}}});
            return a.length > 0 ? true : false;
      }

      async checkCluster(clusterCode: string): Promise<boolean> {
            return await this.clusterService.findIfClusterExist(clusterCode);
      }

      async findPlant(plantCode: string): Promise<SubPlantDTO> {
            return this.plantAdpter.convertSubPlantToDto(await this.entity.findOne({where: {plant_code: plantCode}, relations: ['plantLocation',
            'plantLocation.addressU', 'contactDetails', 'contactDetails.contactU', 'parentPlantCode', 'clusterCode']}));
      }

      async getPlantByClusterCode(clusterCode: string): Promise<SubPlantDTO[]> {
            const plantsData = await this.entity.find({where: {clusterCode: {cluster_code: clusterCode}}, relations: ['plantLocation',
            'plantLocation.addressU', 'contactDetails', 'contactDetails.contactU', 'parentPlantCode', 'clusterCode']});
            return plantsData.map(v => {
                  return this.plantAdpter.convertSubPlantToDto(v);
            });
      }

      async checkActiveDepartment(plantCode: string): Promise<boolean> {
            return (await this.departmentEntity.find({where: {plantCode:{plant_code:plantCode}, isActive: true}})).length>0 ? true : false;
      }
}
