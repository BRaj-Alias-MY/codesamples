import {SectionDTO} from 'src/dtos/section.dto';

export class SectionCreateResponse {
    status: boolean;
    data?: SectionDTO;
    errorInfo?: string;
}

export class GetSectionsResponse {
    status: boolean;
    data?: SectionDTO[];
    errorInfo?: string;
}

export class GetSectionResponse {
    status: boolean;
    data?: boolean;
    errorInfo?: string;
}
