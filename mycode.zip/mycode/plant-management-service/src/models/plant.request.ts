import { ApiModelProperty } from '@nestjs/swagger';

export class PlantCodeModel {
      @ApiModelProperty()
      plant_code: string;
}
