
import { IsNumber, IsString, IsBoolean ,IsArray } from 'class-validator';
import { ClusterDto } from 'src/dtos/cluster.dto';
import { ApiModelProperty }  from '@nestjs/swagger';

export class RequestAllClusterObject{
    @ApiModelProperty()
    @IsNumber()
    page_number :  number;
}

export class RequestClusterObject{
    @ApiModelProperty()
    @IsString()
    cluster_code : string;
}

export class RequestAllClusterForPlantObject{
    @ApiModelProperty()
    @IsString()
    company_code :  string;
}


export class ReturnClusterResult{
    status : boolean;
    errInfo ?: string;
    data ?:  ClusterDto
}

export class ReturnFindAllClustersResult{
    status : boolean;
    errInfo ?: string;
    data ?:  ClusterDto[]
}
