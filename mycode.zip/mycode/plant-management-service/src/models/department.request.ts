import { ApiModelProperty } from "@nestjs/swagger";
import { IsNumber, IsString } from "class-validator";

export class DepartmentFindObject
{
    @ApiModelProperty()
    @IsNumber()
    page : number
}
export class DepartmentFindByCode
{
    @ApiModelProperty()
    @IsString()
    department_code : string
}

