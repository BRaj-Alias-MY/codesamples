import {SectionDTO} from 'src/dtos/section.dto';
import { ApiModelProperty } from '@nestjs/swagger';

export class SectionRequest {
    @ApiModelProperty()
    section_code: string;
}