import { DepartmentDto } from "src/dtos/department.dto";

export class DepartmentCreateObject
{
    status : boolean;
    errInfo ?: string;
    data ?: DepartmentDto;
}
export class DepartmentFindObject
{
    status : boolean;
    errInfo ?: string;
    data ?: DepartmentDto[];
}