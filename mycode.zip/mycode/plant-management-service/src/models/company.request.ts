import { ApiModelProperty } from '@nestjs/swagger';

export class CompanyRequest {
    @ApiModelProperty()
    company_code: string;
}