import { CompanyDTO } from 'src/dtos/company.dto';

export class CompanyCreateResponse {
    status: boolean;
    data?: CompanyDTO;
    errorInfo?: string;
}

export class GetCompaniesResponse {
    status: boolean;
    data?: CompanyDTO[];
    errorInfo?: string;
}

export class GetCompanyResponse {
    status: boolean;
    data?: boolean;
    errorInfo?: string;
}