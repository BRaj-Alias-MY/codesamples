import {PlantDTO} from 'src/dtos/plant.dto';
import {SubPlantDTO} from 'src/dtos/subplant.dto';

export class PlantResponseModel {
      status: boolean;
      errInfo?: string;
      data?: SubPlantDTO;
}

export class PlantsResponseModel {
      status: boolean;
      errInfo?: string;
      data?: SubPlantDTO[];
}

export class SubPlantResponseModel {
      status: boolean;
      errInfo?: string;
      data?: SubPlantDTO;
}