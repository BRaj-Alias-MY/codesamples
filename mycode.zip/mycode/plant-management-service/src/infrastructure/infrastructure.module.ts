import { DepartmentsAdapter } from 'src/adapters/department.adapter';
import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { SectionController } from '../controllers/section.controller';
import { SectionService } from '../services/section.service';
import { SectionAdapter } from '../adapters/section.adapter';
import { PlantController } from 'src/controllers/plant.controller';
import { PlantService } from 'src/services/plant.service';
import { PlantAdapter } from 'src/adapters/plant.adapter';
import { ClusterController } from 'src/controllers/cluster.controller';
import { CompanyController } from 'src/controllers/company.controller';
import { ClusterService } from 'src/services/cluster.service';
import { CompanyService } from 'src/services/company.service';
import { CompanyAdapter } from 'src/adapters/company.adapter';
import { DepartmentsService } from 'src/services/department.service';
import { DepartmentsController } from 'src/controllers/department.controller';
import { IdmsAddress } from 'src/entities/idms_address';
import { IdmsContact } from 'src/entities/idms_contact';
import { IdmsLocation } from 'src/entities/idms_location';
import { IdmsUserDetails } from 'src/entities/idms_user_details';
import { PmsCompanies } from 'src/entities/pms_companies';
import { PmsCluster } from 'src/entities/pms_cluster';
import { PmsPlant } from 'src/entities/pms_plant';
import { PmsDepartments } from 'src/entities/pms_departments';
import { PmsSections } from 'src/entities/pms_sections';



@Module({
    imports: [TypeOrmModule.forFeature([IdmsAddress,IdmsContact,IdmsLocation,IdmsUserDetails,PmsCompanies,PmsCluster,PmsPlant,PmsDepartments,PmsSections])],
    controllers: [ PlantController, CompanyController, ClusterController, DepartmentsController, SectionController],
    providers: [ PlantService, PlantAdapter,CompanyService, CompanyAdapter, DepartmentsAdapter, ClusterService, DepartmentsService,SectionService,SectionAdapter],
})

export class InfrastructureModule { }
