import { Controller, Post, Body, Logger} from '@nestjs/common';
import { DepartmentsService } from '../services/department.service';
import { DepartmentDto } from '../dtos/department.dto';
import { DepartmentFindByCode} from 'src/models/department.request';
import { DepartmentCreateObject,DepartmentFindObject} from 'src/models/department.response';
import { PlantService } from 'src/services/plant.service';


@Controller('departments')
export class DepartmentsController {
    private logger = new Logger('DepartmentsController')
    constructor(private service: DepartmentsService , private platService : PlantService) { }
    
    @Post('/createDepartment')
    async createDepartment(@Body() department:DepartmentDto):Promise<DepartmentCreateObject>{   
        const departmentExists = await this.service.validatingDepartmentExists(department.department_code);
        const plantExists = await this.platService.checkPlantCode(department.plant_code);
        const response_obj = new DepartmentCreateObject();
        if(!departmentExists && plantExists){
            return await this.service.createDepartment(department).then((data)=>{
                response_obj.data = data;
                response_obj.status = true;
                return response_obj
            }).catch((err)=>{
                response_obj.status = false;
                response_obj.errInfo = "failed";
                return response_obj
            });
        }
        else{
            response_obj.errInfo = "Department Already Exists for selected Plant Code";
            response_obj.status=false;
            return response_obj;
        }
    }

    @Post('/deActivateDepartment')
    async deActivateDepartment(@Body() departmentvalidationobj:DepartmentFindByCode):Promise<DepartmentCreateObject>{
        const IsDeactivateValidation = await this.service.deActivateDepartmentValidation(departmentvalidationobj.department_code);
        const response_obj = new DepartmentCreateObject();
        if(IsDeactivateValidation){
            return await this.service.deActivateDepartment(departmentvalidationobj.department_code).then((data)=>{
                response_obj.status = true;
                response_obj.errInfo = "success";
                return response_obj
            }).catch((err)=>{
                response_obj.status = false;
                response_obj.errInfo = "failed";
                return response_obj
            })
        }
        else{
            const response_obj = new DepartmentCreateObject();
            response_obj.errInfo = "You Can't delete the Department";
            response_obj.status=false;
            return response_obj;
        }
    }

    @Post('/getAllDepartments')
    async getAllDepartments():Promise<DepartmentFindObject>{
        const response_obj = new DepartmentFindObject();
        return await this.service.getAllDepartments().then((data)=>{
            response_obj.data = data;
            response_obj.status = true;
            return response_obj

        }).catch((err)=>{
            response_obj.status = false;
            response_obj.errInfo = err.errInfo;
            return response_obj;
        });
    }

    @Post('/getDepartment')
    getDepartment(@Body() departmentCode : DepartmentFindByCode):Promise<DepartmentCreateObject>{
        const response_obj = new DepartmentCreateObject();
        return this.service.getDepartment(departmentCode.department_code).then((data)=>{
            if(data){
                response_obj.data = data;
                response_obj.status = true;
                return response_obj
            }else{
                response_obj.data = data;
                response_obj.status = false;
                return response_obj
            }
        }).catch((err)=>{
            response_obj.status = false;
            response_obj.errInfo = err.errInfo;
            return response_obj;
        });
    }

    @Post('/updateDepartment')
    async updateDepartment(@Body() department:DepartmentDto):Promise<DepartmentCreateObject>{   
        const departmentExists = await this.service.validatingDepartmentExists(department.department_code);
        const plantExists = await this.platService.checkPlantCode(department.plant_code);
        if(departmentExists && plantExists){
            const response_obj = new DepartmentCreateObject();
            return await this.service.createDepartment(department).then((data)=>{
                response_obj.data = data;
                response_obj.status = true;
                return response_obj
            }).catch((err)=>{
                response_obj.errInfo = err;
                response_obj.status = false;
                response_obj.errInfo = "failed";
                return response_obj
            });
        }
        else{
            const response_obj = new DepartmentCreateObject();
            response_obj.errInfo = "Department Does Not Exists for selected Plant Code";
            response_obj.status=false;
            return response_obj;
        }
    }
}
    