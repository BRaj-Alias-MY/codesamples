import { Controller, Post, Body, UsePipes } from '@nestjs/common';
import { PlantService } from 'src/services/plant.service';
import { PlantsResponseModel } from 'src/models/plant.response';
import { PlantResponseModel } from 'src/models/plant.response';
import { PlantDTO } from 'src/dtos/plant.dto';
import { PlantCodeModel } from 'src/models/plant.request';
import { RequestClusterObject } from 'src/models/cluster.request';
import { SubPlantDTO } from 'src/dtos/subplant.dto';
import { SubPlantResponseModel } from 'src/models/plant.response';

@Controller('plant')
export class PlantController {

      constructor(private service: PlantService) { }

      @Post('/createPlant')
      async createPlant(@Body() plant: PlantDTO): Promise<PlantResponseModel> {
            const response = new PlantResponseModel();
            if (await this.service.checkCluster(plant.cluster_code)) {
                  if (await this.service.checkPlantCode(plant.plant_code)) {
                        response.status = false;
                        response.errInfo = 'plant code already exist.';
                        return response;
                  } else {
                        const obj = await this.service.createPlant(plant);
                        response.status = obj ? true : false;
                        response.errInfo = obj ? null : 'Error while creating plant. Please check your input values.';
                        response.data = obj ? obj : null;
                        return response;
                  }
            } else {
                  response.status = false;
                  response.errInfo = 'cluster not exist.';
                  return response;
            }
      }

      @Post('/createSubPlant')
      async createSubPlant(@Body() input: SubPlantDTO) {
            const response = new SubPlantResponseModel();
            if (await this.service.checkCluster(input.cluster_code)) {
                  if (await this.service.checkPlantCode(input.plant_code)) {
                        response.status = false;
                        response.errInfo = 'plant code already exist.';
                        return response;
                  } else {
                        if (await this.service.checkPlantCode(input.parent_plant_code)) {
                              const obj = await this.service.createSubPlant(input);
                              response.status = obj ? true : false;
                              response.errInfo = obj ? null : 'Error while creating plant. Please check your input values.';
                              response.data = obj ? obj : null;
                              return response;
                        }else{
                              response.status = false;
                              response.errInfo = 'Parent Plant code Not exist.';
                              return response;
                        }
                  }
            } else {
                  response.status = false;
                  response.errInfo = 'cluster not exist.';
                  return response;
            }
      }

      @Post('/getAllPlants')
      async getAllPlants(): Promise<PlantsResponseModel> {
            const response = new PlantsResponseModel();
            const obj = await this.service.getAllPlants();
            if (obj.length > 0) {
                  response.status = true;
                  response.data = obj;
                  return response;
            } else {
                  response.status = false;
                  response.errInfo = 'No data found.';
                  return response;
            }
      }

      @Post('/deActivatePlant')
      async deActivatePlant(@Body() plant: PlantCodeModel): Promise<PlantsResponseModel> {
            const response = new PlantsResponseModel();
            if (await this.service.checkPlantCode(plant.plant_code)) {
                  if (await this.service.checkSubPlantcode(plant.plant_code)) {
                        response.status = false;
                        response.errInfo = 'Sub plants are active for ' + plant.plant_code;
                        return response;
                  } else {
                        if(await this.service.checkActiveDepartment(plant.plant_code))
                        {
                              response.status  = false;
                              response.errInfo = 'Please deactivate all the departments under this plant.';
                              return response;
                        }else{
                              if (await this.service.deActivatePlant(plant.plant_code)) {
                                    const obj = await this.service.getAllPlants();
                                    if (obj.length > 0) {
                                          response.status = true;
                                          response.data = obj;
                                          response.errInfo = 'plant Deactivated.';
                                    } else {
                                          response.status = true;
                                          response.errInfo = 'plant Deactivated.';
                                    }
                                    return response;
                              } else {
                                    response.status = false;
                                    response.errInfo = 'Fail to Deactivete data.';
                                    return response;
                              }
                        }
                  }
            } else {
                  response.status = false;
                  response.errInfo = 'Plant code not found.';
                  return response;
            }
      }

      @Post('/updatePlant')
      async updatePlant(@Body() input: PlantDTO): Promise<PlantsResponseModel> {
            const response = new PlantsResponseModel();
            if (await this.service.updatePlant(input, input.plant_code)) {
                  const obj = await this.service.getAllPlants();
                  if (obj.length > 0) {
                        response.status = true;
                        response.data = obj;
                        response.errInfo = 'plant updated.';
                  } else {
                        response.status = true;
                        response.errInfo = 'plant updated.';
                  }
                  return response;
            } else {
                  response.status = false;
                  response.errInfo = 'failed to update.';
                  return response;
            }
      }

      @Post('/getPlant')
      async findPlant(@Body() input: PlantCodeModel): Promise<PlantResponseModel> {
            const response = new PlantResponseModel();
            if (await this.service.checkPlantCode(input.plant_code)) {
                  const obj = await this.service.findPlant(input.plant_code);
                  response.status = true;
                  response.data = obj;
                  return response;
            } else {
                  response.status = false;
                  response.errInfo = 'Plant Not Found.';
                  return response;
            }
      }

      @Post('/getPlantByClusterCode')
      async getPlantByClusterCode(@Body() input: RequestClusterObject): Promise<PlantsResponseModel> {
            const response = new PlantsResponseModel();
            if(await this.service.checkCluster(input.cluster_code)){
                  const plants = await this.service.getPlantByClusterCode(input.cluster_code);
                  if (plants.length > 0) {
                        response.status = true;
                        response.data = plants;
                  } else {
                        response.status = false;
                        response.errInfo = 'No Data found.';
                  }
                  return response;
            } else {
                  response.status = false;
                  response.errInfo = 'Cluster Not found.';
                  return response;
            }
      }
}
