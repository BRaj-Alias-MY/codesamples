
import { ValidationPipe } from 'src/shared/validation.pipe';
import { Controller, Post, Body, UsePipes, Logger } from '@nestjs/common';
import { ClusterService } from 'src/services/cluster.service';
import { ClusterDto } from 'src/dtos/cluster.dto';
import { RequestClusterObject,RequestAllClusterObject,ReturnClusterResult,ReturnFindAllClustersResult,RequestAllClusterForPlantObject } from 'src/models/cluster.request';


@Controller('cluster')
export class ClusterController {
    private logger = new Logger('ClusterController')
    constructor(private clusterService: ClusterService) {
        //Do Nothing
    }

    @Post('/getAllClusters')
    async getAllClusters():Promise<ReturnFindAllClustersResult>{
        let returnFindAllClustersResult = new  ReturnFindAllClustersResult();
        return await this.clusterService.getAllClusters().then(clusters=>{
            if(clusters){
                returnFindAllClustersResult.data = clusters;
                returnFindAllClustersResult.status = true;
                return returnFindAllClustersResult;
            }else{
                returnFindAllClustersResult.errInfo = 'No Clusters Found';
                returnFindAllClustersResult.status = false;
                return returnFindAllClustersResult;
            }
        }).catch(err=>{
            returnFindAllClustersResult.errInfo = 'Unable to Load Clusters'; 
            returnFindAllClustersResult.status = false;
            return returnFindAllClustersResult;
        });
    }
    
    @Post('/getCluster')
    async getCluster(@Body() cluster_code : RequestClusterObject):Promise<ReturnClusterResult>{
        let requestClusterObject = new  ReturnClusterResult();
        return await this.clusterService.getCluster(cluster_code.cluster_code).then(cluster=>{
            if(cluster){
                requestClusterObject.data = cluster;
                requestClusterObject.status = true;
                return requestClusterObject;
            }else{
                requestClusterObject.errInfo = 'No Clusters Found'; 
                requestClusterObject.status = false;
                return requestClusterObject;
            }
        }).catch(err=>{
            requestClusterObject.errInfo = 'Cluster Not Found'; 
            requestClusterObject.status = false;
            return requestClusterObject;
        });
    }

    @Post('/getAllClustersForCompany')
    async getClustersForCompany(@Body() company : RequestAllClusterForPlantObject):Promise<ReturnFindAllClustersResult>{
        let returnFindAllClustersResult = new  ReturnFindAllClustersResult();
        return await this.clusterService.getClustersForCompany(company.company_code).then(clusters=>{
            if(clusters){
                returnFindAllClustersResult.data = clusters;
                returnFindAllClustersResult.status = true;
                return returnFindAllClustersResult;
            }else{
                returnFindAllClustersResult.errInfo = 'No Clusters Found For the  Company'; 
                returnFindAllClustersResult.status = false;
                return returnFindAllClustersResult;
            }
        }).catch(err=>{
            returnFindAllClustersResult.errInfo = 'Unable to Load Clusters for Company'; 
            returnFindAllClustersResult.status = false;
            return returnFindAllClustersResult;
        });
    }

    @Post('/createCluster')
    async createCluster(@Body() clusterDto : ClusterDto):Promise<ReturnClusterResult>{
        this.logger.log(JSON.stringify(clusterDto));
        const returnClusterResult = new  ReturnClusterResult();
        const clusterExist = await this.clusterService.findIfClusterExist(clusterDto.cluster_code)        
        if(clusterExist){
            returnClusterResult.errInfo = 'Cluster Already Exist'; 
            returnClusterResult.status = false;
            return returnClusterResult;
        }else{
            return await this.clusterService.createCluster(clusterDto).then(async res=>{
                if(res){
                    returnClusterResult.data = res;
                    returnClusterResult.status = true;
                    return returnClusterResult;
                }else{
                    returnClusterResult.errInfo = 'Company Does not Exist'; 
                    returnClusterResult.status = false;
                    return returnClusterResult;
                }
            }).catch(err=>{
                returnClusterResult.errInfo = 'Unable to save Cluster '; 
                returnClusterResult.status = false;
                return returnClusterResult;
            });
        }
    }

    @Post('/updateCluster')
    async updateCluster(@Body() clusterDto : ClusterDto ):Promise<ReturnClusterResult>{
        this.logger.log(JSON.stringify(clusterDto))
        const returnClusterResult = new ReturnClusterResult();
        const clusterExist = await this.clusterService.findIfClusterExist(clusterDto.cluster_code);
        if(clusterExist){
            return await this.clusterService.updateCluster(clusterDto).then(updatedCluster=>{
                returnClusterResult.status = true;
                returnClusterResult.data = updatedCluster;
                return returnClusterResult;
            }).catch(err=>{
                returnClusterResult.status = false;
                returnClusterResult.errInfo = 'Cluster Updating Problem';
                return returnClusterResult;
            });
        }else{
            returnClusterResult.errInfo = 'Cluster Does not Exist'; 
            returnClusterResult.status = false;
            return returnClusterResult;
        }
       
    }

    @Post('/deActivateCluster')
    async deActivateCluster(@Body() cluster_code : RequestClusterObject):Promise<ReturnClusterResult>{
        const returnClusterResult = new ReturnClusterResult();
        if(await this.clusterService.findIfClusterExist(cluster_code.cluster_code)){
            const res =  await this.clusterService.deActivateCluster(cluster_code.cluster_code);
            if(res){
                returnClusterResult.status = true;
                return returnClusterResult;
            }else{
                returnClusterResult.errInfo = 'Cluster Not Deleted'; 
                returnClusterResult.status = false;
                return returnClusterResult;
            }
        }else{
            returnClusterResult.errInfo = 'Cluster does not exist to delete'; 
            returnClusterResult.status = false;
            return returnClusterResult;
        }
    }
}
