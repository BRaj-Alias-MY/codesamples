import { Controller, Get, Post, Put, Delete, Body, Param, UsePipes, Logger, Query } from '@nestjs/common';
import { CompanyDTO } from 'src/dtos/company.dto';
import { CompanyService } from 'src/services//company.service';
import { CompanyCreateResponse, GetCompaniesResponse, GetCompanyResponse } from 'src/models/company.response';
import { CompanyRequest } from 'src/models/company.request';

@Controller('company')
export class CompanyController {
    private logger = new Logger('CompanyController');
    constructor(private companyService: CompanyService) {
    }

    @Post('/createCompany')
    async createCompany(@Body() companyDetails: CompanyDTO): Promise <CompanyCreateResponse> {
        this.logger.log(JSON.stringify(companyDetails));
        const response = new CompanyCreateResponse();
        const companyExists = await this.companyService.verifyIfCompanyExists(companyDetails.company_code);
        if (!companyExists) {
            return await this.companyService.saveCompany(companyDetails).then(
                company => {
                    response.status = true;
                    response.data = company;
                    return response;
                },

            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } else {
            response.status = false;
            response.errorInfo = 'Company code already exist.';
            return response;
        }
    }

    @Post('/getCompanyByCompanycode')
    async getCompany(@Body() companyRequest: CompanyRequest): Promise <CompanyCreateResponse> {
        this.logger.log(JSON.stringify(companyRequest));
        const response = new CompanyCreateResponse();
        return await this.companyService.getCompanyDetails(companyRequest.company_code).then(
            company => {
                if (company) {
                    response.status = true;
                    response.data = company;
                    return response;
                } else {
                    response.status = false;
                    response.errorInfo = 'Company not found';
                    return response;
                }
            },
        ).catch(err => {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        });
    }

    @Post('/updateCompany')
    async updateCompany(@Body() companyDetails: CompanyDTO): Promise <CompanyCreateResponse>{
        this.logger.log(JSON.stringify(companyDetails));
        const response = new CompanyCreateResponse();
        const companyExists = await this.companyService.verifyIfCompanyExists(companyDetails.company_code);
        if (companyExists) {
            return await this.companyService.saveCompany(companyDetails).then(
                company => {
                    response.status = true;
                    response.data = company;
                    return response;
                },

            ).catch(err => {
                response.status = false;
                response.errorInfo = err.message;
                return response;
            });
        } else {
            response.status = false;
            response.errorInfo = 'Company not found.';
            return response;
        }
    }

    @Post('/getAllCompanies')
    async getAllCompanies(): Promise <GetCompaniesResponse> {
        const response = new GetCompaniesResponse();
        return await this.companyService.getAllCompanies().then(
            companies => {
                response.status = true;
                response.data = companies;
                return response;
            },
        ).catch(err => {
            response.status = false;
            response.errorInfo = err.message;
            return response;
        });
    }

    @Post('/deActivateCompany')
    async deActivateCompany(@Body() companyRequest: CompanyRequest): Promise<GetCompanyResponse>  {
        this.logger.log(JSON.stringify(companyRequest));
        const response = new GetCompanyResponse();
        const companyExists = await this.companyService.verifyIfCompanyExists(companyRequest.company_code);
        if (companyExists) {
            const clusterExists = await this.companyService.checkActiveCluster(companyRequest.company_code);
            if(clusterExists){
                response.status = false;
                response.errorInfo = 'Cluster Exists For this Company';
                return response;
            }else{
                return await this.companyService.deActivateCompany(companyRequest.company_code).then(
                    res => {
                        if(res){
                            response.status = true;
                            return response;
                        }else{
                            response.status = false;
                            response.errorInfo = 'Error Occured while Deleting Company';
                            return response;
                        }
                    },
                ).catch(err => {
                    response.status = false;
                    response.errorInfo = err.message;
                    return response;
                });
            }
        } else {
            response.status = false;
            response.errorInfo = 'Company not found.';
            return response;
        }
    }
}
