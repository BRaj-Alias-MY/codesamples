import { Controller, Get, Post, Put, Delete, Body, Param, UsePipes, Logger, Query } from '@nestjs/common';
import {SectionService} from '../services/section.service';
import {SectionDTO} from 'src/dtos/section.dto'
import {SectionRequest} from 'src/models/section.request';
import {SectionCreateResponse,GetSectionsResponse,GetSectionResponse} from 'src/models/section.response';
import { DepartmentsService } from '../services/department.service';


@Controller('section')
export class SectionController {
    
    constructor(private sectionService: SectionService, private departmentService : DepartmentsService){
    }
   
    @Post('/getAllSections')
    async getAllSections(): Promise<GetSectionsResponse> {
        const response = new GetSectionsResponse();
        const obj = await this.sectionService.getAllSections();
        if (obj.length > 0) {
            response.status = true;
            response.data  =  obj;
            return response;
        } else {
            response.status = false;
            response.errorInfo = "No Data Found";
            return response;
        }
    }

    @Post('/getSection')
    async getSection(@Body() sectionCode : SectionRequest) {
        const response = new SectionCreateResponse();
        const validatesection = await this.sectionService.validateSection(sectionCode.section_code);
        if (validatesection) {
            const obj = await this.sectionService.getSection(sectionCode.section_code);
            response.status = true;
            response.data = obj;
            return response;
        } else {
            response.status = false;
            response.errorInfo = 'Section Not Found.';
            return response;
        }
    }

    @Post('/createSection')
    async createSection(@Body() sectiondata: SectionDTO) {
        const validatesection = await this.sectionService.validateSection(sectiondata.section_code);
        const validatedepartment = await this.departmentService.validatingDepartmentExists(sectiondata.departmentCode);
        if(!validatesection){
            if(validatedepartment){
                return await this.sectionService.createSection(sectiondata).then((response)=>{
                    const response_obj = new SectionCreateResponse();
                    response_obj.errorInfo = "success";
                    response_obj.data = response;
                    response_obj.status=true;
                    return response_obj;
                }).catch((err)=>{
                    const response_obj = new SectionCreateResponse();
                    response_obj.errorInfo = "failed";
                    response_obj.status=false;
                    return response_obj;
                })
            }else{
                const response_obj = new SectionCreateResponse();
                response_obj.errorInfo = "Department Does Not Exist";
                response_obj.status=false;
                return response_obj;
            }
        }
        else
        {
            const response_obj = new SectionCreateResponse();
            response_obj.errorInfo = "Section Already Exist";
            response_obj.status=false;
            return response_obj;
        } 
    }

    
 
    @Post('/updateSection')
    async updateSection(@Body() sectiondata: SectionDTO) {
        const validatesection = await this.sectionService.validateSection(sectiondata.section_code);
        const validatedepartment = await this.departmentService.validatingDepartmentExists(sectiondata.departmentCode);
        if(validatesection && validatedepartment){
            return await this.sectionService.createSection(sectiondata).then((response)=>{
                const response_obj = new SectionCreateResponse();
                response_obj.errorInfo = "Updated Sucessfully";
                response_obj.status=true;
                response_obj.data = response;
                return response_obj;
            }).catch((err)=>{
                const response_obj = new SectionCreateResponse();
                response_obj.errorInfo = "failed";
                response_obj.status=false;
                return response_obj;
            })
        }else{
            const response_obj = new SectionCreateResponse();
            response_obj.errorInfo = "Section not found";
            response_obj.status=false;
            return response_obj;
        } 
            
    }


    @Post('/deActivateSection')
    async deActivateSection(@Body() sectionCode: SectionRequest)
    {
        const response_obj = new SectionCreateResponse();
        const sectionExists =  await this.sectionService.validateSection(sectionCode.section_code);
        if (sectionExists) {
            return await this.sectionService.deActivateSection(sectionCode.section_code).then((response)=>{
                response_obj.errorInfo = "Deleted Sucessfully";
                response_obj.status=true;
                return response_obj;
            }).catch((err)=>{
                response_obj.errorInfo = "failed";
                response_obj.status=false;
                return response_obj;
            })
        } else {
            response_obj.status = false;
            response_obj.errorInfo = 'Section not found.';
            return response_obj;
        } 
    }
      
}
