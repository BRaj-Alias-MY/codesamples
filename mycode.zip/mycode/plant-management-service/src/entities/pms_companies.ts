import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsLocation} from "./idms_location";
import {IdmsUserDetails} from "./idms_user_details";
import {PmsCluster} from "./pms_cluster";


@Entity("pms_companies",{schema:"public" } )
@Index("fki_location",["locationU",])
@Index("fki_user",["userU",])
export class PmsCompanies {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:20,
        name:"company_code"
        })
    company_code:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:30,
        name:"company_name"
        })
    company_name:string;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:false,
        default: () => "true",
        name:"isActive"
        })
    isActive:boolean;
        

   
    @ManyToOne(type=>IdmsLocation, idms_location=>idms_location.pmsCompaniess,{ cascade: true })
    @JoinColumn({ name:'location_uid'})
    locationU:IdmsLocation | null;


   
    @ManyToOne(type=>IdmsUserDetails, idms_user_details=>idms_user_details.pmsCompaniess,{ cascade: true })
    @JoinColumn({ name:'user_uid'})
    userU:IdmsUserDetails | null;


   
    @OneToMany(type=>PmsCluster, pms_cluster=>pms_cluster.corporateCode)
    pmsClusters:PmsCluster[];
    
}
