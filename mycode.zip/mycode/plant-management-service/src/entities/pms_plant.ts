import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsLocation} from "./idms_location";
import {IdmsUserDetails} from "./idms_user_details";
import {PmsCluster} from "./pms_cluster";
import {PmsDepartments} from "./pms_departments";


@Entity("pms_plant",{schema:"public" } )
@Index("fk_cluster_code",["clusterCode",])
@Index("fk_userdetails",["contactDetails",])
@Index("fki_plant_fk",["parentPlantCode",])
@Index("fk_location",["plantLocation",])
export class PmsPlant {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:10,
        name:"plant_code"
        })
    plant_code:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:50,
        name:"plant_name"
        })
    plant_name:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"m3_production_plant_code"
        })
    m3_production_plant_code:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:10,
        name:"plant_type"
        })
    plant_type:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

    @Column("boolean",{ 
        nullable:true,
        name:"isActive"
        })
    isActive:boolean | null;
        

    @Column("time without time zone",{ 
        nullable:true,
        name:"plant_start_time"
        })
    plant_start_time:string | null;
        

    @Column("time without time zone",{ 
        nullable:true,
        name:"plant_end_time"
        })
    plant_end_time:string | null;
        

   
    @ManyToOne(type=>PmsPlant, pms_plant=>pms_plant.pmsPlants,{  })
    @JoinColumn({ name:'parent_plant_code'})
    parentPlantCode:PmsPlant | null;


   
    @ManyToOne(type=>IdmsLocation, idms_location=>idms_location.pmsPlants,{  nullable:false, cascade: true})
    @JoinColumn({ name:'plant_location'})
    plantLocation:IdmsLocation | null;


   
    @ManyToOne(type=>IdmsUserDetails, idms_user_details=>idms_user_details.pmsPlants,{  nullable:false,cascade: true })
    @JoinColumn({ name:'contact_details'})
    contactDetails:IdmsUserDetails | null;


   
    @ManyToOne(type=>PmsCluster, pms_cluster=>pms_cluster.pmsPlants,{  })
    @JoinColumn({ name:'cluster_code'})
    clusterCode:PmsCluster | null;


   
    @OneToMany(type=>PmsDepartments, pms_departments=>pms_departments.plantCode)
    pmsDepartmentss:PmsDepartments[];
    

   
    @OneToMany(type=>PmsPlant, pms_plant=>pms_plant.parentPlantCode)
    pmsPlants:PmsPlant[];
    
}
