import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsUserDetails} from "./idms_user_details";
import {PmsPlant} from "./pms_plant";
import {PmsSections} from "./pms_sections";


@Entity("pms_departments",{schema:"public" } )
@Index("fki_fk_plantcode",["plantCode",])
@Index("fki_fk_departmenthead",["userU",])
export class PmsDepartments {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:10,
        name:"department_code"
        })
    department_code:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:30,
        name:"department_name"
        })
    department_name:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:10,
        name:"department_type"
        })
    department_type:string;
        

    @Column("bigint",{ 
        nullable:false,
        name:"sla"
        })
    sla:string;
        

    @Column("boolean",{ 
        nullable:false,
        name:"is_active"
        })
    is_active:boolean;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

   
    @ManyToOne(type=>IdmsUserDetails, idms_user_details=>idms_user_details.pmsDepartmentss,{  nullable:false, cascade:true})
    @JoinColumn({ name:'user_uid'})
    userU:IdmsUserDetails | null;


   
    @ManyToOne(type=>PmsPlant, pms_plant=>pms_plant.pmsDepartmentss,{  nullable:false, })
    @JoinColumn({ name:'plant_code'})
    plantCode:PmsPlant | null;


   
    @OneToMany(type=>PmsSections, pms_sections=>pms_sections.departmentCode)
    pmsSectionss:PmsSections[];
    
}
