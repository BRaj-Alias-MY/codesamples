import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {PmsCompanies} from "./pms_companies";
import {IdmsLocation} from "./idms_location";
import {IdmsUserDetails} from "./idms_user_details";
import {PmsPlant} from "./pms_plant";


@Entity("pms_cluster",{schema:"public" } )
@Index("fki_company_fk",["corporateCode",])
@Index("fki_location_fkey",["locationU",])
@Index("fki_user_fk",["userU",])
export class PmsCluster {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:20,
        name:"cluster_code"
        })
    cluster_code:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:50,
        name:"cluster_name"
        })
    cluster_name:string;
        

    @Column("boolean",{ 
        nullable:true,
        name:"isActive"
        })
    isActive:boolean | null;
        

    @Column("date",{ 
        nullable:true,
        name:"activated_date"
        })
    activated_date:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"deactivated_date"
        })
    deactivated_date:string | null;
        

   
    @ManyToOne(type=>PmsCompanies, pms_companies=>pms_companies.pmsClusters,{  nullable:false, })
    @JoinColumn({ name:'corporate_code'})
    corporateCode:PmsCompanies | null;


   
    @ManyToOne(type=>IdmsLocation, idms_location=>idms_location.pmsClusters,{ cascade:true })
    @JoinColumn({ name:'location_uid'})
    locationU:IdmsLocation | null;


   
    @ManyToOne(type=>IdmsUserDetails, idms_user_details=>idms_user_details.pmsClusters,{ cascade:true })
    @JoinColumn({ name:'user_uid'})
    userU:IdmsUserDetails | null;


   
    @OneToMany(type=>PmsPlant, pms_plant=>pms_plant.clusterCode)
    pmsPlants:PmsPlant[];
    
}
