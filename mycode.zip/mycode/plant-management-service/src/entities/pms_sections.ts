import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsUserDetails} from "./idms_user_details";
import {PmsDepartments} from "./pms_departments";


@Entity("pms_sections",{schema:"public" } )
@Index("fki_fk_section_dept",["departmentCode",])
@Index("fki_fk_section_user",["user",])
export class PmsSections {

    @Column("character varying",{ 
        nullable:false,
        primary:true,
        length:10,
        name:"section_code"
        })
    section_code:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:30,
        name:"section_name"
        })
    section_name:string;
        

    @Column("boolean",{ 
        nullable:false,
        name:"isActive"
        })
    isActive:boolean;
        

   
    @ManyToOne(type=>IdmsUserDetails, idms_user_details=>idms_user_details.pmsSectionss,{  nullable:false, cascade:true})
    @JoinColumn({ name:'user_id'})
    user:IdmsUserDetails | null;


   
    @ManyToOne(type=>PmsDepartments, pms_departments=>pms_departments.pmsSectionss,{  nullable:false, cascade:true})
    @JoinColumn({ name:'department_code'})
    departmentCode:PmsDepartments | null;

}
