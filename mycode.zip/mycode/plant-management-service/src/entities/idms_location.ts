import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsAddress} from "./idms_address";
import {PmsCluster} from "./pms_cluster";
import {PmsCompanies} from "./pms_companies";
import {PmsPlant} from "./pms_plant";


@Entity("idms_location",{schema:"public" } )
@Index("fki_fk_address",["addressU",])
export class IdmsLocation {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"location_uid"
        })
    location_uid:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"location_type"
        })
    location_type:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:10,
        name:"lat"
        })
    lat:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:10,
        name:"long"
        })
    long:string | null;
        

   
    @ManyToOne(type=>IdmsAddress, idms_address=>idms_address.idmsLocations,{  nullable:false, cascade:true})
    @JoinColumn({ name:'address_uid'})
    addressU:IdmsAddress | null;


   
    @OneToMany(type=>PmsCluster, pms_cluster=>pms_cluster.locationU)
    pmsClusters:PmsCluster[];
    

   
    @OneToMany(type=>PmsCompanies, pms_companies=>pms_companies.locationU)
    pmsCompaniess:PmsCompanies[];
    

   
    @OneToMany(type=>PmsPlant, pms_plant=>pms_plant.plantLocation)
    pmsPlants:PmsPlant[];
    
}
