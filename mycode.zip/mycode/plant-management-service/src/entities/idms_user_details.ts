import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsContact} from "./idms_contact";
import {PmsCluster} from "./pms_cluster";
import {PmsCompanies} from "./pms_companies";
import {PmsDepartments} from "./pms_departments";
import {PmsPlant} from "./pms_plant";
import {PmsSections} from "./pms_sections";


@Entity("idms_user_details",{schema:"public" } )
@Index("fki_fk_contact",["contactU",])
export class IdmsUserDetails {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"user_uid"
        })
    user_uid:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:20,
        name:"first_name"
        })
    first_name:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"middle_name"
        })
    middle_name:string | null;
        

    @Column("character varying",{ 
        nullable:false,
        length:20,
        name:"last_name"
        })
    last_name:string;
        

    @Column("character varying",{ 
        nullable:false,
        length:10,
        name:"gender"
        })
    gender:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"ref_uid"
        })
    ref_uid:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"uid_country"
        })
    uid_country:string | null;
        

    @Column("date",{ 
        nullable:true,
        name:"date_of_birth"
        })
    date_of_birth:string | null;
        

   
    @ManyToOne(type=>IdmsContact, idms_contact=>idms_contact.idmsUserDetailss,{  nullable:false,cascade:true })
    @JoinColumn({ name:'contact_uid'})
    contactU:IdmsContact | null;


   
    @OneToMany(type=>PmsCluster, pms_cluster=>pms_cluster.userU)
    pmsClusters:PmsCluster[];
    

   
    @OneToMany(type=>PmsCompanies, pms_companies=>pms_companies.userU)
    pmsCompaniess:PmsCompanies[];
    

   
    @OneToMany(type=>PmsDepartments, pms_departments=>pms_departments.userU)
    pmsDepartmentss:PmsDepartments[];
    

   
    @OneToMany(type=>PmsPlant, pms_plant=>pms_plant.contactDetails)
    pmsPlants:PmsPlant[];
    

   
    @OneToMany(type=>PmsSections, pms_sections=>pms_sections.user)
    pmsSectionss:PmsSections[];
    
}
