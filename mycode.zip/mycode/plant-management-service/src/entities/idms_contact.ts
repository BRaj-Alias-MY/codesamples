import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsAddress} from "./idms_address";
import {IdmsUserDetails} from "./idms_user_details";


@Entity("idms_contact",{schema:"public" } )
@Index("fki_fk01_address",["addressU",])
export class IdmsContact {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"contact_uid"
        })
    contact_uid:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"land_line_no"
        })
    land_line_no:string | null;
        

    @Column("character varying",{ 
        nullable:false,
        length:15,
        name:"mobile_no"
        })
    mobile_no:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:50,
        name:"email"
        })
    email:string | null;
        

   
    @ManyToOne(type=>IdmsAddress, idms_address=>idms_address.idmsContacts,{cascade:true})
    @JoinColumn({ name:'address_uid'})
    addressU:IdmsAddress | null;


   
    @OneToMany(type=>IdmsUserDetails, idms_user_details=>idms_user_details.contactU)
    idmsUserDetailss:IdmsUserDetails[];
    
}
