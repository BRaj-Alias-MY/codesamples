import {BaseEntity,Column,Entity,Index,JoinColumn,JoinTable,ManyToMany,ManyToOne,OneToMany,OneToOne,PrimaryColumn,PrimaryGeneratedColumn,RelationId} from "typeorm";
import {IdmsContact} from "./idms_contact";
import {IdmsLocation} from "./idms_location";


@Entity("idms_address",{schema:"public" } )
export class IdmsAddress {

    @Column("uuid",{ 
        nullable:false,
        primary:true,
        default: () => "uuid_generate_v4()",
        name:"address_uid"
        })
    address_uid:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"door_no"
        })
    door_no:string | null;
        

    @Column("character varying",{ 
        nullable:false,
        length:50,
        name:"address_line_1"
        })
    address_line_1:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:50,
        name:"address_line_2"
        })
    address_line_2:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:50,
        name:"land_mark"
        })
    land_mark:string | null;
        

    @Column("character varying",{ 
        nullable:true,
        length:20,
        name:"state"
        })
    state:string | null;
        

    @Column("character varying",{ 
        nullable:false,
        length:20,
        name:"country"
        })
    country:string;
        

    @Column("character varying",{ 
        nullable:true,
        length:10,
        name:"zipcode"
        })
    zipcode:string | null;
        

   
    @OneToMany(type=>IdmsContact, idms_contact=>idms_contact.addressU)
    idmsContacts:IdmsContact[];
    

   
    @OneToMany(type=>IdmsLocation, idms_location=>idms_location.addressU)
    idmsLocations:IdmsLocation[];
    
}
